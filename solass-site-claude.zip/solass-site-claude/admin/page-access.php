<?php
/**
 * Сторінка "Доступи та інтеграції".
 *
 * НЕ про оновлення плагіна. Оновлення йдуть на вшитих у код посиланнях
 * (Update URI у шапці + шаблон JSON в апдейтері) і ні з чим тут не пов'язані.
 *
 * Ця сторінка — сховище ДОСТУПІВ для роботи з файлами: запис у репо, обмін,
 * майбутні патчі. Без указаного репо + токена плагін (і Claude через нього)
 * можуть лише читати й виконувати команди, але НЕ записувати файли.
 *
 * На майбутнє сюди додаватимуться інші інтеграції (інші репо, FTP тощо).
 *
 * Процедурний стиль (функції з префіксом solass_claude_access_*).
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Повертає налаштований доступ до GitHub-репо (для запису/патчів).
 *
 * @param array $cfg Налаштування плагіна (solass_claude).
 * @return array [owner, repo, branch, token, configured]
 */
function solass_claude_access_github( array $cfg ): array {
    $owner  = trim( $cfg['gh_owner']  ?? '' );
    $repo   = trim( $cfg['gh_repo']   ?? '' );
    $branch = trim( $cfg['gh_branch'] ?? '' ) ?: 'main';
    $token  = trim( $cfg['gh_token']  ?? '' );

    return array(
        'owner'      => $owner,
        'repo'       => $repo,
        'branch'     => $branch,
        'token'      => $token,
        'configured' => ( $owner !== '' && $repo !== '' && $token !== '' ),
    );
}

/**
 * Замаскувати токен для показу в адмінці (показуємо лише хвіст).
 */
function solass_claude_access_mask_token( string $token ): string {
    $len = strlen( $token );
    if ( $len === 0 ) return '';
    if ( $len <= 8 )  return str_repeat( '•', $len );
    return str_repeat( '•', 12 ) . substr( $token, -4 );
}

/**
 * Перевірка з'єднання з репо: GET /repos/{owner}/{repo} з токеном.
 * Перевіряє лише доступність (HTTP 200). Права на запис тут не перевіряються —
 * вони з'ясуються при першому реальному записі файлу.
 *
 * @return array [ok(bool), code(int), message(string)]
 */
function solass_claude_access_check( array $gh ): array {
    if ( empty( $gh['owner'] ) || empty( $gh['repo'] ) || empty( $gh['token'] ) ) {
        return array( 'ok' => false, 'code' => 0, 'message' => 'Не налаштовано' );
    }

    $url = 'https://api.github.com/repos/' . rawurlencode( $gh['owner'] ) . '/' . rawurlencode( $gh['repo'] );
    $res = wp_remote_get( $url, array(
        'timeout' => 12,
        'headers' => array(
            'Authorization' => 'Bearer ' . $gh['token'],
            'Accept'        => 'application/vnd.github+json',
            'User-Agent'    => 'SOLASS-Site-Claude',
        ),
    ) );

    if ( is_wp_error( $res ) ) {
        return array( 'ok' => false, 'code' => 0, 'message' => 'Немає з\'єднання з GitHub' );
    }

    $code = (int) wp_remote_retrieve_response_code( $res );
    if ( $code === 200 ) {
        return array( 'ok' => true, 'code' => 200, 'message' => 'Доступ підтверджено' );
    }

    return array( 'ok' => false, 'code' => $code, 'message' => 'Дані невірні або немає доступу' );
}

/**
 * Рендер сторінки "Доступи та інтеграції".
 *
 * @param array  $cfg         Налаштування плагіна.
 * @param string $option_name Ім'я опції для form (self::OPT).
 */
function solass_claude_access_render( array $cfg, string $option_name ): void {
    $gh         = solass_claude_access_github( $cfg );
    $has_token  = $gh['token'] !== '';
    $token_mask = solass_claude_access_mask_token( $gh['token'] );

    // Посилання на створення fine-grained токена.
    // Якщо вказано власника — ведемо на його сторінку токенів, інакше загальну.
    if ( $gh['owner'] !== '' ) {
        $token_url = 'https://github.com/settings/personal-access-tokens/new';
    } else {
        $token_url = 'https://github.com/settings/tokens?type=beta';
    }
    ?>
    <div class="wrap">
        <h1>Доступи та інтеграції</h1>
        <p>Тут зберігаються доступи для <strong>роботи з файлами</strong> — запис у репозиторій,
           обмін файлами, майбутні патчі. Це <em>не</em> налаштування оновлень плагіна:
           оновлення працюють окремо й завжди.</p>
        <p><strong>Без указаного репозиторію та токена</strong> плагін може лише читати дані
           й виконувати команди. Можливість <strong>записувати/змінювати файли</strong>
           з'являється тільки після заповнення доступу нижче.</p>

        <form method="post" action="options.php">
            <?php settings_fields( $option_name ); ?>
            <input type="hidden" name="<?= esc_attr( $option_name ) ?>[enabled]"     value="<?= (int) ( $cfg['enabled'] ?? 0 ) ?>">
            <input type="hidden" name="<?= esc_attr( $option_name ) ?>[get_enabled]" value="<?= (int) ( $cfg['get_enabled'] ?? 0 ) ?>">
            <input type="hidden" name="<?= esc_attr( $option_name ) ?>[get_write]"   value="<?= (int) ( $cfg['get_write'] ?? 0 ) ?>">
            <input type="hidden" name="<?= esc_attr( $option_name ) ?>[token]"       value="<?= esc_attr( $cfg['token'] ?? '' ) ?>">
            <input type="hidden" name="<?= esc_attr( $option_name ) ?>[access_slug]" value="<?= esc_attr( $cfg['access_slug'] ?? '' ) ?>">
            <input type="hidden" name="<?= esc_attr( $option_name ) ?>[log_path]"    value="<?= esc_attr( $cfg['log_path'] ?? '' ) ?>">
            <input type="hidden" name="<?= esc_attr( $option_name ) ?>[root_path]"   value="<?= esc_attr( $cfg['root_path'] ?? '' ) ?>">
            <input type="hidden" name="<?= esc_attr( $option_name ) ?>[allowed_ips]" value="<?= esc_attr( $cfg['allowed_ips'] ?? '' ) ?>">
            <?php foreach ( (array) ( $cfg['services'] ?? array() ) as $svc ) : ?>
                <input type="hidden" name="<?= esc_attr( $option_name ) ?>[services][]" value="<?= esc_attr( $svc ) ?>">
            <?php endforeach; ?>

            <h2>GitHub репозиторій</h2>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><label for="gh_owner">Власник (owner)</label></th>
                    <td>
                        <input name="<?= esc_attr( $option_name ) ?>[gh_owner]" id="gh_owner" type="text"
                               class="regular-text" value="<?= esc_attr( $gh['owner'] ) ?>" placeholder="ваш-логін">
                        <p class="description">Логін або організація на GitHub.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="gh_repo">Репозиторій (repo)</label></th>
                    <td>
                        <input name="<?= esc_attr( $option_name ) ?>[gh_repo]" id="gh_repo" type="text"
                               class="regular-text" value="<?= esc_attr( $gh['repo'] ) ?>" placeholder="назва-репозиторію">
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="gh_branch">Гілка (branch)</label></th>
                    <td>
                        <input name="<?= esc_attr( $option_name ) ?>[gh_branch]" id="gh_branch" type="text"
                               class="regular-text" value="<?= esc_attr( $cfg['gh_branch'] ?? '' ) ?>" placeholder="main">
                        <p class="description">Якщо порожньо — використовується <code>main</code>.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="gh_token">Токен доступу</label></th>
                    <td>
                        <?php if ( $has_token ) : ?>
                            <p style="margin:0 0 6px;"><code><?= esc_html( $token_mask ) ?></code> — токен збережено.</p>
                        <?php endif; ?>
                        <span style="position:relative;display:inline-block;">
                            <input name="<?= esc_attr( $option_name ) ?>[gh_token]" id="gh_token" type="password"
                                   class="regular-text" value="<?= esc_attr( $gh['token'] ) ?>" autocomplete="new-password"
                                   placeholder="github_pat_..." style="padding-right:34px;">
                            <button type="button" id="gh_token_eye" class="button-link"
                                    aria-label="Показати або приховати токен"
                                    style="position:absolute;right:6px;top:50%;transform:translateY(-50%);padding:0;line-height:1;cursor:pointer;color:#646970;">
                                <span class="dashicons dashicons-visibility"></span>
                            </button>
                        </span>
                        <p class="description" style="font-weight:normal;">
                            Fine-grained або classic токен з правом запису (Contents: Read &amp; Write).
                            Зберігається в базі сайту. Потрібен лише для запису у репо (патчі/файли).
                            <br><a href="<?= esc_url( $token_url ) ?>" target="_blank" rel="noopener">Отримати токен на GitHub</a>
                        </p>
                        <script>
                        (function () {
                            var btn = document.getElementById('gh_token_eye');
                            var inp = document.getElementById('gh_token');
                            if ( ! btn || ! inp ) return;
                            btn.addEventListener('click', function () {
                                var show = inp.type === 'password';
                                inp.type = show ? 'text' : 'password';
                                btn.querySelector('.dashicons').className =
                                    'dashicons ' + ( show ? 'dashicons-hidden' : 'dashicons-visibility' );
                            });
                        })();
                        </script>
                    </td>
                </tr>
            </table>

            <?php submit_button( 'Зберегти доступи' ); ?>
        </form>

        <h2>Стан доступу</h2>
        <table class="form-table" role="presentation">
            <tr>
                <th scope="row">GitHub запис</th>
                <td>
                    <?php
                    if ( ! $gh['configured'] ) :
                        ?>
                        <span style="color:#8a6d00;font-weight:600;">Не налаштовано</span>
                        — доступні лише читання та команди
                        <?php
                    else :
                        $check = solass_claude_access_check( $gh );
                        if ( $check['ok'] ) :
                            ?>
                            <span style="color:#1a7f37;font-weight:600;">Доступ підтверджено</span>
                            — <?= esc_html( $gh['owner'] . '/' . $gh['repo'] ) ?> (<?= esc_html( $gh['branch'] ) ?>)
                            <?php
                        else :
                            ?>
                            <span style="color:#b32d2e;font-weight:600;"><?= esc_html( $check['message'] ) ?></span>
                            <?php if ( $check['code'] ) : ?>
                                <span style="color:#777;">(HTTP <?= (int) $check['code'] ?>)</span>
                            <?php endif; ?>
                            — перевірте власника, репозиторій та токен
                            <?php
                        endif;
                    endif;
                    ?>
                </td>
            </tr>
        </table>
    </div>
    <?php
}
