<?php
/**
 * Сторінка "Джерело оновлень" — GitHub-конект.
 * Дозволяє кожному сайту працювати зі СВОЇМ репо оновлень,
 * а не з зашитим у код студійним репо.
 *
 * Процедурний стиль (функції з префіксом solass_claude_source_*).
 * Викликається з методу page_source() головного класу.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Повертає поточно діюче джерело оновлень.
 * Пріоритет: налаштування БД (owner/repo/branch) → fallback на Update URI з шапки.
 *
 * @param array $cfg  Налаштування плагіна (solass_claude).
 * @return array [owner, repo, branch, json_url, zip_url, source] — source: 'db'|'header'
 */
function solass_claude_source_resolve( array $cfg ): array {
    $owner  = trim( $cfg['upd_owner']  ?? '' );
    $repo   = trim( $cfg['upd_repo']   ?? '' );
    $branch = trim( $cfg['upd_branch'] ?? '' ) ?: 'main';
    $slug   = 'solass-site-claude';

    if ( $owner !== '' && $repo !== '' ) {
        $base = "https://raw.githubusercontent.com/{$owner}/{$repo}/{$branch}";
        return array(
            'owner'    => $owner,
            'repo'     => $repo,
            'branch'   => $branch,
            'json_url' => "{$base}/{$slug}-info.json",
            'zip_url'  => "{$base}/{$slug}.zip",
            'source'   => 'db',
        );
    }

    // Fallback — з шапки плагіна (Update URI = пряме посилання на zip)
    $zip  = defined( 'SOLASS_CLAUDE_UPDATEURI' ) ? SOLASS_CLAUDE_UPDATEURI : '';
    $json = $zip ? trailingslashit( dirname( $zip ) ) . $slug . '-info.json' : '';
    return array(
        'owner'    => '',
        'repo'     => '',
        'branch'   => '',
        'json_url' => $json,
        'zip_url'  => $zip,
        'source'   => 'header',
    );
}

/**
 * Рендер сторінки "Джерело оновлень".
 *
 * @param array  $cfg         Налаштування плагіна.
 * @param string $option_name Ім'я опції для form (self::OPT).
 */
function solass_claude_source_render( array $cfg, string $option_name ): void {
    $src = solass_claude_source_resolve( $cfg );
    ?>
    <div class="wrap">
        <h1>Джерело оновлень</h1>
        <p>Тут вказується GitHub-репозиторій, з якого плагін отримує оновлення.
           Якщо поля порожні — використовується джерело, зашите в заголовку плагіна (<code>Update URI</code>).</p>

        <form method="post" action="options.php">
            <?php settings_fields( $option_name ); ?>
            <input type="hidden" name="<?= esc_attr( $option_name ) ?>[enabled]"     value="<?= (int) ( $cfg['enabled'] ?? 0 ) ?>">
            <input type="hidden" name="<?= esc_attr( $option_name ) ?>[get_enabled]" value="<?= (int) ( $cfg['get_enabled'] ?? 0 ) ?>">
            <input type="hidden" name="<?= esc_attr( $option_name ) ?>[get_write]"   value="<?= (int) ( $cfg['get_write'] ?? 0 ) ?>">
            <input type="hidden" name="<?= esc_attr( $option_name ) ?>[token]"       value="<?= esc_attr( $cfg['token'] ?? '' ) ?>">
            <input type="hidden" name="<?= esc_attr( $option_name ) ?>[access_slug]" value="<?= esc_attr( $cfg['access_slug'] ?? '' ) ?>">
            <input type="hidden" name="<?= esc_attr( $option_name ) ?>[log_path]"    value="<?= esc_attr( $cfg['log_path'] ?? '' ) ?>">
            <input type="hidden" name="<?= esc_attr( $option_name ) ?>[root_path]"   value="<?= esc_attr( $cfg['root_path'] ?? '' ) ?>">
            <input type="hidden" name="<?= esc_attr( $option_name ) ?>[allowed_ips]" value="<?= esc_attr( $cfg['allowed_ips'] ?? '' ) ?>">
            <?php foreach ( (array) ( $cfg['services'] ?? array() ) as $svc ) : ?>
                <input type="hidden" name="<?= esc_attr( $option_name ) ?>[services][]" value="<?= esc_attr( $svc ) ?>">
            <?php endforeach; ?>

            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><label for="upd_owner">Власник (owner)</label></th>
                    <td>
                        <input name="<?= esc_attr( $option_name ) ?>[upd_owner]" id="upd_owner" type="text"
                               class="regular-text" value="<?= esc_attr( $cfg['upd_owner'] ?? '' ) ?>" placeholder="govras75">
                        <p class="description">Логін або організація на GitHub.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="upd_repo">Репозиторій (repo)</label></th>
                    <td>
                        <input name="<?= esc_attr( $option_name ) ?>[upd_repo]" id="upd_repo" type="text"
                               class="regular-text" value="<?= esc_attr( $cfg['upd_repo'] ?? '' ) ?>" placeholder="site-claude-updates">
                        <p class="description">Назва репозиторію з файлами оновлень.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="upd_branch">Гілка (branch)</label></th>
                    <td>
                        <input name="<?= esc_attr( $option_name ) ?>[upd_branch]" id="upd_branch" type="text"
                               class="regular-text" value="<?= esc_attr( $cfg['upd_branch'] ?? '' ) ?>" placeholder="main">
                        <p class="description">Якщо порожньо — використовується <code>main</code>.</p>
                    </td>
                </tr>
            </table>

            <?php submit_button( 'Зберегти джерело' ); ?>
        </form>

        <h2>Поточно діюче джерело</h2>
        <table class="form-table" role="presentation">
            <tr>
                <th scope="row">Звідки взято</th>
                <td><?= $src['source'] === 'db'
                        ? '<strong>Налаштування плагіна</strong> (поля вище)'
                        : '<strong>Заголовок плагіна</strong> (Update URI) — поля вище порожні' ?></td>
            </tr>
            <tr>
                <th scope="row">JSON інфо</th>
                <td><code><?= esc_html( $src['json_url'] ?: '— не визначено —' ) ?></code></td>
            </tr>
            <tr>
                <th scope="row">ZIP архів</th>
                <td><code><?= esc_html( $src['zip_url'] ?: '— не визначено —' ) ?></code></td>
            </tr>
        </table>
    </div>
    <?php
}
