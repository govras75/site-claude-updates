<?php
/**
 * SOLASS Site -> Claude — БЛОК: Робота з репозиторіями через GitHub API (Шар 2)
 * -------------------------------------------------------------------
 * Самодостатній блок-фіча. Працює ПІСЛЯ підключення (коли в опції є токен).
 * Дає:
 *   - попап вибору репозиторію (перші 5 свіжих + пошук від 3 символів),
 *   - створення нового репозиторію (назва + приватність),
 *   - узгоджене заповнення owner/repo/branch у форму доступів.
 *
 * Бере токен з опції solass_claude_github (байдуже, як здобутий — device
 * flow чи руками). Не знає про спосіб підключення.
 *
 * Видалення цього файлу прибирає лише вибір/створення репо. Підключення
 * (storage-auth.php) і ручна форма лишаються робочими.
 *
 * Процедурний стиль, префікс solass_storage_api_*. Уся логіка в одному файлі.
 * -------------------------------------------------------------------
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* Поточний токен/owner з опції. */
function solass_storage_api_token(): string {
	$gh = SOLASS_Config::cfg_github();
	return trim( $gh['gh_token'] ?? '' );
}
function solass_storage_api_owner(): string {
	$gh = SOLASS_Config::cfg_github();
	return trim( $gh['gh_owner'] ?? '' );
}

/* Базовий GET до GitHub API з токеном. Повертає [code, data]. */
function solass_storage_api_get( string $url, string $token ): array {
	$res = wp_remote_get( $url, array(
		'timeout' => 15,
		'headers' => array(
			'Authorization' => 'Bearer ' . $token,
			'Accept'        => 'application/vnd.github+json',
			'User-Agent'    => 'SOLASS-Site-Claude',
		),
	) );
	if ( is_wp_error( $res ) ) return array( 0, null );
	$code = (int) wp_remote_retrieve_response_code( $res );
	$data = json_decode( wp_remote_retrieve_body( $res ), true );
	return array( $code, $data );
}

/* Звести репо до короткого виду для фронта. */
function solass_storage_api_shape( array $r ): array {
	return array(
		'owner'   => $r['owner']['login'] ?? '',
		'name'    => $r['name'] ?? '',
		'branch'  => $r['default_branch'] ?? 'main',
		'private' => ! empty( $r['private'] ),
		'full'    => $r['full_name'] ?? '',
	);
}

/* ====================== AJAX: список / пошук репозиторіїв ====================== */
add_action( 'wp_ajax_solass_storage_gh_repos', 'solass_storage_api_ajax_repos' );
function solass_storage_api_ajax_repos(): void {
	check_ajax_referer( 'solass_storage_gh', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'Немає прав' ), 403 );
	}

	$token = solass_storage_api_token();
	if ( $token === '' ) {
		wp_send_json_error( array( 'message' => 'Спочатку підключіть GitHub' ), 400 );
	}

	$q = isset( $_POST['q'] ) ? sanitize_text_field( wp_unslash( $_POST['q'] ) ) : '';
	$q = trim( $q );

	$list = array();

	if ( mb_strlen( $q ) >= 3 ) {
		// Пошук серед репо акаунта по назві.
		$owner = solass_storage_api_owner();
		$query = rawurlencode( $q . ' in:name' . ( $owner !== '' ? ' user:' . $owner : '' ) . ' fork:true' );
		list( $code, $data ) = solass_storage_api_get(
			'https://api.github.com/search/repositories?q=' . $query . '&per_page=5',
			$token
		);
		if ( $code === 200 && ! empty( $data['items'] ) ) {
			foreach ( $data['items'] as $r ) $list[] = solass_storage_api_shape( $r );
		}
	} else {
		// Перші 5 свіжих репо (власні).
		list( $code, $data ) = solass_storage_api_get(
			'https://api.github.com/user/repos?sort=updated&per_page=5&affiliation=owner',
			$token
		);
		if ( $code === 200 && is_array( $data ) ) {
			foreach ( $data as $r ) $list[] = solass_storage_api_shape( $r );
		}
	}

	if ( ! isset( $code ) || $code !== 200 ) {
		wp_send_json_error( array( 'message' => 'GitHub не повернув список (перевірте доступ).' ), 502 );
	}

	wp_send_json_success( array( 'repos' => $list ) );
}

/* ====================== AJAX: вибір репозиторію ====================== */
add_action( 'wp_ajax_solass_storage_gh_pick', 'solass_storage_api_ajax_pick' );
function solass_storage_api_ajax_pick(): void {
	check_ajax_referer( 'solass_storage_gh', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'Немає прав' ), 403 );
	}

	$owner  = isset( $_POST['owner'] )  ? sanitize_text_field( wp_unslash( $_POST['owner'] ) )  : '';
	$repo   = isset( $_POST['repo'] )   ? sanitize_text_field( wp_unslash( $_POST['repo'] ) )   : '';
	$branch = isset( $_POST['branch'] ) ? sanitize_text_field( wp_unslash( $_POST['branch'] ) ) : 'main';

	if ( $owner === '' || $repo === '' ) {
		wp_send_json_error( array( 'message' => 'Не вказано репозиторій' ), 400 );
	}

	$gh = (array) get_option( SOLASS_Config::OPT_GH, array() );
	$gh['gh_owner']  = $owner;
	$gh['gh_repo']   = $repo;
	$gh['gh_branch'] = $branch ?: 'main';
	update_option( SOLASS_Config::OPT_GH, $gh );

	wp_send_json_success( array( 'owner' => $owner, 'repo' => $repo, 'branch' => $gh['gh_branch'] ) );
}

/* ====================== AJAX: створення репозиторію ====================== */
add_action( 'wp_ajax_solass_storage_gh_create', 'solass_storage_api_ajax_create' );
function solass_storage_api_ajax_create(): void {
	check_ajax_referer( 'solass_storage_gh', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'Немає прав' ), 403 );
	}

	$token = solass_storage_api_token();
	if ( $token === '' ) {
		wp_send_json_error( array( 'message' => 'Спочатку підключіть GitHub' ), 400 );
	}

	$name    = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
	$private = ! empty( $_POST['private'] ) && $_POST['private'] !== 'false';

	$name = trim( $name );
	if ( $name === '' ) {
		wp_send_json_error( array( 'message' => 'Вкажіть назву репозиторію' ), 400 );
	}

	$res = wp_remote_post( 'https://api.github.com/user/repos', array(
		'timeout' => 20,
		'headers' => array(
			'Authorization' => 'Bearer ' . $token,
			'Accept'        => 'application/vnd.github+json',
			'User-Agent'    => 'SOLASS-Site-Claude',
			'Content-Type'  => 'application/json',
		),
		'body'    => wp_json_encode( array(
			'name'      => $name,
			'private'   => $private,
			'auto_init' => true, // одразу гілка main + README, щоб репо було готове до запису
		) ),
	) );

	if ( is_wp_error( $res ) ) {
		wp_send_json_error( array( 'message' => 'Немає з\'єднання з GitHub' ), 502 );
	}

	$code = (int) wp_remote_retrieve_response_code( $res );
	$data = json_decode( wp_remote_retrieve_body( $res ), true );

	if ( $code !== 201 ) {
		$msg = $data['errors'][0]['message'] ?? ( $data['message'] ?? 'Не вдалося створити репозиторій' );
		// Типовий випадок — назва вже існує.
		if ( stripos( (string) $msg, 'already exists' ) !== false ) {
			$msg = 'Репозиторій з такою назвою вже існує';
		}
		wp_send_json_error( array( 'message' => $msg ), 400 );
	}

	$shaped = solass_storage_api_shape( $data );

	// Одразу зберігаємо як обраний.
	$gh = (array) get_option( SOLASS_Config::OPT_GH, array() );
	$gh['gh_owner']  = $shaped['owner'];
	$gh['gh_repo']   = $shaped['name'];
	$gh['gh_branch'] = $shaped['branch'] ?: 'main';
	update_option( SOLASS_Config::OPT_GH, $gh );

	wp_send_json_success( $shaped );
}

/* ====================== Рендер блоку (кнопка + попап) ====================== */
/* Кнопка «Обрати репозиторій» — рендериться всередині плашки підключення (на всю ширину). */
function solass_storage_api_render_button(): void {
	if ( solass_storage_api_token() === '' ) return;
	?>
	<p style="margin:10px 0;">
		<button type="button" class="button button-primary" id="sc-repo-open" style="width:100%;justify-content:center;">Обрати репозиторій</button>
	</p>
	<?php
}

function solass_storage_api_render_block(): void {
	// Показуємо лише коли є токен (підключено). Тут — лише попап (кнопка окремо, у плашці).
	if ( solass_storage_api_token() === '' ) return;

	$nonce = wp_create_nonce( 'solass_storage_gh' );
	?>

	<!-- Попап -->
	<div class="sc-modal" id="sc-repo-modal" style="display:none;">
		<div class="sc-modal-overlay" id="sc-repo-overlay"></div>
		<div class="sc-modal-box" role="dialog" aria-modal="true">
			<div class="sc-modal-head">
				<strong>Репозиторій GitHub</strong>
				<button type="button" class="sc-modal-x" id="sc-repo-x" aria-label="Закрити">&times;</button>
			</div>

			<div class="sc-modal-tabs">
				<button type="button" class="sc-tab is-active" data-tab="pick">Обрати наявний</button>
				<button type="button" class="sc-tab" data-tab="create">Створити новий</button>
			</div>

			<!-- Вкладка: вибір -->
			<div class="sc-tabpane" data-pane="pick">
				<input type="text" id="sc-repo-search" class="regular-text" placeholder="Пошук за назвою (від 3 символів)…" style="width:100%;margin-bottom:10px;">
				<div class="sc-repo-list" id="sc-repo-list">
					<p class="sc-repo-empty">Завантаження…</p>
				</div>
			</div>

			<!-- Вкладка: створення -->
			<div class="sc-tabpane" data-pane="create" style="display:none;">
				<p>
					<label for="sc-repo-name"><strong>Назва репозиторію</strong></label><br>
					<input type="text" id="sc-repo-name" class="regular-text" placeholder="site-backups" style="width:100%;">
				</p>
				<p>
					<label><input type="checkbox" id="sc-repo-public"> Зробити публічним</label>
					<span class="description">за замовчуванням приватний</span>
				</p>
				<p>
					<button type="button" class="button button-primary" id="sc-repo-create-btn">Створити і підключити</button>
					<span class="sc-repo-create-msg" id="sc-repo-create-msg"></span>
				</p>
			</div>
		</div>
	</div>

	<style>
		.sc-repo { margin:0 0 20px; }
		.sc-repo-row { display:flex; gap:12px; align-items:center; flex-wrap:wrap; }
		.sc-modal { position:fixed; inset:0; z-index:100000; }
		.sc-modal-overlay { position:absolute; inset:0; background:rgba(0,0,0,.5); }
		.sc-modal-box { position:relative; max-width:520px; margin:8vh auto 0; background:#fff; border-radius:8px; box-shadow:0 10px 40px rgba(0,0,0,.3); padding:0; overflow:hidden; }
		.sc-modal-head { display:flex; justify-content:space-between; align-items:center; padding:14px 18px; border-bottom:1px solid #e0e0e0; }
		.sc-modal-x { background:none; border:0; font-size:22px; line-height:1; cursor:pointer; color:#777; }
		.sc-modal-x:hover { color:#000; }
		.sc-modal-tabs { display:flex; gap:4px; padding:10px 18px 0; }
		.sc-tab { background:none; border:0; border-bottom:2px solid transparent; padding:6px 10px; cursor:pointer; font-size:13px; color:#555; }
		.sc-tab.is-active { color:#2271b1; border-bottom-color:#2271b1; font-weight:600; }
		.sc-tabpane { padding:16px 18px 20px; }
		.sc-repo-list { max-height:280px; overflow-y:auto; }
		.sc-repo-item { display:flex; justify-content:space-between; align-items:center; padding:10px 12px; border:1px solid #e6e6e6; border-radius:6px; margin-bottom:6px; cursor:pointer; }
		.sc-repo-item:hover { border-color:#2271b1; background:#f0f6fc; }
		.sc-repo-item .sc-repo-name { font-weight:600; }
		.sc-repo-item .sc-repo-meta { font-size:12px; color:#777; }
		.sc-repo-badge { font-size:11px; padding:2px 8px; border-radius:10px; background:#eee; color:#555; }
		.sc-repo-badge.priv { background:#fcf0e6; color:#8a5400; }
		.sc-repo-empty { color:#777; text-align:center; padding:14px; }
		.sc-repo-create-msg { margin-left:10px; }
		.sc-repo-create-msg.err { color:#b32d2e; }
	</style>

	<script>
	(function () {
		var AJAX  = '<?= esc_js( admin_url( 'admin-ajax.php' ) ) ?>';
		var NONCE = '<?= esc_js( $nonce ) ?>';

		var openBtn  = document.getElementById('sc-repo-open');
		var modal    = document.getElementById('sc-repo-modal');
		var overlay  = document.getElementById('sc-repo-overlay');
		var closeBtn = document.getElementById('sc-repo-x');
		var search   = document.getElementById('sc-repo-search');
		var listBox  = document.getElementById('sc-repo-list');
		var createBtn= document.getElementById('sc-repo-create-btn');
		var createMsg= document.getElementById('sc-repo-create-msg');
		var nameInp  = document.getElementById('sc-repo-name');
		var pubChk   = document.getElementById('sc-repo-public');

		if ( ! openBtn ) return;

		function post(action, params, cb) {
			var body = 'action=' + action + '&nonce=' + encodeURIComponent(NONCE);
			for (var k in params) body += '&' + k + '=' + encodeURIComponent(params[k]);
			fetch(AJAX, { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:body })
				.then(function(r){ return r.json(); }).then(cb).catch(function(){ cb(null); });
		}

		function openModal()  { modal.style.display='block'; loadRepos(''); }
		function closeModal() { modal.style.display='none'; }

		openBtn.addEventListener('click', openModal);
		overlay.addEventListener('click', closeModal);
		closeBtn.addEventListener('click', closeModal);

		// Вкладки
		document.querySelectorAll('.sc-tab').forEach(function(tab){
			tab.addEventListener('click', function(){
				document.querySelectorAll('.sc-tab').forEach(function(t){ t.classList.remove('is-active'); });
				tab.classList.add('is-active');
				var name = tab.getAttribute('data-tab');
				document.querySelectorAll('.sc-tabpane').forEach(function(p){
					p.style.display = ( p.getAttribute('data-pane') === name ) ? 'block' : 'none';
				});
			});
		});

		function renderList(repos) {
			if ( ! repos || ! repos.length ) {
				listBox.innerHTML = '<p class="sc-repo-empty">Нічого не знайдено</p>';
				return;
			}
			listBox.innerHTML = '';
			repos.forEach(function(r){
				var item = document.createElement('div');
				item.className = 'sc-repo-item';
				item.innerHTML =
					'<span><span class="sc-repo-name">' + r.name + '</span>'
					+ '<br><span class="sc-repo-meta">' + r.owner + ' · ' + r.branch + '</span></span>'
					+ '<span class="sc-repo-badge ' + (r.private ? 'priv' : '') + '">' + (r.private ? 'приватний' : 'публічний') + '</span>';
				item.addEventListener('click', function(){ pickRepo(r); });
				listBox.appendChild(item);
			});
		}

		function loadRepos(q) {
			listBox.innerHTML = '<p class="sc-repo-empty">Завантаження…</p>';
			post('solass_storage_gh_repos', { q: q || '' }, function(res){
				if ( ! res || ! res.success ) {
					listBox.innerHTML = '<p class="sc-repo-empty">' + (res && res.data && res.data.message ? res.data.message : 'Помилка завантаження') + '</p>';
					return;
				}
				renderList(res.data.repos);
			});
		}

		var searchTimer = null;
		search.addEventListener('input', function(){
			var q = search.value.trim();
			clearTimeout(searchTimer);
			if ( q.length > 0 && q.length < 3 ) return; // чекаємо 3 символи
			searchTimer = setTimeout(function(){ loadRepos(q); }, 350);
		});

		function pickRepo(r) {
			post('solass_storage_gh_pick', { owner:r.owner, repo:r.name, branch:r.branch }, function(res){
				if ( res && res.success ) { location.reload(); }
				else { alert( res && res.data && res.data.message ? res.data.message : 'Не вдалося обрати' ); }
			});
		}

		createBtn && createBtn.addEventListener('click', function(){
			var name = (nameInp.value || '').trim();
			createMsg.className = 'sc-repo-create-msg';
			createMsg.textContent = '';
			if ( ! name ) { createMsg.className='sc-repo-create-msg err'; createMsg.textContent='Вкажіть назву'; return; }
			createBtn.disabled = true; createBtn.textContent = 'Створюю…';
			post('solass_storage_gh_create', { name:name, private: pubChk.checked ? 'false' : 'true' }, function(res){
				createBtn.disabled = false; createBtn.textContent = 'Створити і підключити';
				if ( res && res.success ) { location.reload(); }
				else { createMsg.className='sc-repo-create-msg err'; createMsg.textContent = res && res.data && res.data.message ? res.data.message : 'Помилка'; }
			});
		});
	})();
	</script>
	<?php
}
