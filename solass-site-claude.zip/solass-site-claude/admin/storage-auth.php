<?php
/**
 * SOLASS Site -> Claude — БЛОК: Підключення GitHub через Device Flow
 * -------------------------------------------------------------------
 * Самодостатній блок-фіча. Дає кнопку "Підключити GitHub", яка через
 * OAuth Device Flow здобуває токен і кладе його у форму доступів
 * (опція solass_claude_github -> gh_token, gh_owner).
 *
 * Межа назовні одна: НА ВИХОДІ ТОКЕН у формі. Як саме здобутий —
 * нікого більше не обходить. Тому блок замінний: захочемо колись
 * редірект-флоу замість device flow — міняємо ТІЛЬКИ цей файл.
 *
 * Видалення цього файлу прибирає лише кнопку підключення. Ручна форма
 * доступів (owner/repo/branch/token) лишається й працює як раніше.
 *
 * Процедурний стиль, префікс solass_storage_gh_*. Уся логіка (PHP+JS+CSS)
 * в одному файлі — щоб видалявся безслідно.
 * -------------------------------------------------------------------
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/*
 * Публічний Client ID OAuth-застосунку SOLASS ("SOLASS Site Claude").
 * Це НЕ секрет: він не дає доступу ні до акаунта SOLASS, ні до чужих репо.
 * Device Flow працює лише на client_id (client_secret не потрібен).
 */
if ( ! defined( 'SOLASS_STORAGE_GH_CLIENT_ID' ) ) {
	define( 'SOLASS_STORAGE_GH_CLIENT_ID', 'Ov23liT0nY5o33DF3hlL' );
}

/*
 * Scope для OAuth App device flow. OAuth App не має fine-grained прав,
 * тому для запису у вміст репозиторіїв беремо класичний scope "repo".
 * Це широкий доступ (усі репо користувача) — наслідок вибору OAuth App;
 * токен лежить лише в БД сайту користувача й використовується для
 * обраного репо.
 */
if ( ! defined( 'SOLASS_STORAGE_GH_SCOPE' ) ) {
	define( 'SOLASS_STORAGE_GH_SCOPE', 'repo' );
}

// Ключ transient для device_code (прив'язка до користувача).
function solass_storage_gh_dc_key(): string {
	return 'solass_storage_gh_dc_' . get_current_user_id();
}

/* ====================== AJAX: старт device flow ====================== */
add_action( 'wp_ajax_solass_storage_gh_start', 'solass_storage_gh_ajax_start' );
function solass_storage_gh_ajax_start(): void {
	check_ajax_referer( 'solass_storage_gh', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'Немає прав' ), 403 );
	}

	$res = wp_remote_post( 'https://github.com/login/device/code', array(
		'timeout' => 15,
		'headers' => array( 'Accept' => 'application/json', 'User-Agent' => 'SOLASS-Site-Claude' ),
		'body'    => array(
			'client_id' => SOLASS_STORAGE_GH_CLIENT_ID,
			'scope'     => SOLASS_STORAGE_GH_SCOPE,
		),
	) );

	if ( is_wp_error( $res ) ) {
		wp_send_json_error( array( 'message' => 'Немає з\'єднання з GitHub' ), 502 );
	}

	$data = json_decode( wp_remote_retrieve_body( $res ), true );
	if ( empty( $data['device_code'] ) || empty( $data['user_code'] ) ) {
		wp_send_json_error( array(
			'message' => 'GitHub не повернув код. Перевірте, чи увімкнено Device Flow у застосунку.',
		), 502 );
	}

	$expires = (int) ( $data['expires_in'] ?? 900 );
	set_transient( solass_storage_gh_dc_key(), $data['device_code'], $expires );

	wp_send_json_success( array(
		'user_code'        => $data['user_code'],
		'verification_uri' => $data['verification_uri'] ?? 'https://github.com/login/device',
		'interval'         => (int) ( $data['interval'] ?? 5 ),
		'expires_in'       => $expires,
	) );
}

/* ====================== AJAX: опитування статусу ====================== */
add_action( 'wp_ajax_solass_storage_gh_poll', 'solass_storage_gh_ajax_poll' );
function solass_storage_gh_ajax_poll(): void {
	check_ajax_referer( 'solass_storage_gh', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'Немає прав' ), 403 );
	}

	$dc = get_transient( solass_storage_gh_dc_key() );
	if ( ! $dc ) {
		wp_send_json_error( array( 'state' => 'expired', 'message' => 'Код протерміновано. Почніть спочатку.' ) );
	}

	$res = wp_remote_post( 'https://github.com/login/oauth/access_token', array(
		'timeout' => 15,
		'headers' => array( 'Accept' => 'application/json', 'User-Agent' => 'SOLASS-Site-Claude' ),
		'body'    => array(
			'client_id'   => SOLASS_STORAGE_GH_CLIENT_ID,
			'device_code' => $dc,
			'grant_type'  => 'urn:ietf:params:oauth:grant-type:device_code',
		),
	) );

	// Тимчасова мережна помилка — не зривати поллінг, хай триває.
	if ( is_wp_error( $res ) ) {
		wp_send_json_success( array( 'state' => 'pending' ) );
	}

	$data = json_decode( wp_remote_retrieve_body( $res ), true );

	// Успіх — отримали токен.
	if ( ! empty( $data['access_token'] ) ) {
		$token = (string) $data['access_token'];
		$login = solass_storage_gh_fetch_login( $token );

		$gh = (array) get_option( SOLASS_Config::OPT_GH, array() );
		$gh['gh_token'] = $token;
		if ( $login !== '' ) {
			$gh['gh_owner'] = $login;
		}
		update_option( SOLASS_Config::OPT_GH, $gh );

		delete_transient( solass_storage_gh_dc_key() );
		wp_send_json_success( array( 'state' => 'done', 'login' => $login ) );
	}

	// Проміжні стани device flow.
	$err = $data['error'] ?? 'unknown';

	if ( $err === 'authorization_pending' ) {
		wp_send_json_success( array( 'state' => 'pending' ) );
	}
	if ( $err === 'slow_down' ) {
		wp_send_json_success( array( 'state' => 'pending', 'interval' => (int) ( $data['interval'] ?? 10 ) ) );
	}
	if ( $err === 'expired_token' ) {
		delete_transient( solass_storage_gh_dc_key() );
		wp_send_json_error( array( 'state' => 'expired', 'message' => 'Код протерміновано. Почніть спочатку.' ) );
	}
	if ( $err === 'access_denied' ) {
		delete_transient( solass_storage_gh_dc_key() );
		wp_send_json_error( array( 'state' => 'denied', 'message' => 'Доступ відхилено на GitHub.' ) );
	}

	wp_send_json_error( array( 'state' => 'error', 'message' => 'GitHub: ' . $err ) );
}

/* Отримати login користувача за токеном (для автозаповнення owner). */
function solass_storage_gh_fetch_login( string $token ): string {
	$res = wp_remote_get( 'https://api.github.com/user', array(
		'timeout' => 12,
		'headers' => array(
			'Authorization' => 'Bearer ' . $token,
			'Accept'        => 'application/vnd.github+json',
			'User-Agent'    => 'SOLASS-Site-Claude',
		),
	) );
	if ( is_wp_error( $res ) ) return '';
	$d = json_decode( wp_remote_retrieve_body( $res ), true );
	return isset( $d['login'] ) ? (string) $d['login'] : '';
}

/* ====================== AJAX: відключення (вийти з акаунта) ====================== */
add_action( 'wp_ajax_solass_storage_gh_disconnect', 'solass_storage_gh_ajax_disconnect' );
function solass_storage_gh_ajax_disconnect(): void {
	check_ajax_referer( 'solass_storage_gh', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'Немає прав' ), 403 );
	}

	// Стираємо лише токен і owner — repo/branch лишаємо (раптом заповнені вручну).
	// Це локальне відключення: дозвіл застосунку на самому GitHub НЕ відкликається
	// (це може зробити лише користувач у Settings → Applications).
	$gh = (array) get_option( SOLASS_Config::OPT_GH, array() );
	$gh['gh_token'] = '';
	$gh['gh_owner'] = '';
	update_option( SOLASS_Config::OPT_GH, $gh );

	delete_transient( solass_storage_gh_dc_key() );
	wp_send_json_success( array( 'state' => 'disconnected' ) );
}

/* ====================== Рендер блоку на сторінці ====================== */
function solass_storage_gh_render_block(): void {
	$nonce       = wp_create_nonce( 'solass_storage_gh' );
	$gh          = SOLASS_Config::cfg_github();
	$is_connected = ! empty( $gh['gh_token'] );
	$owner_now   = trim( $gh['gh_owner'] ?? '' );
	?>
	<div class="sc-conn" id="sc-conn">
		<h2>Підключення GitHub</h2>
		<p class="description" style="margin-bottom:12px;">
			Натисніть «Підключити» — і ввійдіть на GitHub без ручного створення токена.
			Дані доступу нижче заповняться автоматично. Ручне заповнення теж лишається доступним.
		</p>

		<?php if ( $is_connected ) : ?>
			<p class="sc-conn-state sc-conn-ok">
				<span class="dashicons dashicons-yes-alt"></span>
				Підключено<?php if ( $owner_now !== '' ) : ?> як <strong><?= esc_html( $owner_now ) ?></strong><?php endif; ?>.
			</p>
			<p class="sc-conn-row">
				<button type="button" class="button" id="sc-conn-start">Підключити інший акаунт</button>
				<button type="button" class="button" id="sc-conn-logout">Вийти з акаунта</button>
				<a href="https://github.com/settings/applications" target="_blank" rel="noopener" class="sc-conn-revoke">відкликати на GitHub</a>
			</p>
		<?php else : ?>
			<p>
				<button type="button" class="button button-primary" id="sc-conn-start">
					<span class="dashicons dashicons-github" style="vertical-align:middle;margin-top:-2px;"></span>
					Підключити GitHub
				</button>
			</p>
		<?php endif; ?>

		<!-- Область коду (з'являється після старту) -->
		<div class="sc-conn-code" id="sc-conn-code" style="display:none;">
			<p style="margin:0 0 6px;">1. Відкрийте сторінку GitHub і введіть код:</p>
			<div class="sc-conn-row">
				<code class="sc-conn-usercode" id="sc-conn-usercode">––––––––</code>
				<button type="button" class="button" id="sc-conn-copy">Копіювати код</button>
				<a class="button button-primary" id="sc-conn-open" href="https://github.com/login/device" target="_blank" rel="noopener">Відкрити GitHub</a>
			</div>
			<p class="sc-conn-status" id="sc-conn-status" style="margin-top:10px;">
				2. Підтвердьте доступ на GitHub. Чекаю підтвердження…
			</p>
		</div>

		<!-- Повідомлення про помилку -->
		<div class="sc-conn-err" id="sc-conn-err" style="display:none;"></div>
	</div>

	<style>
		.sc-conn { background:#fff; border:1px solid #e0e0e0; border-radius:8px; padding:16px 20px; margin:0 0 20px; max-width:760px; }
		.sc-conn h2 { margin:0 0 6px; }
		.sc-conn .dashicons-github:before { content:"\f325"; }
		.sc-conn-row { display:flex; gap:10px; align-items:center; flex-wrap:wrap; }
		.sc-conn-usercode { font-size:20px; letter-spacing:3px; font-weight:600; background:#f0f6fc; border:1px solid #c8d8e8; border-radius:6px; padding:8px 16px; }
		.sc-conn-code { margin-top:12px; padding-top:12px; border-top:1px solid #f0f0f0; }
		.sc-conn-state { font-weight:600; display:flex; align-items:center; gap:6px; }
		.sc-conn-ok { color:#1a7f37; }
		.sc-conn-ok .dashicons { color:#1a7f37; }
		.sc-conn-status { color:#555; }
		.sc-conn-err { color:#b32d2e; font-weight:600; margin-top:10px; }
		.sc-conn-revoke { font-size:12px; color:#777; align-self:center; }
	</style>

	<script>
	(function () {
		var AJAX  = '<?= esc_js( admin_url( 'admin-ajax.php' ) ) ?>';
		var NONCE = '<?= esc_js( $nonce ) ?>';

		var startBtn = document.getElementById('sc-conn-start');
		var codeBox  = document.getElementById('sc-conn-code');
		var codeEl   = document.getElementById('sc-conn-usercode');
		var copyBtn  = document.getElementById('sc-conn-copy');
		var openBtn  = document.getElementById('sc-conn-open');
		var statusEl = document.getElementById('sc-conn-status');
		var errBox   = document.getElementById('sc-conn-err');

		if ( ! startBtn ) return;

		var pollTimer = null;
		var deadline  = 0;

		function showErr(msg) {
			if (pollTimer) { clearTimeout(pollTimer); pollTimer = null; }
			errBox.textContent = msg;
			errBox.style.display = 'block';
		}
		function clearErr() { errBox.style.display = 'none'; errBox.textContent = ''; }

		function post(action, cb) {
			var body = 'action=' + action + '&nonce=' + encodeURIComponent(NONCE);
			fetch(AJAX, {
				method: 'POST',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
				body: body
			})
			.then(function (r) { return r.json(); })
			.then(cb)
			.catch(function () { /* мережа — спробуємо на наступному циклі */ cb(null); });
		}

		startBtn.addEventListener('click', function () {
			clearErr();
			startBtn.disabled = true;
			startBtn.textContent = 'Запит до GitHub…';
			post('solass_storage_gh_start', function (res) {
				startBtn.disabled = false;
				startBtn.textContent = 'Підключити інший акаунт';
				if ( ! res || ! res.success ) {
					showErr( res && res.data && res.data.message ? res.data.message : 'Не вдалося звʼязатися з GitHub.' );
					return;
				}
				var d = res.data;
				codeEl.textContent = d.user_code;
				openBtn.href = d.verification_uri || 'https://github.com/login/device';
				codeBox.style.display = 'block';
				deadline = Date.now() + (d.expires_in || 900) * 1000;
				var interval = Math.max(5, d.interval || 5);
				schedulePoll(interval);
			});
		});

		copyBtn && copyBtn.addEventListener('click', function () {
			var t = codeEl.textContent;
			if (navigator.clipboard) { navigator.clipboard.writeText(t); }
			var o = copyBtn.textContent; copyBtn.textContent = 'Скопійовано';
			setTimeout(function(){ copyBtn.textContent = o; }, 1500);
		});

		var logoutBtn = document.getElementById('sc-conn-logout');
		logoutBtn && logoutBtn.addEventListener('click', function () {
			if ( ! confirm('Вийти з акаунта GitHub? Токен буде стерто з цього сайту.') ) return;
			logoutBtn.disabled = true;
			logoutBtn.textContent = 'Виходжу…';
			post('solass_storage_gh_disconnect', function (res) {
				if ( res && res.success ) {
					location.reload();
				} else {
					logoutBtn.disabled = false;
					logoutBtn.textContent = 'Вийти з акаунта';
					showErr( res && res.data && res.data.message ? res.data.message : 'Не вдалося відключити.' );
				}
			});
		});

		function schedulePoll(intervalSec) {
			pollTimer = setTimeout(function () { poll(intervalSec); }, intervalSec * 1000);
		}

		function poll(intervalSec) {
			if (Date.now() > deadline) { showErr('Код протерміновано. Почніть спочатку.'); return; }
			post('solass_storage_gh_poll', function (res) {
				if ( ! res ) { schedulePoll(intervalSec); return; } // мережа — повтор
				if ( res.success && res.data && res.data.state === 'done' ) {
					statusEl.innerHTML = '<span class="dashicons dashicons-yes-alt" style="color:#1a7f37;"></span> Підключено'
						+ ( res.data.login ? ' як <strong>' + res.data.login + '</strong>' : '' )
						+ '. Оновлюю сторінку…';
					setTimeout(function(){ location.reload(); }, 1200);
					return;
				}
				if ( res.success && res.data && res.data.state === 'pending' ) {
					var nextInt = res.data.interval ? Math.max(5, res.data.interval) : intervalSec;
					schedulePoll(nextInt);
					return;
				}
				// помилкові стани (expired/denied/error)
				var msg = res.data && res.data.message ? res.data.message : 'Помилка підключення.';
				showErr(msg);
			});
		}
	})();
	</script>
	<?php
}
