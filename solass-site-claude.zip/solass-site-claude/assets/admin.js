/* global SC, ajaxurl */
/**
 * SOLASS Site → Claude — Admin JS
 * Динамічні дані (SC.token, SC.baseUrl тощо) передаються через wp_localize_script.
 */
(function () {
    'use strict';

    // --- Іконки dashicons (inline HTML) ---
    var ICON_DONE     = '<span class="dashicons dashicons-yes-alt" style="color:#00a32a;font-size:20px;width:20px;height:20px;display:block;"></span>';
    var ICON_DONE_W   = '<span class="dashicons dashicons-yes-alt" style="color:#fff;font-size:18px;width:18px;height:18px;margin:0;display:block;"></span>';
    var ICON_UPDATE_W = '<span class="dashicons dashicons-update" style="color:#fff;font-size:18px;width:18px;height:18px;margin:0;display:block;"></span>';

    // --- Копіювання тексту ---
    function scCopy(text, btn) {
        var orig = btn.innerHTML;
        navigator.clipboard.writeText(text).then(function () {
            btn.innerHTML = ICON_DONE;
            setTimeout(function () { btn.innerHTML = orig; }, 2000);
        });
    }

    // --- Ініціалізація після DOM ---
    document.addEventListener('DOMContentLoaded', function () {

        // Всі кнопки копіювання з data-copy (універсально)
        document.querySelectorAll('.sc-copy-icon[data-copy]').forEach(function (btn) {
            btn.addEventListener('click', function () { scCopy(this.dataset.copy, this); });
        });

        // Копіювання токена
        var copyToken = document.getElementById('sc-copy-token');
        if (copyToken) {
            copyToken.addEventListener('click', function () { scCopy(SC.token, this); });
        }

        // Кнопка "Для Claude"
        var copyForClaude = document.getElementById('sc-copy-claude');
        if (copyForClaude) {
            copyForClaude.addEventListener('click', function () {
                var self = this;
                var slugInput = document.getElementById('sc-slug-input');
                var slug = slugInput ? slugInput.value : '';
                var msg = 'SOLASS API: ' + SC.baseUrl + '\nToken: ' + SC.token + '\nHelp: ' + SC.helpUrl;
                if (slug) msg += '\nDiscover: ' + SC.baseUrl + '/discover/' + slug;
                navigator.clipboard.writeText(msg).then(function () {
                    self.style.background = '#00a32a';
                    self.style.borderColor = '#00a32a';
                    setTimeout(function () { self.style.background = ''; self.style.borderColor = ''; }, 2000);
                });
            });
        }

        // Генерація access slug
        var genSlug = document.getElementById('sc-gen-slug');
        if (genSlug) {
            genSlug.addEventListener('click', function () {
                var chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
                var slug = '';
                for (var i = 0; i < 8; i++) slug += chars[Math.floor(Math.random() * chars.length)];
                document.getElementById('sc-slug-input').value = slug;
            });
        }

        // GET-режим toggle
        var getToggle = document.getElementById('sc-get-toggle');
        if (getToggle) {
            getToggle.addEventListener('change', function () {
                document.getElementById('sc-get-write-block').style.display = this.checked ? 'block' : 'none';
            });
        }

        // Генерація токена (AJAX)
        var genBtn = document.getElementById('sc-gen-btn');
        if (genBtn) {
            genBtn.addEventListener('click', function () {
                if (!confirm('Згенерувати новий токен? Старий одразу перестане працювати.')) return;
                var self = this;
                self.disabled = true;
                self.innerHTML = ICON_UPDATE_W;
                fetch(ajaxurl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: 'action=solass_claude_gen_token&nonce=' + SC.ajaxNonce
                })
                .then(function (r) { return r.json(); })
                .then(function (d) {
                    if (d.success) {
                        document.getElementById('sc-token-display').textContent = d.data.token;
                        document.getElementById('sc-token-input').value = d.data.token;
                        SC.token = d.data.token;
                        self.innerHTML = ICON_DONE_W;
                        setTimeout(function () { self.innerHTML = ICON_UPDATE_W; self.disabled = false; }, 2000);
                    } else {
                        self.innerHTML = ICON_UPDATE_W;
                        self.disabled = false;
                    }
                });
            });
        }

        // Ping
        var pingBtn = document.getElementById('sc-ping-btn');
        if (pingBtn) {
            pingBtn.addEventListener('click', function () {
                var res = document.getElementById('ping-result');
                res.style.display = 'block';
                res.textContent = 'Запит...';
                fetch(SC.baseUrl + '/ping', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Claude-Token': SC.token, 'X-WP-Nonce': SC.nonce },
                    body: '{}'
                })
                .then(function (r) { return r.json(); })
                .then(function (d) { res.textContent = 'OK\n\n' + JSON.stringify(d.data, null, 2); })
                .catch(function (e) { res.textContent = 'Помилка: ' + e.message; });
            });
        }

        // --- Help-tip: клік/тап відкриває підказку (для тач-екранів) ---
        document.querySelectorAll('.sc-tip').forEach(function (tip) {
            tip.addEventListener('click', function (e) {
                e.stopPropagation();
                var open = tip.classList.contains('is-open');
                document.querySelectorAll('.sc-tip.is-open').forEach(function (t) { t.classList.remove('is-open'); });
                if (!open) tip.classList.add('is-open');
            });
        });
        document.addEventListener('click', function () {
            document.querySelectorAll('.sc-tip.is-open').forEach(function (t) { t.classList.remove('is-open'); });
        });

        // --- Eye-toggle для поля пароля (data-eye + data-target) ---
        // Використовується в page-access.php (GitHub token)
        document.querySelectorAll('[data-eye]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var inp = document.getElementById(this.dataset.eye);
                if (!inp) return;
                var show = inp.type === 'password';
                inp.type = show ? 'text' : 'password';
                var icon = btn.querySelector('.dashicons');
                if (icon) icon.className = 'dashicons ' + (show ? 'dashicons-hidden' : 'dashicons-visibility');
            });
        });

        // --- Копіювання через textarea-fallback (data-copy-ta + data-done) ---
        // Використовується в page-access.php для кнопки "Копіювати дані доступу GitHub"
        document.querySelectorAll('[data-copy-ta]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var src  = document.getElementById(this.dataset.copyTa);
                var done = document.getElementById(this.dataset.done);
                if (!src) return;
                var ok = false;
                try {
                    if (navigator.clipboard && navigator.clipboard.writeText) {
                        navigator.clipboard.writeText(src.value); ok = true;
                    } else {
                        src.style.left = '0'; src.style.top = '0';
                        src.select(); ok = document.execCommand('copy');
                        src.style.left = '-9999px'; src.style.top = '-9999px';
                    }
                } catch (e) { ok = false; }
                if (ok && done) {
                    done.style.display = 'inline';
                    setTimeout(function () { done.style.display = 'none'; }, 2000);
                }
            });
        });

    });

})();
