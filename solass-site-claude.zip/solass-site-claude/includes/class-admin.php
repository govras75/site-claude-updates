<?php
/**
 * SOLASS Site -> Claude — МОДУЛЬ: Адмінка / головна сторінка налаштувань
 * -------------------------------------------------------------------
 * Самостійний модуль. Містить:
 *   - головне меню плагіна + пункт "Налаштування"
 *   - сторінку основних налаштувань (page) з усіма полями
 *   - AJAX генерації токена
 *   - генерацію proxy-файла api.php при збереженні (after_save_settings)
 *   - посилання "Налаштування" у списку плагінів
 *
 * Самореєструється: admin_menu, admin AJAX, update/add_option хуки.
 * Видалення цього файлу прибирає адмінку плагіна (REST продовжує працювати).
 *
 * plugin_file передається в конструктор — для plugin_action_links і шляху api.php.
 * -------------------------------------------------------------------
 */

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'SOLASS_Admin' ) ) :

class SOLASS_Admin {

    private $plugin_file;

    public function __construct( $plugin_file ) {
        $this->plugin_file = $plugin_file;

        add_action( 'admin_menu', [ $this, 'admin_menu' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_scripts' ] );
        add_action( 'wp_ajax_solass_claude_gen_token', [ $this, 'ajax_gen_token' ] );
        add_action( 'update_option_' . SOLASS_Config::OPT, [ $this, 'after_save_settings' ] );
        add_action( 'add_option_' . SOLASS_Config::OPT,    [ $this, 'after_save_settings' ] );
        add_filter( 'plugin_action_links_' . plugin_basename( $plugin_file ), [ $this, 'plugin_links' ] );
    }

    public function enqueue_scripts( string $hook ): void {
        // Тільки на сторінках плагіна
        // Усі сторінки плагіна мають hook, що містить 'solass-claude'
        // (головна, доступи, майбутні). Точний список крихкий, тому перевіряємо входження.
        if ( strpos( $hook, 'solass-claude' ) === false ) return;

        $url = plugin_dir_url( $this->plugin_file );
        $ver = SOLASS_CLAUDE_VERSION;

        wp_enqueue_style(
            'solass-admin',
            $url . 'assets/admin.css',
            [],
            $ver
        );

        wp_enqueue_script(
            'solass-admin',
            $url . 'assets/admin.js',
            [],
            $ver,
            true  // footer
        );

        // Динамічні дані (токен, nonce тощо) → JS об'єкт SC
        $cfg = SOLASS_Config::cfg();
        wp_localize_script( 'solass-admin', 'SC', [
            'token'     => $cfg['token'] ?? '',
            'baseUrl'   => get_rest_url( null, SOLASS_Api::NS ),
            'helpUrl'   => get_rest_url( null, SOLASS_Api::NS ) . '/help',
            'nonce'     => wp_create_nonce( 'wp_rest' ),
            'ajaxNonce' => wp_create_nonce( 'solass_claude_nonce' ),
        ] );
    }

    public function plugin_links(array $links): array {
        array_unshift($links, sprintf(
            '<a href="%s">Налаштування</a>',
            admin_url('admin.php?page=solass-claude')
        ));
        return $links;
    }

    public function admin_menu(): void {
        add_menu_page('SOLASS → Claude', 'SOLASS → Claude', 'manage_options', 'solass-claude', [$this, 'page'], 'dashicons-rest-api', 80);
        add_submenu_page('solass-claude', 'Налаштування', 'Налаштування', 'manage_options', 'solass-claude', [$this, 'page']);
    }

    public function after_save_settings(): void {
        $this->update_api_file();
    }

    public function ajax_gen_token(): void {
        check_ajax_referer('solass_claude_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_die();
        $token = wp_generate_password(48, false);
        $cfg   = SOLASS_Config::cfg();
        $cfg['token'] = $token;
        update_option(SOLASS_Config::OPT, $cfg);
        wp_send_json_success(['token' => $token]);
    }

    public function page(): void {
        $cfg      = SOLASS_Config::cfg();
        $token    = $cfg['token'] ?? '';
        $base_url = get_rest_url(null, SOLASS_Api::NS);
        $help_url = $base_url . '/help';
        $active_s = $cfg['services'] ?? array_keys(SOLASS_Api::SERVICES);
        $get_on   = !empty($cfg['get_enabled']);
        $get_write= !empty($cfg['get_write']);
        ?>
        <div class="wrap sc">
            <h1>
                SOLASS Site → Claude
                <span class="sc-badge <?= empty($cfg['enabled']) ? 'off' : '' ?>"><?= empty($cfg['enabled']) ? 'Вимкнено' : 'v' . SOLASS_CLAUDE_VERSION ?></span>
                <?php if ($get_on): ?>
                    <span class="sc-badge <?= $get_write ? 'warn' : '' ?>">GET <?= $get_write ? '+ запис' : 'активний' ?></span>
                <?php endif; ?>
            </h1>

            <?php if (isset($_GET['settings-updated'])): ?>
                <div class="notice notice-success is-dismissible"><p>Налаштування збережено.</p></div>
            <?php endif; ?>

            <form method="post" action="options.php">
                <?php settings_fields(SOLASS_Config::OPT); ?>

                <div class="sc-grid">
                    <div>

                        <!-- Загальне -->
                        <div class="sc-card">
                            <h2>Загальне</h2>
                            <label style="display:flex;align-items:center;gap:8px;font-size:14px;">
                                <input type="checkbox" name="<?= SOLASS_Config::OPT ?>[enabled]" value="1" <?= checked($cfg['enabled'] ?? 1, 1) ?>>
                                Плагін активний
                            </label>
                        </div>

                        <!-- Токен -->
                        <div class="sc-card">
                            <h2>API Токен</h2>
                            <div class="sc-row">
                                <div class="sc-token" id="sc-token-display"><?= esc_html($token ?: '— не задано —') ?></div>
                                <button type="button" class="sc-copy-icon" id="sc-copy-token" title="Копіювати"><span class="dashicons dashicons-clipboard"></span></button>
                                <button type="button" class="button button-primary" id="sc-gen-btn" title="Згенерувати новий токен" style="display:inline-flex;align-items:center;justify-content:center;width:34px;padding:0;"><span class="dashicons dashicons-update" style="margin:0;color:#fff;font-size:18px;width:18px;height:18px;line-height:1;"></span></button>
                            </div>
                            <input type="hidden" name="<?= SOLASS_Config::OPT ?>[token]" id="sc-token-input" value="<?= esc_attr($token) ?>">
                            <p class="description" style="margin-top:8px;">POST: заголовок <code>X-Claude-Token</code>. GET: параметр <code>?token=</code></p>
                        </div>

                        <!-- GET доступ -->
                        <div class="sc-card">
                            <h2>GET доступ для Claude</h2>

                            <div class="sc-get-block <?= $get_on ? 'active' : '' ?>">
                                <label style="display:flex;align-items:center;gap:8px;font-size:14px;font-weight:500;">
                                    <input type="checkbox" name="<?= SOLASS_Config::OPT ?>[get_enabled]" value="1" id="sc-get-toggle" <?= checked($get_on, true) ?>>
                                    Увімкнути GET-запити
                                </label>
                                <p style="margin:8px 0 0;font-size:12px;color:#666;">
                                    <strong>Для Claude:</strong> вмикай коли хочеш щоб я сам лізав на сервер за твоєю командою з чату. Вимикай коли не потрібно.
                                </p>

                                <div id="sc-get-write-block" style="margin-top:12px;padding-top:12px;border-top:1px solid #e0e0e0;<?= $get_on ? '' : 'display:none' ?>">
                                    <label style="display:flex;align-items:center;gap:8px;font-size:13px;">
                                        <input type="checkbox" name="<?= SOLASS_Config::OPT ?>[get_write]" value="1" <?= checked($get_write, true) ?>>
                                        <span>Дозволити <strong>запис</strong> через GET
                                        <small style="display:block;color:#888;font-weight:normal;">write-file, wp-cli, exec — небезпечніше, вмикай тільки якщо треба</small></span>
                                    </label>
                                </div>
                            </div>

                            <?php if ($get_on): ?>
                                <div class="sc-warn">
                                    <span class="dashicons dashicons-warning" style="color:#f0a500;font-size:18px;vertical-align:middle;margin-right:6px;"></span><strong>GET увімкнено.</strong> Токен передається в URL — він може потрапити в логи сервера. Плагін автоматично маскує токен в логах після кожного запиту.
                                    <?php if ($get_write): ?>
                                        <br><br><span class="dashicons dashicons-warning" style="color:#d63638;font-size:18px;vertical-align:middle;margin-right:6px;"></span><strong>Запис через GET увімкнено</strong> — підвищений ризик. Вимкни коли закінчиш роботу з Claude.
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <div class="sc-info" style="margin-top:10px;">
                                    GET вимкнено — тільки POST з заголовком. Максимальна безпека.
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Access Slug -->
                        <div class="sc-card">
                            <h2>Access Slug для Claude</h2>
                            <?php $access_slug = $cfg['access_slug'] ?? ''; ?>
                            <div class="sc-row">
                                <input type="text" name="<?= SOLASS_Config::OPT ?>[access_slug]" id="sc-slug-input"
                                       value="<?= esc_attr($access_slug) ?>"
                                       class="regular-text code"
                                       placeholder="напр. x7k2m9">
                                <button type="button" class="button" id="sc-gen-slug" title="Згенерувати slug" style="display:inline-flex;align-items:center;justify-content:center;width:34px;padding:0;"><span class="dashicons dashicons-update" style="margin:0;font-size:18px;width:18px;height:18px;line-height:1;"></span></button>
                            </div>
                            <p class="description" style="margin-top:8px;">
                                Короткий секретний рядок для GET доступу без токену в URL.<br>
                                <?php if ($access_slug): ?>
                                Приклад: <code><?= esc_html($base_url . '/' . $access_slug . '/ping') ?></code>
                                <?php endif; ?>
                            </p>
                        </div>

                        <!-- Корінь -->
                        <div class="sc-card">
                            <h2>Корінь для сканування</h2>
                            <input type="text" name="<?= SOLASS_Config::OPT ?>[root_path]" value="<?= esc_attr($cfg['root_path'] ?? '') ?>" class="large-text code" placeholder="<?= esc_attr(ABSPATH) ?>">
                            <p class="description">Claude читає файли починаючи з цієї папки. Default: корінь WP (<code><?= esc_html(ABSPATH) ?></code>)</p>
                        </div>

                        <!-- Лог -->
                        <div class="sc-card">
                            <h2>Шлях до лог-файлу</h2>
                            <input type="text" name="<?= SOLASS_Config::OPT ?>[log_path]" value="<?= esc_attr($cfg['log_path'] ?? '') ?>" class="large-text code" placeholder="<?= esc_attr(WP_CONTENT_DIR) ?>/debug.log">
                        </div>

                        <!-- IP -->
                        <div class="sc-card">
                            <h2>Дозволені IP</h2>
                            <textarea name="<?= SOLASS_Config::OPT ?>[allowed_ips]" class="large-text code" rows="4"
                                placeholder="# Порожньо = всі дозволені (захист через токен)&#10;# Один IP на рядок, # = коментар&#10;1.2.3.4"><?= esc_textarea($cfg['allowed_ips'] ?? '') ?></textarea>
                            <div class="sc-ip-note">
                                <strong>Порожньо</strong> → всі IP + правильний токен<br>
                                <strong>Є IP</strong> → тільки він + правильний токен
                            </div>
                        </div>

                    </div>
                    <div>

                        <!-- Сервіси -->
                        <div class="sc-card">
                            <h2>Активні сервіси</h2>
                            <div class="sc-services">
                                <?php foreach (SOLASS_Api::SERVICES as $slug => [$label, $params]):
                                    $is_write = in_array($slug, SOLASS_Api::WRITE_CMDS); ?>
                                    <label>
                                        <input type="checkbox" name="<?= SOLASS_Config::OPT ?>[services][]" value="<?= esc_attr($slug) ?>" <?= in_array($slug, $active_s) ? 'checked' : '' ?>>
                                        <span>
                                            <code style="font-size:11px;<?= $is_write ? 'background:#fff3e0;color:#e65100;' : '' ?>"><?= esc_html($slug) ?></code><br>
                                            <small style="color:#666"><?= esc_html($label) ?></small>
                                        </span>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                            <p style="margin-top:10px;font-size:12px;">
                                <a href="#" onclick="document.querySelectorAll('.sc-services input').forEach(i=>i.checked=true);return false">Всі</a> |
                                <a href="#" onclick="document.querySelectorAll('.sc-services input').forEach(i=>i.checked=false);return false">Жодного</a>
                            </p>
                            <p class="description">Виділені команди — запис. Через GET доступні тільки якщо увімкнено "Дозволити запис через GET".</p>
                        </div>

                        <!-- Тест -->
                        <div class="sc-card">
                            <h2>Тест з'єднання</h2>
                            <button type="button" class="button button-primary" id="sc-ping-btn" style="display:inline-flex;align-items:center;gap:4px;"><span class="dashicons dashicons-controls-play" style="margin:0;color:#fff;font-size:16px;width:16px;height:16px;line-height:1.1;"></span> Ping</button>
                            <div id="ping-result"></div>
                        </div>

                    </div>
                </div>

                <?php submit_button('Зберегти'); ?>
            </form>

            <!-- ЗА МЕЖАМИ ФОРМИ -->
            <div class="sc-card">
                <h2>API для Claude</h2>
                <div class="sc-row">
                    <div class="sc-url"><?= esc_url($base_url) ?></div>
                    <button type="button" class="sc-copy-icon" data-copy="<?= esc_attr($base_url) ?>" title="Копіювати"><span class="dashicons dashicons-clipboard"></span></button>
                    <button type="button" class="button button-primary" id="sc-copy-claude" style="display:inline-flex;align-items:center;gap:6px;"><span class="dashicons dashicons-clipboard" style="margin:0;color:#fff;font-size:16px;width:16px;height:16px;line-height:1.1;"></span> Для Claude</button>
                </div>

                <div class="sc-info" style="margin-top:12px;">
                    <strong>Help URL (публічний):</strong>
                    <div class="sc-row" style="margin-top:6px;">
                        <div class="sc-url"><?= esc_url($help_url) ?></div>
                        <button type="button" class="sc-copy-icon" data-copy="<?= esc_attr($help_url) ?>" title="Копіювати"><span class="dashicons dashicons-clipboard"></span></button>
                    </div>
                </div>

                <?php
                $access_slug_val = $cfg['access_slug'] ?? '';
                if ($get_on && $access_slug_val): ?>
                <div style="margin-top:12px;">
                    <p style="font-size:13px;font-weight:500;margin-bottom:8px;">GET URL для Claude (через Access Slug):</p>
                    <?php
                    $examples = [
                        'ping'           => '',
                        'wp-info'        => '',
                        'server-info'    => '',
                        'list-dir'       => '?path=wp-content/themes',
                        'find-files'     => '?path=wp-content/themes&pattern=*.css',
                        'tree'           => '?path=wp-content/plugins&depth=2',
                        'read-file'      => '?path=wp-content/themes/' . get_stylesheet() . '/style.css',
                        'get-log'        => '?lines=50',
                        'active-plugins' => '',
                    ];
                    foreach ($examples as $ep => $extra):
                        $url = $base_url . '/' . $access_slug_val . '/' . $ep . ($extra ?: '');
                    ?>
                    <div class="sc-row" style="margin-bottom:4px;">
                        <div class="sc-url"><?= esc_html($url) ?></div>
                        <button type="button" class="sc-copy-icon" data-copy="<?= esc_attr($url) ?>" title="Копіювати"><span class="dashicons dashicons-clipboard"></span></button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php elseif ($get_on && !$access_slug_val): ?>
                <div class="sc-info" style="margin-top:12px;border-left-color:#f0a500;">
                    Задай <strong>Access Slug</strong> вище і збережи — тут з'являться GET URL для Claude.
                </div>
                <?php else: ?>
                <div class="sc-info" style="margin-top:12px;border-left-color:#888;">
                    GET вимкнено — увімкни GET щоб побачити URL для Claude.
                </div>
                <?php endif; ?>
            </div>

        </div>

        <?php
    }

    private function update_api_file(): void {
        $cfg  = SOLASS_Config::cfg();
        $slug = trim($cfg['access_slug'] ?? '');
        $file = plugin_dir_path($this->plugin_file) . 'api.php';

        if (empty($slug) || empty($cfg['enabled'])) {
            // Видаляємо файл якщо slug не задано або плагін вимкнено
            if (file_exists($file)) unlink($file);
            return;
        }

        $site_url  = get_rest_url(null, 'solass-claude/v1');
        $token     = $cfg['token'] ?? '';
        $get_write = !empty($cfg['get_write']) ? 'true' : 'false';

        $php = <<<PHPCODE
<?php
/**
 * SOLASS Site -> Claude — API Proxy
 * Auto-generated. Do not edit manually.
 * URL: {$_SERVER['HTTP_HOST']}/wp-content/plugins/solass-site-claude/api.php/SLUG/endpoint
 */

define('SC_SLUG',      '{$slug}');
define('SC_TOKEN',     '{$token}');
define('SC_API_BASE',  '{$site_url}');
define('SC_GET_WRITE', {$get_write});

// Парсимо PATH_INFO: /SLUG/endpoint
\$path = trim(\$_SERVER['PATH_INFO'] ?? parse_url(\$_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
\$path = preg_replace('#^.*api\.php/?#', '', \$path);
\$parts = explode('/', ltrim(\$path, '/'), 2);
\$req_slug    = \$parts[0] ?? '';
\$req_endpoint= \$parts[1] ?? '';

if (\$req_slug !== SC_SLUG || empty(\$req_endpoint)) {
    http_response_code(404);
    die(json_encode(['error' => 'Not found']));
}

// Команди запису — тільки якщо дозволено
\$write_cmds = ['write-file', 'wp-cli', 'exec'];
if (in_array(\$req_endpoint, \$write_cmds) && !SC_GET_WRITE) {
    http_response_code(403);
    die(json_encode(['error' => 'Write commands disabled']));
}

// Збираємо параметри з GET
\$params = \$_GET;
unset(\$params['_path']);

// Проксі запит до WP REST API
\$url = SC_API_BASE . '/' . \$req_endpoint;
if (!empty(\$params)) \$url .= '?' . http_build_query(\$params);

\$ch = curl_init(\$url);
curl_setopt_array(\$ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => 30,
    CURLOPT_HTTPHEADER     => [
        'X-Claude-Token: ' . SC_TOKEN,
        'Content-Type: application/json',
    ],
    CURLOPT_SSL_VERIFYPEER => false,
]);
\$response = curl_exec(\$ch);
\$code      = curl_getinfo(\$ch, CURLINFO_HTTP_CODE);
curl_close(\$ch);

http_response_code(\$code);
header('Content-Type: application/json; charset=utf-8');
echo \$response;
PHPCODE;

        file_put_contents($file, $php);
    }
}

endif;
