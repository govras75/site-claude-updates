<?php
/**
 * SOLASS Site -> Claude — МОДУЛЬ: Команди / управління хостом
 * -------------------------------------------------------------------
 * Самостійний модуль REST API. Містить:
 *   - реєстрацію всіх маршрутів (token-доступ + slug-доступ)
 *   - авторизацію (auth, auth_slug)
 *   - усі базові команди роботи з хостом (action_*)
 *   - маскування токена в логах, лог запитів
 *
 * Самореєструється на rest_api_init. Видалення цього файлу прибирає
 * увесь REST-функціонал, не зачіпаючи ядро та інші модулі.
 *
 * Ядро викликається статично: SOLASS_Config::cfg(), SOLASS_Utils::ok().
 * -------------------------------------------------------------------
 */

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'SOLASS_Api' ) ) :

class SOLASS_Api {

    const NS         = 'solass-claude/v1';
    const SLUG_LENGTH = 8;

    const PROTECTED_FILES = ['wp-config.php', 'wp-config-sample.php', '.htaccess', 'wp-settings.php', 'wp-load.php', 'wp-blog-header.php', 'wp-cron.php', 'xmlrpc.php'];
    const PROTECTED_DIRS  = ['wp-admin', 'wp-includes'];

    const READ_ONLY = ['ping', 'server-info', 'disk-usage', 'list-dir', 'find-files', 'tree', 'get-log', 'wp-info', 'check-url', 'active-plugins', 'read-file', 'site-state', 'read-file-chunk', 'tail-file', 'get-access'];
    const WRITE_CMDS = ['write-file', 'wp-cli', 'exec'];

    const SERVICES = [
        'ping'           => ['Ping — перевірка з\'єднання',                 []],
        'server-info'    => ['Інфо про сервер (PHP, OS, пам\'ять, uptime)', []],
        'disk-usage'     => ['Використання диску',                          ['path? (default /)']],
        'read-file'      => ['Читати вміст файлу',                          ['path']],
        'write-file'     => ['Записати файл (з автобекапом)',               ['path', 'content']],
        'list-dir'       => ['Список файлів у директорії',                  ['path']],
        'find-files'     => ['Пошук файлів по масці рекурсивно',            ['path', 'pattern (напр. *.php)', 'depth? (default 5)']],
        'tree'           => ['Дерево папок',                                ['path', 'depth? (default 3)']],
        'get-log'        => ['Читати лог-файл (tail)',                      ['path?', 'lines? (default 50)']],
        'wp-info'        => ['Інфо про WordPress',                          []],
        'wp-cli'         => ['Виконати WP-CLI команду',                     ['command — без "wp"']],
        'check-url'      => ['Перевірити доступність URL',                  ['url']],
        'active-plugins' => ['Список активних плагінів',                    []],
        'exec'           => ['Виконати shell-команду',                      ['cmd']],
        'site-state'     => ['Повний знімок сайту одним запитом',           []],
        'read-file-chunk'=> ['Читати файл шматками (offset/limit)',          ['path', 'offset? (default 0)', 'limit? (default 50000)']],
        'tail-file'      => ['Хвіст лог-файлу (tail)',                       ['path?', 'lines? (default 100)']],
        'force-update'   => ['Примусово оновити плагін з GitHub',            []],
        'get-access'     => ['Дані доступу до GitHub-репо (owner/repo/branch + токен)', []],
        // 'flush-cache' — примусова свіжа перевірка оновлень (force_check).
        // Зайвий: WP сам покаже оновлення коли мине timeout (плагіни 1 год),
        // а після force-update force_check викликається автоматично.
        // Щоб увімкнути: розкоментувати рядок нижче + додати 'flush-cache' у READ_ONLY,
        // прив'язка до методу action_flush_cache() (нижче, теж закоментований).
        // 'flush-cache'    => ['Примусова свіжа перевірка оновлень', []],
    ];

    private $updater;

    public function __construct( $updater = null ) {
        $this->updater = $updater;
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    public function register_routes(): void {
        // /help — завжди публічний GET
        register_rest_route(self::NS, '/help', [
            'methods'             => ['GET', 'POST'],
            'callback'            => [$this, 'action_help'],
            'permission_callback' => '__return_true',
        ]);

        // /discover/SLUG — публічний, завжди реєструємо
        register_rest_route(self::NS, '/discover/(?P<slug>[a-zA-Z0-9_-]+)', [
            'methods'             => 'GET',
            'callback'            => [$this, 'action_discover'],
            'permission_callback' => '__return_true',
        ]);

        $cfg = SOLASS_Config::cfg();
        if (empty($cfg['enabled'])) return;

        $active  = $cfg['services'] ?? array_keys(self::SERVICES);
        $get_on  = !empty($cfg['get_enabled']);

        // Slug маршрути: /SLUG/endpoint
        $this->register_slug_routes();

        foreach (self::SERVICES as $slug => $_) {
            if (!in_array($slug, $active)) continue;
            register_rest_route(self::NS, '/' . $slug, [
                'methods'             => $get_on ? ['GET', 'POST'] : 'POST',
                'callback'            => [$this, 'action_' . str_replace('-', '_', $slug)],
                'permission_callback' => [$this, 'auth'],
            ]);
        }
    }

    private function register_slug_routes(): void {
        $cfg  = SOLASS_Config::cfg();
        $slug = trim($cfg['access_slug'] ?? '');
        if (empty($slug) || empty($cfg['get_enabled'])) return;

        $active = $cfg['services'] ?? array_keys(self::SERVICES);

        foreach (self::SERVICES as $service => $_) {
            if (!in_array($service, $active)) continue;
            // Маршрут: /ACCESS_SLUG/endpoint
            register_rest_route(self::NS, '/' . preg_quote($slug, '/') . '/' . $service, [
                'methods'             => 'GET',
                'callback'            => [$this, 'action_' . str_replace('-', '_', $service)],
                'permission_callback' => [$this, 'auth_slug'],
            ]);
        }
    }

    public function auth(WP_REST_Request $r){
        $cfg   = SOLASS_Config::cfg();
        $token = $cfg['token'] ?? '';

        if (empty($token))
            return new WP_Error('no_token', 'Token not configured', ['status' => 500]);

        // Токен з заголовку (POST) або GET-параметра
        $provided = $r->get_header('X-Claude-Token') ?: $r->get_param('token');
        if ($provided !== $token)
            return new WP_Error('bad_token', 'Invalid token', ['status' => 401]);

        // IP фільтр
        $ips = array_filter(
            array_map('trim', explode("\n", $cfg['allowed_ips'] ?? '')),
            fn($l) => $l !== '' && $l[0] !== '#'
        );
        if (!empty($ips) && !in_array($_SERVER['REMOTE_ADDR'] ?? '', $ips))
            return new WP_Error('bad_ip', 'IP not allowed: ' . ($_SERVER['REMOTE_ADDR'] ?? ''), ['status' => 403]);

        // GET-запит — перевіряємо чи дозволений
        if ($r->get_method() === 'GET') {
            if (empty($cfg['get_enabled']))
                return new WP_Error('get_disabled', 'GET requests are disabled', ['status' => 405]);

            // Команди запису через GET — тільки якщо явно дозволено
            $slug = basename($r->get_route());
            if (in_array($slug, self::WRITE_CMDS) && empty($cfg['get_write']))
                return new WP_Error('get_write_disabled', 'Write commands via GET are disabled', ['status' => 403]);

            // Маскуємо токен в логах після авторизації
            $this->mask_token_in_logs($token);
        }

        $this->log_req($r->get_route(), $r->get_method());
        return true;
    }

    public function auth_slug(WP_REST_Request $r){
        $cfg  = SOLASS_Config::cfg();
        $slug = trim($cfg['access_slug'] ?? '');

        if (empty($slug))
            return new WP_Error('no_slug', 'Access slug not configured', ['status' => 500]);

        // IP фільтр
        $ips = array_filter(
            array_map('trim', explode("
", $cfg['allowed_ips'] ?? '')),
            fn($l) => $l !== '' && $l[0] !== '#'
        );
        if (!empty($ips) && !in_array($_SERVER['REMOTE_ADDR'] ?? '', $ips))
            return new WP_Error('bad_ip', 'IP not allowed: ' . ($_SERVER['REMOTE_ADDR'] ?? ''), ['status' => 403]);

        // Команди запису — тільки якщо дозволено
        $endpoint = basename(parse_url($r->get_route(), PHP_URL_PATH));
        if (in_array($endpoint, self::WRITE_CMDS) && empty($cfg['get_write']))
            return new WP_Error('write_disabled', 'Write commands disabled for slug access', ['status' => 403]);

        $this->log_req($r->get_route(), 'GET-SLUG');
        return true;
    }

    private function mask_token_in_logs(string $token): void {
        if (empty($token) || strlen($token) < 8) return;

        // Шукаємо можливі лог-файли
        $log_candidates = array_filter([
            ini_get('error_log'),
            WP_CONTENT_DIR . '/debug.log',
            // Nginx/Apache access logs — типові шляхи
            '/var/log/nginx/access.log',
            '/var/log/apache2/access.log',
            '/var/log/httpd/access_log',
            '/www/wwwlogs/' . parse_url(get_bloginfo('url'), PHP_URL_HOST) . '.log',
        ], fn($f) => $f && file_exists($f) && is_writable($f));

        foreach ($log_candidates as $log_file) {
            try {
                // Читаємо тільки останні 200 рядків щоб не вантажити пам'ять
                $lines = [];
                $handle = fopen($log_file, 'r+');
                if (!$handle) continue;

                // Отримуємо розмір файлу
                fseek($handle, 0, SEEK_END);
                $size = ftell($handle);
                if ($size === 0) { fclose($handle); continue; }

                // Читаємо останні ~20KB
                $chunk_size = min($size, 20480);
                fseek($handle, -$chunk_size, SEEK_END);
                $chunk = fread($handle, $chunk_size);
                fclose($handle);

                // Замінюємо токен на ***
                if (strpos($chunk, $token) !== false) {
                    $masked = str_replace($token, str_repeat('*', 8), $chunk);
                    // Перезаписуємо тільки останній chunk
                    $handle = fopen($log_file, 'r+');
                    fseek($handle, -$chunk_size, SEEK_END);
                    fwrite($handle, $masked);
                    fclose($handle);
                }
            } catch (\Throwable $e) {
                // Тихо пропускаємо помилки логування
            }
        }
    }

    public function action_help(WP_REST_Request $r): WP_REST_Response {
        $cfg    = SOLASS_Config::cfg();
        $active = $cfg['services'] ?? array_keys(self::SERVICES);
        $base   = get_rest_url(null, self::NS);
        $get_on = !empty($cfg['get_enabled']);
        $cmds   = [];
        foreach (self::SERVICES as $slug => [$label, $params]) {
            $is_write = in_array($slug, self::WRITE_CMDS);
            $cmds[$slug] = [
                'endpoint'  => $base . '/' . $slug,
                'label'     => $label,
                'params'    => $params,
                'enabled'   => in_array($slug, $active),
                'via_get'   => $get_on && (!$is_write || !empty($cfg['get_write'])),
                'write_cmd' => $is_write,
            ];
        }
        return SOLASS_Utils::ok([
            'plugin'    => 'SOLASS Site → Claude v' . SOLASS_CLAUDE_VERSION,
            'site'      => get_bloginfo('url'),
            'base_url'  => $base,
            'wp'        => get_bloginfo('version'),
            'php'       => PHP_VERSION,
            'root'      => SOLASS_Config::root(),
            'get_mode'  => $get_on ? (!empty($cfg['get_write']) ? 'enabled+write' : 'enabled+readonly') : 'disabled',
            'note'      => 'GET з токеном в шляху: /endpoint/TOKEN (напр. /ping/' . substr($token, 0, 8) . '...)',
            'commands'  => $cmds,
        ]);
    }

    public function action_discover(WP_REST_Request $r): WP_REST_Response {
        $cfg  = SOLASS_Config::cfg();
        $slug = trim($cfg['access_slug'] ?? '');
        $token = $cfg['token'] ?? '';

        // Перевіряємо slug
        if (empty($slug) || $r->get_param('slug') !== $slug) {
            return new WP_REST_Response(['error' => 'Invalid slug'], 403);
        }

        if (empty($cfg['enabled'])) {
            return new WP_REST_Response(['error' => 'Plugin disabled'], 403);
        }

        $base     = get_rest_url(null, self::NS);
        $active   = $cfg['services'] ?? array_keys(self::SERVICES);
        $get_on   = !empty($cfg['get_enabled']);
        $get_write= !empty($cfg['get_write']);

        // Приклади параметрів для кожного ендпоінту
        $examples = [
            'ping'           => [],
            'server-info'    => [],
            'disk-usage'     => [],
            'wp-info'        => [],
            'active-plugins' => [],
            'list-dir'       => ['path' => 'wp-content/themes'],
            'find-files'     => ['path' => 'wp-content', 'pattern' => '*.php', 'depth' => '3'],
            'tree'           => ['path' => 'wp-content', 'depth' => '2'],
            'get-log'        => ['lines' => '50'],
            'read-file'      => ['path' => 'wp-content/themes/' . get_stylesheet() . '/functions.php'],
            'check-url'      => ['url' => get_bloginfo('url')],
            'write-file'     => ['path' => 'wp-content/test.txt', 'content' => 'test'],
            'wp-cli'         => ['command' => 'plugin list'],
            'exec'           => ['cmd' => 'whoami'],
        ];

        $urls = [];
        foreach (self::SERVICES as $service => [$label, $params]) {
            if (!in_array($service, $active)) continue;

            $is_write = in_array($service, self::WRITE_CMDS);
            if ($is_write && !$get_write) continue;
            if (!$get_on && $is_write) continue;

            // Будуємо GET URL з токеном
            $query = ['token' => $token];
            if (!empty($examples[$service])) {
                $query = array_merge($query, $examples[$service]);
            }
            $url = $base . '/' . $service . '?' . http_build_query($query);

            $urls[$service] = [
                'label'   => $label,
                'url'     => $url,
                'params'  => $params,
                'write'   => $is_write,
            ];
        }

        return SOLASS_Utils::ok([
            'plugin'    => 'SOLASS Site → Claude v' . SOLASS_CLAUDE_VERSION,
            'site'      => get_bloginfo('url'),
            'wp'        => get_bloginfo('version'),
            'php'       => PHP_VERSION,
            'root'      => SOLASS_Config::root(),
            'abspath'   => ABSPATH,
            'time'      => current_time('Y-m-d H:i:s'),
            'note'      => 'Це приватний endpoint для Claude. Всі URL нижче готові до використання.',
            'endpoints' => $urls,
        ]);
    }

    public function action_ping(): WP_REST_Response {
        return SOLASS_Utils::ok(['pong' => true, 'site' => get_bloginfo('url'), 'time' => current_time('Y-m-d H:i:s'), 'plugin' => SOLASS_CLAUDE_VERSION]);
    }

    public function action_server_info(): WP_REST_Response {
        return SOLASS_Utils::ok([
            'php'      => PHP_VERSION,
            'os'       => php_uname('s') . ' ' . php_uname('r'),
            'memory'   => ini_get('memory_limit'),
            'max_exec' => ini_get('max_execution_time'),
            'load'     => sys_getloadavg(),
            'uptime'   => trim(shell_exec('uptime -p') ?? ''),
            'mysql'    => SOLASS_Utils::mysql_ver(),
        ]);
    }

    public function action_disk_usage(WP_REST_Request $r): WP_REST_Response {
        $path  = $r->get_param('path') ?: '/';
        $total = disk_total_space($path);
        $free  = disk_free_space($path);
        return SOLASS_Utils::ok(['path' => $path, 'total' => SOLASS_Utils::fmt($total), 'free' => SOLASS_Utils::fmt($free), 'used' => SOLASS_Utils::fmt($total - $free), 'used_pct' => round((1 - $free / $total) * 100, 1) . '%']);
    }

    public function action_read_file(WP_REST_Request $r): WP_REST_Response {
        $f = SOLASS_Utils::vpath($r->get_param('path'), SOLASS_Config::root());
        if (is_wp_error($f)) return SOLASS_Utils::err($f->get_error_message());
        if (!file_exists($f)) return SOLASS_Utils::err("Not found: {$f}");
        $content = SOLASS_Utils::redact_secrets($f, file_get_contents($f));
        return SOLASS_Utils::ok(['path' => $f, 'content' => $content, 'size' => SOLASS_Utils::fmt(filesize($f)), 'modified' => date('Y-m-d H:i:s', filemtime($f))]);
    }

    public function action_write_file(WP_REST_Request $r): WP_REST_Response {
        $f = SOLASS_Utils::vpath($r->get_param('path'), SOLASS_Config::root());
        if (is_wp_error($f)) return SOLASS_Utils::err($f->get_error_message());
        if (SOLASS_Utils::is_protected_write($f, SOLASS_Config::root(), self::PROTECTED_FILES, self::PROTECTED_DIRS)) return SOLASS_Utils::err('Захищений файл, запис заблоковано: ' . basename($f));
        $backup = null;
        if (file_exists($f)) { $backup = $f . '.bak_' . date('Ymd_His'); copy($f, $backup); }
        $bytes = file_put_contents($f, $r->get_param('content') ?? '');
        if ($bytes === false) return SOLASS_Utils::err("Cannot write: {$f}");
        return SOLASS_Utils::ok(['path' => $f, 'bytes' => $bytes, 'backup' => $backup]);
    }

    public function action_list_dir(WP_REST_Request $r): WP_REST_Response {
        $d = SOLASS_Utils::vpath($r->get_param('path') ?: SOLASS_Config::root(), SOLASS_Config::root());
        if (is_wp_error($d)) return SOLASS_Utils::err($d->get_error_message());
        if (!is_dir($d)) return SOLASS_Utils::err("Not a dir: {$d}");
        $items = [];
        foreach (scandir($d) as $name) {
            if ($name === '.' || $name === '..') continue;
            $full    = $d . '/' . $name;
            $items[] = ['name' => $name, 'type' => is_dir($full) ? 'dir' : 'file', 'size' => is_file($full) ? SOLASS_Utils::fmt(filesize($full)) : null, 'modified' => date('Y-m-d H:i:s', filemtime($full))];
        }
        return SOLASS_Utils::ok(['path' => $d, 'count' => count($items), 'items' => $items]);
    }

    public function action_find_files(WP_REST_Request $r): WP_REST_Response {
        $path    = SOLASS_Utils::vpath($r->get_param('path') ?: SOLASS_Config::root(), SOLASS_Config::root());
        if (is_wp_error($path)) return SOLASS_Utils::err($path->get_error_message());
        $pattern = $r->get_param('pattern') ?: '*';
        $depth   = min((int)($r->get_param('depth') ?: 5), 10);
        $results = [];
        SOLASS_Utils::find_recursive($path, $pattern, $depth, 0, $results);
        return SOLASS_Utils::ok(['path' => $path, 'pattern' => $pattern, 'count' => count($results), 'files' => $results]);
    }

    public function action_tree(WP_REST_Request $r): WP_REST_Response {
        $path  = SOLASS_Utils::vpath($r->get_param('path') ?: SOLASS_Config::root(), SOLASS_Config::root());
        if (is_wp_error($path)) return SOLASS_Utils::err($path->get_error_message());
        $depth = min((int)($r->get_param('depth') ?: 3), 6);
        return SOLASS_Utils::ok(['path' => $path, 'depth' => $depth, 'tree' => SOLASS_Utils::build_tree($path, $depth, 0)]);
    }

    public function action_get_log(WP_REST_Request $r): WP_REST_Response {
        $cfg   = SOLASS_Config::cfg();
        $file  = $r->get_param('path') ?: ($cfg['log_path'] ?: WP_CONTENT_DIR . '/debug.log');
        $lines = (int)($r->get_param('lines') ?: 50);
        $f     = SOLASS_Utils::vpath($file, SOLASS_Config::root());
        if (is_wp_error($f)) return SOLASS_Utils::err($f->get_error_message());
        if (!file_exists($f)) return SOLASS_Utils::err("Log not found: {$f}");
        return SOLASS_Utils::ok(['path' => $f, 'lines' => $lines, 'content' => shell_exec("tail -n {$lines} " . escapeshellarg($f))]);
    }

    public function action_wp_info(): WP_REST_Response {
        global $wpdb;
        return SOLASS_Utils::ok(['site' => get_bloginfo('url'), 'wp' => get_bloginfo('version'), 'theme' => get_stylesheet(), 'plugins_active' => count(get_option('active_plugins', [])), 'users' => count_users()['total_users'], 'posts' => wp_count_posts()->publish, 'db_prefix' => $wpdb->prefix, 'debug' => defined('WP_DEBUG') && WP_DEBUG, 'abspath' => ABSPATH, 'root' => SOLASS_Config::root()]);
    }

    public function action_wp_cli(WP_REST_Request $r): WP_REST_Response {
        $cmd = trim($r->get_param('command') ?? '');
        if (!$cmd) return SOLASS_Utils::err('command required');
        foreach (['db drop', 'db reset', 'user delete', 'core download', 'plugin delete'] as $b)
            if (stripos($cmd, $b) !== false) return SOLASS_Utils::err("Blocked: {$b}");
        return SOLASS_Utils::ok(['command' => $cmd, 'output' => shell_exec('/usr/local/bin/wp --path=' . escapeshellarg(ABSPATH) . ' --allow-root ' . $cmd . ' 2>&1')]);
    }

    public function action_check_url(WP_REST_Request $r): WP_REST_Response {
        $url = $r->get_param('url') ?? '';
        if (!filter_var($url, FILTER_VALIDATE_URL)) return SOLASS_Utils::err('Invalid URL');
        $res = wp_remote_get($url, ['timeout' => 10, 'sslverify' => false]);
        if (is_wp_error($res)) return SOLASS_Utils::err($res->get_error_message());
        return SOLASS_Utils::ok(['url' => $url, 'code' => wp_remote_retrieve_response_code($res), 'body_len' => strlen(wp_remote_retrieve_body($res))]);
    }

    public function action_active_plugins(): WP_REST_Response {
        $active  = get_option('active_plugins', []);
        $plugins = get_plugins();
        $result  = [];
        foreach ($active as $slug) {
            $i = $plugins[$slug] ?? [];
            $result[] = ['slug' => $slug, 'name' => $i['Name'] ?? $slug, 'version' => $i['Version'] ?? '?', 'author' => $i['Author'] ?? '?'];
        }
        return SOLASS_Utils::ok($result);
    }

    public function action_exec(WP_REST_Request $r): WP_REST_Response {
        $cmd = $r->get_param('cmd') ?? '';
        if (!$cmd) return SOLASS_Utils::err('cmd required');
        return SOLASS_Utils::ok(['cmd' => $cmd, 'output' => shell_exec($cmd . ' 2>&1')]);
    }

    public function action_site_state(): WP_REST_Response {
        global $wpdb;

        // Версії і середовище
        $state = [
            'plugin'       => 'SOLASS Site → Claude v' . SOLASS_CLAUDE_VERSION,
            'site'         => get_bloginfo('url'),
            'time'         => current_time('Y-m-d H:i:s'),
            'wp'           => get_bloginfo('version'),
            'php'          => PHP_VERSION,
            'mysql'        => SOLASS_Utils::mysql_ver(),
            'memory_limit' => ini_get('memory_limit'),
            'memory_usage' => SOLASS_Utils::fmt(memory_get_usage(true)),
            'max_exec'     => ini_get('max_execution_time'),
            'wp_debug'     => defined('WP_DEBUG') && WP_DEBUG,
            'abspath'      => ABSPATH,
            'root'         => SOLASS_Config::root(),
            'db_prefix'    => $wpdb->prefix,
        ];

        // Диск
        $free  = disk_free_space('/');
        $total = disk_total_space('/');
        $state['disk'] = [
            'total'    => SOLASS_Utils::fmt($total),
            'free'     => SOLASS_Utils::fmt($free),
            'used'     => SOLASS_Utils::fmt($total - $free),
            'used_pct' => round((1 - $free / $total) * 100, 1) . '%',
        ];

        // Тема
        $state['theme'] = get_stylesheet();

        // Активні плагіни (slug => версія)
        $active  = get_option('active_plugins', []);
        $plugins = get_plugins();
        $active_list = [];
        foreach ($active as $slug) {
            $active_list[$slug] = $plugins[$slug]['Version'] ?? '?';
        }
        $state['active_plugins'] = $active_list;
        $state['plugins_count']  = count($active);

        // Кеш-плагіни
        $cache_plugins = ['w3-total-cache', 'wp-super-cache', 'wp-rocket', 'litespeed-cache', 'wp-fastest-cache', 'redis-cache', 'object-cache-pro'];
        $state['cache_plugins'] = array_values(array_filter($cache_plugins, fn($p) => isset($active_list[$p . '/' . $p . '.php']) || isset($active_list[$p . '/wp-cache.php'])));

        // Останні помилки з debug.log (якщо є)
        $log = WP_CONTENT_DIR . '/debug.log';
        if (file_exists($log)) {
            $lines = array_filter(explode("\n", shell_exec("tail -n 30 " . escapeshellarg($log)) ?? ''));
            $errors = array_values(array_filter($lines, fn($l) => strpos($l, 'PHP Fatal') !== false || strpos($l, 'PHP Error') !== false));
            $state['last_errors'] = array_slice($errors, -5);
        } else {
            $state['last_errors'] = [];
        }

        // Версія плагіна в GitHub (з кешованого info.json)
        $info = $this->updater->fetch_update_info();
        $state['update'] = [
            'current'    => SOLASS_CLAUDE_VERSION,
            'available'  => $info['version'] ?? null,
            'has_update' => $info ? version_compare($info['version'] ?? '0', SOLASS_CLAUDE_VERSION, '>') : false,
        ];

        return SOLASS_Utils::ok($state);
    }

    public function action_read_file_chunk(WP_REST_Request $r): WP_REST_Response {
        $f = SOLASS_Utils::vpath($r->get_param('path'), SOLASS_Config::root());
        if (is_wp_error($f)) return SOLASS_Utils::err($f->get_error_message());
        if (!file_exists($f)) return SOLASS_Utils::err("Not found: {$f}");

        $offset = max(0, (int) ($r->get_param('offset') ?? 0));
        $limit  = min(200000, max(1000, (int) ($r->get_param('limit') ?? 50000)));
        $size   = filesize($f);

        $handle = fopen($f, 'r');
        if (!$handle) return SOLASS_Utils::err("Cannot open: {$f}");
        if ($offset > 0) fseek($handle, $offset);
        $chunk = fread($handle, $limit);
        fclose($handle);

        $chunk = SOLASS_Utils::redact_secrets($f, $chunk);

        return SOLASS_Utils::ok([
            'path'      => $f,
            'size'      => SOLASS_Utils::fmt($size),
            'size_bytes'=> $size,
            'offset'    => $offset,
            'limit'     => $limit,
            'read_bytes'=> strlen($chunk),
            'has_more'  => ($offset + $limit) < $size,
            'next_offset'=> min($offset + $limit, $size),
            'content'   => $chunk,
        ]);
    }

    public function action_tail_file(WP_REST_Request $r): WP_REST_Response {
        $cfg   = SOLASS_Config::cfg();
        $path  = $r->get_param('path') ?: ($cfg['log_path'] ?: WP_CONTENT_DIR . '/debug.log');
        $lines = min(500, max(1, (int) ($r->get_param('lines') ?? 100)));

        $f = SOLASS_Utils::vpath($path, SOLASS_Config::root());
        if (is_wp_error($f)) return SOLASS_Utils::err($f->get_error_message());
        if (!file_exists($f)) return SOLASS_Utils::err("File not found: {$f}");

        $content = shell_exec("tail -n {$lines} " . escapeshellarg($f));
        return SOLASS_Utils::ok([
            'path'    => $f,
            'lines'   => $lines,
            'size'    => SOLASS_Utils::fmt(filesize($f)),
            'content' => $content ?? '',
        ]);
    }

    public function action_force_update(): WP_REST_Response {
        $result = $this->updater->run_update();
        return SOLASS_Utils::ok($result);
    }

    public function action_get_access(): WP_REST_Response {
        $gh = SOLASS_Config::cfg_github();
        return SOLASS_Utils::ok([
            'owner'      => $gh['gh_owner'] ?? '',
            'repo'       => $gh['gh_repo'] ?? '',
            'branch'     => ($gh['gh_branch'] ?? '') ?: 'main',
            'token'      => $gh['gh_token'] ?? '',
            'configured' => !empty($gh['gh_owner']) && !empty($gh['gh_repo']) && !empty($gh['gh_token']),
        ]);
    }

    private function log_req(string $route, string $method = 'POST'): void {
        $log = get_option(SOLASS_Config::OPT . '_log', []);
        array_unshift($log, ['t' => current_time('Y-m-d H:i:s'), 'r' => $route, 'ip' => $_SERVER['REMOTE_ADDR'] ?? '', 'm' => $method]);
        update_option(SOLASS_Config::OPT . '_log', array_slice($log, 0, 100));
    }
}

endif;
