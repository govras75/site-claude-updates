<?php
/**
 * SOLASS Site -> Claude — ЯДРО: Конфігурація
 * -------------------------------------------------------------------
 * Фундамент плагіна. Єдина точка доступу до налаштувань у БД.
 *
 * cfg()        — основні налаштування (опція solass_claude)
 * cfg_github() — GitHub-доступи (окрема опція solass_claude_github)
 *
 * Це НЕ модуль-фіча, а ядро — від нього залежать усі модулі.
 * Статичний клас: стану не тримає, лише читає/нормалізує опції.
 * -------------------------------------------------------------------
 */

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'SOLASS_Config' ) ) :

class SOLASS_Config {

    const OPT    = 'solass_claude';
    const OPT_GH = 'solass_claude_github';

    // Список усіх команд за замовчуванням передається ззовні через init(),
    // щоб config не залежав від конкретного списку команд (його тримає API-модуль).
    private static $default_services = [];

    public static function init( array $default_services ): void {
        self::$default_services = $default_services;
    }

    // Дефолти основної опції.
    public static function defaults(): array {
        return [
            'enabled'     => 1,
            'get_enabled' => 0,
            'get_write'   => 0,
            'token'       => '',
            'access_slug' => '',
            'log_path'    => '',
            'root_path'   => '',
            'allowed_ips' => '',
            'services'    => self::$default_services,
        ];
    }

    // Основні налаштування (єдиний масив, як було).
    public static function cfg(): array {
        return array_merge( self::defaults(), (array) get_option( self::OPT, [] ) );
    }

    // GitHub-доступи — окрема опція.
    public static function cfg_github(): array {
        return array_merge(
            [ 'gh_owner' => '', 'gh_repo' => '', 'gh_branch' => '', 'gh_token' => '' ],
            (array) get_option( self::OPT_GH, [] )
        );
    }

    // Корінь файлових операцій.
    public static function root(): string {
        $cfg = self::cfg();
        return rtrim( $cfg['root_path'] ?: ABSPATH, '/' );
    }

    // ---- sanitize callbacks (кожна опція зберігається окремо) ----

    public static function sanitize_main( array $in ): array {
        return [
            'enabled'     => ! empty( $in['enabled'] )     ? 1 : 0,
            'get_enabled' => ! empty( $in['get_enabled'] ) ? 1 : 0,
            'get_write'   => ! empty( $in['get_write'] )   ? 1 : 0,
            'token'       => sanitize_text_field( $in['token'] ?? '' ),
            'access_slug' => sanitize_text_field( $in['access_slug'] ?? '' ),
            'log_path'    => sanitize_text_field( $in['log_path'] ?? '' ),
            'root_path'   => sanitize_text_field( $in['root_path'] ?? '' ),
            'allowed_ips' => sanitize_textarea_field( $in['allowed_ips'] ?? '' ),
            'services'    => ! empty( $in['services'] ) && is_array( $in['services'] )
                             ? array_map( 'sanitize_text_field', $in['services'] )
                             : [],
        ];
    }

    public static function sanitize_github( array $in ): array {
        return [
            'gh_owner'  => sanitize_text_field( $in['gh_owner'] ?? '' ),
            'gh_repo'   => sanitize_text_field( $in['gh_repo'] ?? '' ),
            'gh_branch' => sanitize_text_field( $in['gh_branch'] ?? '' ),
            'gh_token'  => sanitize_text_field( $in['gh_token'] ?? '' ),
        ];
    }

    // Реєстрація обох опцій у WP Settings API.
    public static function register(): void {
        register_setting( self::OPT,    self::OPT,    [ 'sanitize_callback' => [ __CLASS__, 'sanitize_main' ] ] );
        register_setting( self::OPT_GH, self::OPT_GH, [ 'sanitize_callback' => [ __CLASS__, 'sanitize_github' ] ] );
    }
}

endif;
