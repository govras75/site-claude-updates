<?php
/**
 * SOLASS Site -> Claude — МОДУЛЬ: GitHub / інформування про сховище
 * -------------------------------------------------------------------
 * Самостійний модуль. Містить:
 *   - сторінку "Доступи та інтеграції" (owner/repo/branch/token)
 *   - перевірку з'єднання з репо
 *   - REST-команду get-access (читання даних доступу)
 *
 * Самореєструється: admin_menu (своє підменю) + rest_api_init (свій роут).
 * Видалення цього файлу прибирає ВЕСЬ GitHub-функціонал (сторінку і команду),
 * не зачіпаючи ядро, api та інші модулі.
 *
 * Авторизацію свого роута бере з api-модуля (спільний механізм auth),
 * щоб не дублювати логіку перевірки токена.
 * -------------------------------------------------------------------
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// Функції рендеру сторінки (процедурний стиль) — частина цього модуля.
require_once __DIR__ . '/../admin/page-access.php';

/*
 * Необов'язкові блоки автопідключення сховища (device flow тощо).
 * Підключаються ТУТ (а не в шаблоні сторінки), бо їм потрібні AJAX-хендлери,
 * які реєструються окремим запитом admin-ajax.php, не через сторінку.
 * Відсутність будь-якого файлу нічого не ламає: блок просто не зʼявиться,
 * ручна форма доступів лишається робочою.
 */
foreach ( array( 'storage-auth.php', 'storage-api.php' ) as $solass_block ) {
	$solass_block_path = __DIR__ . '/../admin/' . $solass_block;
	if ( is_readable( $solass_block_path ) ) {
		require_once $solass_block_path;
	}
}
unset( $solass_block, $solass_block_path );

if ( ! class_exists( 'SOLASS_Github' ) ) :

class SOLASS_Github {

    // Посилання на api-модуль — для спільної авторизації роута.
    private $api;

    public function __construct( $api = null ) {
        $this->api = $api;
        add_action( 'admin_menu',    [ $this, 'menu' ], 20 );
        add_action( 'rest_api_init', [ $this, 'register_route' ] );
    }

    // Підменю "Доступи".
    public function menu(): void {
        add_submenu_page(
            'solass-claude',
            'Доступи та інтеграції',
            'Доступи',
            'manage_options',
            'solass-claude-source',
            [ $this, 'page' ]
        );
    }

    // Рендер сторінки доступів.
    public function page(): void {
        solass_claude_access_render( SOLASS_Config::cfg_github(), SOLASS_Config::OPT_GH );
    }

    // Власний REST-роут get-access (авторизація через api->auth).
    public function register_route(): void {
        $cfg = SOLASS_Config::cfg();
        if ( empty( $cfg['enabled'] ) ) return;

        $get_on = ! empty( $cfg['get_enabled'] );

        register_rest_route( SOLASS_Api::NS, '/get-access', [
            'methods'             => $get_on ? [ 'GET', 'POST' ] : 'POST',
            'callback'            => [ $this, 'action_get_access' ],
            'permission_callback' => $this->api ? [ $this->api, 'auth' ] : '__return_true',
        ] );

        // Slug-доступ (публічний GET через access_slug), якщо ввімкнено.
        $slug = trim( $cfg['access_slug'] ?? '' );
        if ( $slug !== '' && $get_on && $this->api ) {
            register_rest_route( SOLASS_Api::NS, '/' . preg_quote( $slug, '/' ) . '/get-access', [
                'methods'             => 'GET',
                'callback'            => [ $this, 'action_get_access' ],
                'permission_callback' => [ $this->api, 'auth_slug' ],
            ] );
        }
    }

    // Команда: віддає дані доступу до репо.
    public function action_get_access(): WP_REST_Response {
        $gh = SOLASS_Config::cfg_github();
        return SOLASS_Utils::ok( [
            'owner'      => $gh['gh_owner'] ?? '',
            'repo'       => $gh['gh_repo'] ?? '',
            'branch'     => ( $gh['gh_branch'] ?? '' ) ?: 'main',
            'token'      => $gh['gh_token'] ?? '',
            'configured' => ! empty( $gh['gh_owner'] ) && ! empty( $gh['gh_repo'] ) && ! empty( $gh['gh_token'] ),
        ] );
    }
}

endif;
