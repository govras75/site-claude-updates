<?php
/**
 * SOLASS Site -> Claude — Updater Module
 */

if (!defined('ABSPATH')) exit;

class SOLASS_Claude_Updater {

    const UPDATE_JSON_URL = 'https://raw.githubusercontent.com/govras75/site-claude-updates/main/info.json';
    const UPDATE_MAX_BYTES = 26214400;
    const PLUGIN_SLUG     = 'solass-site-claude';

    private string $plugin_file;
    private string $plugin_version;

    public function __construct(string $plugin_file, string $plugin_version) {
        $this->plugin_file    = plugin_basename($plugin_file);
        $this->plugin_version = $plugin_version;

        add_filter('pre_set_site_transient_update_plugins', [$this, 'check_remote_update'], 0);
        add_filter('plugins_api', [$this, 'plugin_info'], 20, 3);
        add_filter('upgrader_pre_download', [$this, 'guard_download_size'], 10, 3);
    }

    const TRANSIENT_KEY   = 'solass_claude_upd_info';

    // ----------------------------------------------------------------
    // Отримати info.json — з кешем для check_remote_update
    // ----------------------------------------------------------------

    public function fetch_update_info(bool $use_cache = true): ?array {
        if ($use_cache) {
            $cached = get_transient(self::TRANSIENT_KEY);
            if ($cached !== false) return $cached ?: null;
        }

        $res = wp_remote_get(self::UPDATE_JSON_URL, [
            'timeout'   => 15,
            'sslverify' => true,
            'headers'   => ['Cache-Control' => 'no-cache'],
        ]);

        if (is_wp_error($res) || 200 !== wp_remote_retrieve_response_code($res)) {
            if ($use_cache) set_transient(self::TRANSIENT_KEY, '', 30 * MINUTE_IN_SECONDS);
            return null;
        }

        $data = json_decode(wp_remote_retrieve_body($res), true);
        if (!is_array($data) || empty($data['version'])) {
            if ($use_cache) set_transient(self::TRANSIENT_KEY, '', 30 * MINUTE_IN_SECONDS);
            return null;
        }

        if ($use_cache) set_transient(self::TRANSIENT_KEY, $data, HOUR_IN_SECONDS);
        return $data;
    }

    public function flush_cache(): void {
        delete_transient(self::TRANSIENT_KEY);
    }

    // ----------------------------------------------------------------
    // WP hook: pre_set_site_transient_update_plugins
    // ----------------------------------------------------------------

    public function check_remote_update($transient) {
        if (empty($transient->checked)) return $transient;

        $plugin_slug = $this->plugin_file;

        // Якщо WP вже знайшов оновлення — лише додаємо іконки
        if (isset($transient->response[$plugin_slug])) {
            $info = $this->fetch_update_info();
            if ($info && empty($transient->response[$plugin_slug]->icons)) {
                $transient->response[$plugin_slug]->icons = [
                    '1x' => $info['icons']['low']  ?? '',
                    '2x' => $info['icons']['high'] ?? '',
                ];
            }
            unset($transient->no_update[$plugin_slug]);
            return $transient;
        }

        // Заповнюємо no_update щоб завжди були видимі "Переглянути деталі" і автооновлення
        $info = $this->fetch_update_info();
        if (!$info) return $transient;

        $transient->no_update[$plugin_slug] = (object) [
            'name'        => $info['name'] ?? 'SOLASS Site -> Claude',
            'slug'        => self::PLUGIN_SLUG,
            'plugin'      => $plugin_slug,
            'new_version' => $this->plugin_version,
            'version'     => $this->plugin_version,
            'last_updated'=> $info['last_updated'] ?? '',
            'package'     => '',
            'tested'      => get_bloginfo('version'),
            'url'         => $info['homepage'] ?? 'https://solass.com.ua',
            'id'          => self::PLUGIN_SLUG . '/' . self::PLUGIN_SLUG . '.php',
            'icons'       => [
                '1x' => $info['icons']['low']  ?? '',
                '2x' => $info['icons']['high'] ?? '',
            ],
        ];

        return $transient;
    }

    // ----------------------------------------------------------------
    // WP hook: plugins_api — попап "Переглянути деталі"
    // ----------------------------------------------------------------

    public function plugin_info($result, $action, $args) {
        if ($action !== 'plugin_information') return $result;
        if (empty($args->slug) || $args->slug !== self::PLUGIN_SLUG) return $result;

        $info = $this->fetch_update_info();
        if (!$info) return $result;

        return (object) [
            'name'           => $info['name'] ?? 'SOLASS Site -> Claude',
            'slug'           => self::PLUGIN_SLUG,
            'version'        => $info['version'],
            'author'         => '<a href="https://solass.com.ua">SOLASS</a>',
            'author_profile' => 'https://solass.com.ua',
            'homepage'       => $info['homepage'] ?? 'https://solass.com.ua',
            'requires'       => $info['requires'] ?? '5.0',
            'tested'         => $info['tested'] ?? '',
            'requires_php'   => $info['requires_php'] ?? '7.4',
            'last_updated'   => $info['last_updated'] ?? '',
            'download_link'  => $info['download_url'] ?? '',
            'trunk'          => $info['download_url'] ?? '',
            'active_installs'=> (int) ($info['active_installs'] ?? 0),
            'sections'       => array_merge(
                ['description' => $info['short_description'] ?? ''],
                (array) ($info['sections'] ?? [])
            ),
            'banners' => [
                'low'  => $info['banners']['low']  ?? '',
                'high' => $info['banners']['high'] ?? '',
            ],
            'icons' => [
                'low'  => $info['icons']['low']  ?? '',
                'high' => $info['icons']['high'] ?? '',
            ],
        ];
    }

    // ----------------------------------------------------------------
    // WP hook: захист від завеликого zip
    // ----------------------------------------------------------------

    public function guard_download_size($reply, $package, $upgrader) {
        if (!is_string($package)) return $reply;
        if (strpos($package, 'raw.githubusercontent.com') === false
            && strpos($package, self::PLUGIN_SLUG) === false) {
            return $reply;
        }

        $head = wp_remote_head($package, ['timeout' => 15, 'sslverify' => true]);
        if (is_wp_error($head)) return $reply;

        $len  = (int) wp_remote_retrieve_header($head, 'content-length');
        $type = wp_remote_retrieve_header($head, 'content-type');

        if ($len > self::UPDATE_MAX_BYTES) {
            return new WP_Error('sc_too_big', sprintf('Пакет завеликий (%s).', size_format($len)));
        }
        if ($type && stripos($type, 'text/html') !== false) {
            return new WP_Error('sc_html', 'Сервер повернув HTML замість ZIP.');
        }

        return $reply;
    }

    // ----------------------------------------------------------------
    // force-update: додаємо в response і викликаємо upgrade()
    // ----------------------------------------------------------------

    public function run_update(): array {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/class-automatic-upgrader-skin.php';

        $local_ver = $this->plugin_version;
        $info = $this->fetch_update_info(false); // без кешу — завжди свіжо

        if (!$info) {
            return ['updated' => false, 'message' => 'Не вдалося отримати info.json.'];
        }

        $remote_ver = $info['version'] ?? '';

        if (!version_compare($remote_ver, $local_ver, '>')) {
            return [
                'updated' => false,
                'from'    => $local_ver,
                'to'      => $remote_ver,
                'message' => "Оновлення не потрібне. Встановлена версія ({$local_ver}) актуальна.",
            ];
        }

        // Додаємо в список оновлень і викликаємо upgrade()
        $current = get_site_transient('update_plugins');
        if (!is_object($current)) $current = new stdClass();
        if (!isset($current->response)) $current->response = [];

        $current->response[$this->plugin_file] = (object) [
            'slug'        => self::PLUGIN_SLUG,
            'plugin'      => $this->plugin_file,
            'new_version' => $remote_ver,
            'package'     => $info['download_url'],
        ];
        set_site_transient('update_plugins', $current);

        $skin     = new Automatic_Upgrader_Skin();
        $upgrader = new Plugin_Upgrader($skin);
        $result   = $upgrader->upgrade($this->plugin_file);

        if (is_wp_error($result)) {
            return ['updated' => false, 'from' => $local_ver, 'to' => $remote_ver,
                'message' => 'Помилка: ' . $result->get_error_message()];
        }

        if ($result === false) {
            return ['updated' => false, 'from' => $local_ver, 'to' => $remote_ver,
                'message' => 'Оновлення не вдалось.'];
        }

        // Активуємо плагін якщо WP деактивував після upgrade
        if (!is_plugin_active($this->plugin_file)) {
            activate_plugin($this->plugin_file);
        }

        return ['updated' => true, 'from' => $local_ver, 'to' => $remote_ver,
            'message' => "Плагін оновлено з {$local_ver} до {$remote_ver}."];
    }
}
