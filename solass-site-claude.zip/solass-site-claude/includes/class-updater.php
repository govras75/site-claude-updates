<?php
/**
 * SOLASS Site -> Claude — Updater Module
 * Побудовано по моделі SOLASS WPSettings / plugins_update.php
 */

if (!defined('ABSPATH')) exit;

class SOLASS_Claude_Updater {

    const UPDATE_JSON_URL = 'https://raw.githubusercontent.com/govras75/site-claude-updates/main/info.json';
    const UPDATE_MAX_BYTES = 26214400; // 25 MB
    const PLUGIN_SLUG     = 'solass-site-claude';
    const TRANSIENT_KEY   = 'solass_claude_update_info';

    private string $plugin_file;    // повний шлях: solass-site-claude/plugin.php
    private string $plugin_version;

    public function __construct(string $plugin_file, string $plugin_version) {
        $this->plugin_file    = plugin_basename($plugin_file);
        $this->plugin_version = $plugin_version;

        add_filter('pre_set_site_transient_update_plugins', [$this, 'check_remote_update'], 0);
        add_filter('plugins_api', [$this, 'plugin_info'], 20, 3);
        add_filter('upgrader_pre_download', [$this, 'guard_download_size'], 10, 3);
    }

    // ----------------------------------------------------------------
    // Отримати info.json з GitHub (кеш 6 год)
    // ----------------------------------------------------------------

    public function fetch_update_info(): ?array {
        $cached = get_transient(self::TRANSIENT_KEY);
        if ($cached !== false) return $cached ?: null;

        $res = wp_remote_get(self::UPDATE_JSON_URL, [
            'timeout'     => 15,
            'redirection' => 5,
            'sslverify'   => true,
            'headers'     => ['Cache-Control' => 'no-cache'],
        ]);

        if (is_wp_error($res) || 200 !== wp_remote_retrieve_response_code($res)) {
            set_transient(self::TRANSIENT_KEY, '', HOUR_IN_SECONDS);
            return null;
        }

        $data = json_decode(wp_remote_retrieve_body($res), true);
        if (!is_array($data) || empty($data['version'])) {
            set_transient(self::TRANSIENT_KEY, '', HOUR_IN_SECONDS);
            return null;
        }

        set_transient(self::TRANSIENT_KEY, $data, 6 * HOUR_IN_SECONDS);
        return $data;
    }

    public function flush_cache(): void {
        delete_transient(self::TRANSIENT_KEY);
    }

    // ----------------------------------------------------------------
    // WP hook: pre_set_site_transient_update_plugins
    // Заповнюємо і response (є оновлення) і no_update (актуальна версія)
    // Саме no_update дозволяє WP завжди показувати "Переглянути деталі"
    // і перемикач автооновлення — навіть коли оновлення немає.
    // ----------------------------------------------------------------

    public function check_remote_update($transient) {
        if (empty($transient->checked)) return $transient;

        $info = $this->fetch_update_info();
        if (!$info) return $transient;

        $plugin_slug = $this->plugin_file;
        $icons = [
            '1x' => $info['icons']['low']  ?? '',
            '2x' => $info['icons']['high'] ?? '',
        ];

        if (version_compare($info['version'], $this->plugin_version, '>')) {
            // Є нова версія
            $transient->response[$plugin_slug] = (object) [
                'name'         => $info['name'] ?? 'SOLASS Site -> Claude',
                'slug'         => self::PLUGIN_SLUG,
                'plugin'       => $plugin_slug,
                'new_version'  => $info['version'],
                'last_updated' => $info['last_updated'] ?? '',
                'package'      => $info['download_url'] ?? '',
                'tested'       => get_bloginfo('version'),
                'requires'     => $info['requires'] ?? '5.0',
                'requires_php' => $info['requires_php'] ?? '7.4',
                'url'          => $info['homepage'] ?? 'https://solass.com.ua',
                'id'           => self::PLUGIN_SLUG . '/' . self::PLUGIN_SLUG . '.php',
                'icons'        => $icons,
            ];
            unset($transient->no_update[$plugin_slug]);
        } else {
            // Версія актуальна — записуємо в no_update щоб WP показував посилання
            $transient->no_update[$plugin_slug] = (object) [
                'name'         => $info['name'] ?? 'SOLASS Site -> Claude',
                'slug'         => self::PLUGIN_SLUG,
                'plugin'       => $plugin_slug,
                'new_version'  => $this->plugin_version,
                'version'      => $this->plugin_version,
                'last_updated' => $info['last_updated'] ?? '',
                'package'      => '',
                'tested'       => get_bloginfo('version'),
                'requires'     => $info['requires'] ?? '5.0',
                'requires_php' => $info['requires_php'] ?? '7.4',
                'url'          => $info['homepage'] ?? 'https://solass.com.ua',
                'id'           => self::PLUGIN_SLUG . '/' . self::PLUGIN_SLUG . '.php',
                'icons'        => $icons,
            ];
            unset($transient->response[$plugin_slug]);
        }

        return $transient;
    }

    // ----------------------------------------------------------------
    // WP hook: plugins_api — дані для попапу "Переглянути деталі"
    // ----------------------------------------------------------------

    public function plugin_info($result, $action, $args) {
        if ($action !== 'plugin_information') return $result;
        if (empty($args->slug) || $args->slug !== self::PLUGIN_SLUG) return $result;

        $info = $this->fetch_update_info();
        if (!$info) return $result;

        return (object) [
            'name'           => $info['name'] ?? 'SOLASS Site -> Claude',
            'slug'           => self::PLUGIN_SLUG,
            'version'        => $info['version'],
            'author'         => '<a href="https://solass.com.ua">SOLASS</a>',
            'author_profile' => 'https://solass.com.ua',
            'homepage'       => $info['homepage'] ?? 'https://solass.com.ua',
            'requires'       => $info['requires'] ?? '5.0',
            'tested'         => $info['tested'] ?? '',
            'requires_php'   => $info['requires_php'] ?? '7.4',
            'last_updated'   => $info['last_updated'] ?? '',
            'download_link'  => $info['download_url'] ?? '',
            'trunk'          => $info['download_url'] ?? '',
            'active_installs'=> (int) ($info['active_installs'] ?? 0),
            'sections'       => array_merge(
                ['description' => $info['short_description'] ?? ''],
                (array) ($info['sections'] ?? [])
            ),
            'banners' => [
                'low'  => $info['banners']['low']  ?? '',
                'high' => $info['banners']['high'] ?? '',
            ],
            'icons' => [
                'low'  => $info['icons']['low']  ?? '',
                'high' => $info['icons']['high'] ?? '',
            ],
        ];
    }

    // ----------------------------------------------------------------
    // WP hook: захист від завеликого zip і HTML замість zip
    // ----------------------------------------------------------------

    public function guard_download_size($reply, $package, $upgrader) {
        if (!is_string($package)) return $reply;
        if (strpos($package, 'raw.githubusercontent.com') === false
            && strpos($package, self::PLUGIN_SLUG) === false) {
            return $reply;
        }

        $head = wp_remote_head($package, ['timeout' => 15, 'sslverify' => true]);
        if (is_wp_error($head)) return $reply;

        $len  = (int) wp_remote_retrieve_header($head, 'content-length');
        $type = wp_remote_retrieve_header($head, 'content-type');

        if ($len > self::UPDATE_MAX_BYTES) {
            return new WP_Error('sc_too_big', sprintf(
                'Пакет завеликий (%s). Ліміт %s.',
                size_format($len), size_format(self::UPDATE_MAX_BYTES)
            ));
        }
        if ($type && stripos($type, 'text/html') !== false) {
            return new WP_Error('sc_html', 'Сервер повернув HTML замість ZIP.');
        }

        return $reply;
    }

    // ----------------------------------------------------------------
    // Примусове оновлення через force-update endpoint
    // ----------------------------------------------------------------

    public function run_update(): array {
        $this->flush_cache();
        $info = $this->fetch_update_info();

        if (!$info) {
            return ['updated' => false, 'message' => 'Не вдалося отримати info.json з GitHub.'];
        }

        $remote_ver = $info['version'] ?? '';
        $local_ver  = $this->plugin_version;

        if (!version_compare($remote_ver, $local_ver, '>')) {
            return [
                'updated' => false,
                'from'    => $local_ver,
                'to'      => $remote_ver,
                'message' => "Оновлення не потрібне. Встановлена версія ({$local_ver}) актуальна.",
            ];
        }

        $zip_url = $info['download_url'] ?? '';
        if (!$zip_url) {
            return ['updated' => false, 'message' => 'download_url відсутній в info.json.'];
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/class-automatic-upgrader-skin.php';

        $skin     = new Automatic_Upgrader_Skin();
        $upgrader = new Plugin_Upgrader($skin);
        $result   = $upgrader->install($zip_url, ['overwrite_package' => true]);

        if (is_wp_error($result)) {
            return [
                'updated' => false,
                'from'    => $local_ver,
                'to'      => $remote_ver,
                'message' => 'Помилка: ' . $result->get_error_message(),
            ];
        }

        if ($result === false) {
            return [
                'updated' => false,
                'from'    => $local_ver,
                'to'      => $remote_ver,
                'message' => 'Оновлення не вдалось (WP Upgrader).',
            ];
        }

        // Скидаємо кеш і тригеримо свіжу перевірку — так само як WP робить після upgrade
        $this->flush_cache();
        wp_clean_plugins_cache(true);

        return [
            'updated' => true,
            'from'    => $local_ver,
            'to'      => $remote_ver,
            'message' => "Плагін оновлено з {$local_ver} до {$remote_ver}.",
        ];
    }
}
