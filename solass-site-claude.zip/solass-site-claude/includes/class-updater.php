<?php
/**
 * SOLASS Site -> Claude — Updater
 * Update URI в шапці плагіна — WP сам читає info.json і показує всі посилання.
 * Цей клас тільки для force-update endpoint.
 */

if (!defined('ABSPATH')) exit;

class SOLASS_Claude_Updater {

    const UPDATE_JSON_URL = 'https://raw.githubusercontent.com/govras75/site-claude-updates/main/info.json';
    const PLUGIN_SLUG     = 'solass-site-claude';

    private string $plugin_file;
    private string $plugin_version;

    public function __construct(string $plugin_file, string $plugin_version) {
        $this->plugin_file    = plugin_basename($plugin_file);
        $this->plugin_version = $plugin_version;
    }

    public function run_update(): array {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/class-automatic-upgrader-skin.php';

        $res = wp_remote_get(self::UPDATE_JSON_URL, ['timeout' => 15, 'sslverify' => true]);
        if (is_wp_error($res) || 200 !== wp_remote_retrieve_response_code($res)) {
            return ['updated' => false, 'message' => 'Не вдалося отримати info.json.'];
        }

        $info = json_decode(wp_remote_retrieve_body($res), true);
        if (!is_array($info) || empty($info['version'])) {
            return ['updated' => false, 'message' => 'Невірний формат info.json.'];
        }

        $remote_ver = $info['version'];
        $local_ver  = $this->plugin_version;

        if (!version_compare($remote_ver, $local_ver, '>')) {
            return ['updated' => false, 'from' => $local_ver, 'to' => $remote_ver,
                'message' => "Оновлення не потрібне. Встановлена версія ({$local_ver}) актуальна."];
        }

        // Додаємо в список оновлень і викликаємо upgrade()
        $current = get_site_transient('update_plugins');
        if (!is_object($current)) $current = new stdClass();
        if (!isset($current->response)) $current->response = [];
        $current->response[$this->plugin_file] = (object) [
            'slug'        => self::PLUGIN_SLUG,
            'plugin'      => $this->plugin_file,
            'new_version' => $remote_ver,
            'package'     => $info['download_url'],
        ];
        set_site_transient('update_plugins', $current);

        $skin     = new Automatic_Upgrader_Skin();
        $upgrader = new Plugin_Upgrader($skin);
        $result   = $upgrader->upgrade($this->plugin_file);

        if (is_wp_error($result)) {
            return ['updated' => false, 'from' => $local_ver, 'to' => $remote_ver,
                'message' => 'Помилка: ' . $result->get_error_message()];
        }
        if ($result === false) {
            return ['updated' => false, 'from' => $local_ver, 'to' => $remote_ver,
                'message' => 'Оновлення не вдалось.'];
        }

        if (!is_plugin_active($this->plugin_file)) {
            activate_plugin($this->plugin_file);
        }

        return ['updated' => true, 'from' => $local_ver, 'to' => $remote_ver,
            'message' => "Плагін оновлено з {$local_ver} до {$remote_ver}."];
    }
}
