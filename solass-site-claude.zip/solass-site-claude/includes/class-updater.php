<?php
/**
 * SOLASS Site -> Claude — Updater Module
 * Замкнений модуль: перевірка оновлень, plugins_api, guard, force-update.
 * Підключається з plugin.php через require_once.
 */

if (!defined('ABSPATH')) exit;

class SOLASS_Claude_Updater {

    const UPDATE_JSON_URL = 'https://raw.githubusercontent.com/govras75/site-claude-updates/main/info.json';
    const UPDATE_MAX_BYTES = 26214400; // 25 MB
    const PLUGIN_SLUG     = 'solass-site-claude';
    const OPT_TRANSIENT   = 'solass_claude_update_info';

    private string $plugin_file;
    private string $plugin_version;

    public function __construct(string $plugin_file, string $plugin_version) {
        $this->plugin_file    = $plugin_file;
        $this->plugin_version = $plugin_version;

        add_filter('pre_set_site_transient_update_plugins', [$this, 'check_remote_update']);
        add_filter('plugins_api', [$this, 'plugin_info'], 20, 3);
        add_filter('upgrader_pre_download', [$this, 'guard_download_size'], 10, 3);
    }

    // ----------------------------------------------------------------
    // ПУБЛІЧНИЙ: отримати info.json (з кешем 6 год)
    // ----------------------------------------------------------------

    public function fetch_update_info(): ?array {
        $cached = get_transient(self::OPT_TRANSIENT);
        if ($cached !== false) return $cached ?: null;

        $res = wp_remote_get(self::UPDATE_JSON_URL, [
            'timeout'     => 15,
            'redirection' => 5,
            'sslverify'   => true,
            'headers'     => ['Cache-Control' => 'no-cache'],
        ]);

        if (is_wp_error($res)) {
            set_transient(self::OPT_TRANSIENT, '', HOUR_IN_SECONDS);
            return null;
        }

        $data = json_decode(wp_remote_retrieve_body($res), true);
        if (!is_array($data) || empty($data['version'])) {
            set_transient(self::OPT_TRANSIENT, '', HOUR_IN_SECONDS);
            return null;
        }

        set_transient(self::OPT_TRANSIENT, $data, 6 * HOUR_IN_SECONDS);
        return $data;
    }

    // ----------------------------------------------------------------
    // ПУБЛІЧНИЙ: примусово скинути кеш info.json
    // ----------------------------------------------------------------

    public function flush_cache(): void {
        delete_transient(self::OPT_TRANSIENT);
    }

    // ----------------------------------------------------------------
    // ПУБЛІЧНИЙ: виконати оновлення якщо версія на GitHub новіша
    // Повертає масив ['updated'=>bool, 'from'=>'x', 'to'=>'x', 'message'=>'...']
    // ----------------------------------------------------------------

    public function run_update(): array {
        // Скидаємо кеш щоб отримати свіжий info.json
        $this->flush_cache();
        $info = $this->fetch_update_info();

        if (!$info) {
            return ['updated' => false, 'message' => 'Не вдалося отримати info.json з GitHub.'];
        }

        $remote_ver = $info['version'] ?? '';
        $local_ver  = $this->plugin_version;

        if (!version_compare($remote_ver, $local_ver, '>')) {
            return [
                'updated' => false,
                'from'    => $local_ver,
                'to'      => $remote_ver,
                'message' => "Оновлення не потрібне. Встановлена версія ({$local_ver}) актуальна.",
            ];
        }

        $zip_url = $info['download_url'] ?? '';
        if (!$zip_url) {
            return ['updated' => false, 'message' => 'download_url відсутній в info.json.'];
        }

        // Завантажуємо ZIP
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/class-automatic-upgrader-skin.php';

        // HEAD-перевірка розміру і типу
        $head = wp_remote_head($zip_url, ['timeout' => 15, 'sslverify' => true]);
        if (!is_wp_error($head)) {
            $len  = (int) wp_remote_retrieve_header($head, 'content-length');
            $type = wp_remote_retrieve_header($head, 'content-type');
            if ($len > self::UPDATE_MAX_BYTES) {
                return ['updated' => false, 'message' => 'ZIP завеликий: ' . size_format($len)];
            }
            if ($type && stripos($type, 'text/html') !== false) {
                return ['updated' => false, 'message' => 'GitHub повернув HTML замість ZIP. Перевірте URL.'];
            }
        }

        // Тихе оновлення через WP Upgrader
        $skin     = new Automatic_Upgrader_Skin();
        $upgrader = new Plugin_Upgrader($skin);
        $result   = $upgrader->install($zip_url, ['overwrite_package' => true]);

        if (is_wp_error($result)) {
            return [
                'updated' => false,
                'from'    => $local_ver,
                'to'      => $remote_ver,
                'message' => 'Помилка оновлення: ' . $result->get_error_message(),
            ];
        }

        if ($result === false) {
            return [
                'updated' => false,
                'from'    => $local_ver,
                'to'      => $remote_ver,
                'message' => 'Оновлення не вдалось (невідома помилка WP Upgrader).',
            ];
        }

        // Скидаємо кеш після оновлення
        $this->flush_cache();

        return [
            'updated' => true,
            'from'    => $local_ver,
            'to'      => $remote_ver,
            'message' => "Плагін оновлено з {$local_ver} до {$remote_ver}.",
        ];
    }

    // ----------------------------------------------------------------
    // WP hook: додати плагін у список оновлень WP
    // ----------------------------------------------------------------

    public function check_remote_update($transient) {
        if (empty($transient->checked)) return $transient;

        $info = $this->fetch_update_info();
        if (!$info) return $transient;

        if (!version_compare($info['version'], $this->plugin_version, '>')) return $transient;

        $transient->response[plugin_basename($this->plugin_file)] = (object) [
            'slug'         => self::PLUGIN_SLUG,
            'plugin'       => plugin_basename($this->plugin_file),
            'new_version'  => $info['version'],
            'url'          => $info['homepage'] ?? '',
            'package'      => $info['download_url'] ?? '',
            'tested'       => $info['tested'] ?? '',
            'requires'     => $info['requires'] ?? '',
            'requires_php' => $info['requires_php'] ?? '',
            'id'           => self::PLUGIN_SLUG . '/' . self::PLUGIN_SLUG . '.php',
        ];

        return $transient;
    }

    // ----------------------------------------------------------------
    // WP hook: картка "Переглянути деталі" у WP-попапі
    // ----------------------------------------------------------------

    public function plugin_info($result, $action, $args) {
        if ($action !== 'plugin_information') return $result;
        if (empty($args->slug) || $args->slug !== self::PLUGIN_SLUG) return $result;

        $info = $this->fetch_update_info();
        if (!$info) return $result;

        return (object) [
            'name'          => $info['name'] ?? 'SOLASS Site -> Claude',
            'slug'          => self::PLUGIN_SLUG,
            'version'       => $info['version'],
            'author'        => '<a href="https://solass.com.ua">SOLASS</a>',
            'author_profile' => 'https://solass.com.ua',
            'homepage'      => $info['homepage'] ?? 'https://solass.com.ua',
            'requires'      => $info['requires'] ?? '5.0',
            'tested'        => $info['tested'] ?? '',
            'requires_php'  => $info['requires_php'] ?? '7.4',
            'last_updated'  => $info['last_updated'] ?? '',
            'download_link' => $info['download_url'] ?? '',
            'sections'      => array_merge(
                ['description' => $info['short_description'] ?? ''],
                $info['sections'] ?? []
            ),
            'banners'       => [],
        ];
    }

    // ----------------------------------------------------------------
    // WP hook: захист від завеликого zip та Drive HTML
    // ----------------------------------------------------------------

    public function guard_download_size($reply, $package, $upgrader) {
        if (!is_string($package)) return $reply;
        if (strpos($package, self::PLUGIN_SLUG) === false
            && strpos($package, 'raw.githubusercontent.com') === false) {
            return $reply;
        }

        $info = $this->fetch_update_info();
        if (!$info || empty($info['download_url'])) return $reply;
        if ($package !== $info['download_url']) return $reply;

        $head = wp_remote_head($package, ['timeout' => 15, 'sslverify' => true]);
        if (is_wp_error($head)) return $reply;

        $len  = (int) wp_remote_retrieve_header($head, 'content-length');
        $type = wp_remote_retrieve_header($head, 'content-type');

        if ($len > self::UPDATE_MAX_BYTES) {
            return new WP_Error('sc_too_big', sprintf(
                'Пакет оновлення завеликий (%s). Ліміт %s.',
                size_format($len), size_format(self::UPDATE_MAX_BYTES)
            ));
        }
        if ($type && stripos($type, 'text/html') !== false) {
            return new WP_Error('sc_html', 'Сервер повернув HTML замість ZIP. Оновлення скасовано.');
        }

        return $reply;
    }
}
