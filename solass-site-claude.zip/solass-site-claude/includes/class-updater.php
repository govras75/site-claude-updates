<?php
/**
 * SOLASS Universal Plugin Updater
 * -------------------------------------------------------------------
 * Універсальний апдейтер для self-hosted плагінів SOLASS.
 * Працює за принципом SOLASS WPSettings:
 *   - pre_set_site_transient_update_plugins  → перемикає response[] / no_update[]
 *       (no_update[] тримає "Переглянути деталі" + перемикач автооновлення завжди)
 *   - plugins_api                            → дані для попапу "Переглянути деталі"
 *
 * Усі параметри беруться АВТОМАТИЧНО з шапки плагіна:
 *   Version, Plugin Name, Author, Update URI (→ URL до JSON з інфо про оновлення).
 *
 * JSON інфо лежить на сервері оновлень (GitHub) і називається [slug]-info.json.
 * Один і той самий файл-клас можна вставити в будь-який плагін SOLASS:
 *   require_once __DIR__ . '/includes/class-updater.php';
 *   new SOLASS_Updater( __FILE__ );
 * -------------------------------------------------------------------
 */

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'SOLASS_Updater' ) ) :

class SOLASS_Updater {

    private string  $file;       // повний шлях головного файлу плагіна (__FILE__)
    private string  $basename;   // slug/slug.php
    private string  $slug;       // slug (ім'я папки)
    private string  $name;       // Plugin Name з шапки
    private string  $version;    // Version з шапки
    private string  $author;     // Author з шапки
    private string  $zip_url;    // Update URI з шапки → пряме посилання на zip
    private string  $json_url;   // сформоване: тека Update URI + [slug]-info.json
    private $remote = null;      // кеш розпарсеного JSON на час одного HTTP-запиту

    public function __construct( string $plugin_file ) {
        $this->file     = $plugin_file;
        $this->basename = plugin_basename( $plugin_file );
        $this->slug     = dirname( $this->basename );

        // Усе з шапки — нічого не дублюємо вручну
        $meta = get_file_data( $plugin_file, array(
            'Name'      => 'Plugin Name',
            'Version'   => 'Version',
            'Author'    => 'Author',
            'UpdateURI' => 'Update URI',
        ) );

        $this->name    = $meta['Name'];
        $this->version = $meta['Version'];
        $this->author  = $meta['Author'];

        // Update URI = пряме посилання на zip (як у SOLASS WPSettings).
        // JSON з інфо лежить у тій самій теці і називається [slug]-info.json.
        // ВАЖЛИВО: джерело оновлень — лише вшите тут (шапка + цей шаблон),
        // воно НЕ пов'язане з налаштуваннями доступу до репо в адмінці.
        // Налаштування репо в адмінці — це доступ для ЗАПИСУ (патчі/файли), не для оновлень.
        $this->zip_url  = $meta['UpdateURI'];
        $this->json_url = trailingslashit( dirname( $this->zip_url ) ) . $this->slug . '-info.json';

        add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'inject_update' ), 0 );
        add_filter( 'plugins_api', array( $this, 'plugin_info' ), 20, 3 );
    }

    // ----------------------------------------------------------------
    // Завантажити і розпарсити JSON з сервера оновлень (раз на запит)
    // ----------------------------------------------------------------
    private function get_remote() {
        if ( $this->remote !== null ) {
            return $this->remote ?: null;
        }
        if ( empty( $this->json_url ) ) {
            $this->remote = false;
            return null;
        }

        $res = wp_remote_get( $this->json_url, array(
            'timeout' => 15,
            'headers' => array( 'Accept' => 'application/json' ),
        ) );

        if ( is_wp_error( $res )
            || 200 !== wp_remote_retrieve_response_code( $res )
            || empty( wp_remote_retrieve_body( $res ) )
        ) {
            $this->remote = false;
            return null;
        }

        $data = json_decode( wp_remote_retrieve_body( $res ) );
        if ( ! is_object( $data ) || empty( $data->version ) ) {
            $this->remote = false;
            return null;
        }

        $this->remote = $data;
        return $data;
    }

    // ----------------------------------------------------------------
    // pre_set_site_transient_update_plugins
    // ----------------------------------------------------------------
    public function inject_update( $transient ) {

    if ( empty( $transient->checked ) ) {
        return $transient;
    }

    $remote = $this->get_remote();
    if ( ! $remote ) {
        return $transient;
    }

    // Завжди беремо поточну версію з файлу плагіна,
    // а не ту, що була прочитана під час створення об'єкта.
    $meta = get_file_data( $this->file, array(
        'Version' => 'Version',
    ) );

    $current_version = $meta['Version'] ?? $this->version;

    $icons = array(
        '1x' => $remote->icons->low  ?? '',
        '2x' => $remote->icons->high ?? '',
    );

    if ( version_compare( $current_version, $remote->version, '<' ) ) {

        $transient->response[ $this->basename ] = (object) array(
            'name'         => $remote->name ?? $this->name,
            'slug'         => $this->slug,
            'plugin'       => $this->basename,
            'new_version'  => $remote->version,
            'last_updated' => $remote->last_updated ?? '',
            'package'      => $remote->download_url ?? $this->zip_url,
            'url'          => $remote->homepage ?? '',
            'tested'       => $remote->tested ?? get_bloginfo( 'version' ),
            'requires'     => $remote->requires ?? '',
            'requires_php' => $remote->requires_php ?? '',
            'icons'        => $icons,
        );

        unset( $transient->no_update[ $this->basename ] );

    } else {

        $transient->no_update[ $this->basename ] = (object) array(
            'name'         => $remote->name ?? $this->name,
            'slug'         => $this->slug,
            'plugin'       => $this->basename,
            'new_version'  => $current_version,
            'version'      => $current_version,
            'last_updated' => $remote->last_updated ?? '',
            'package'      => '',
            'url'          => $remote->homepage ?? '',
            'tested'       => $remote->tested ?? get_bloginfo( 'version' ),
            'icons'        => $icons,
        );

        unset( $transient->response[ $this->basename ] );
    }

    return $transient;
}

    // ----------------------------------------------------------------
    // plugins_api — дані для попапу "Переглянути деталі"
    // ----------------------------------------------------------------
    public function plugin_info( $res, $action, $args ) {
        if ( 'plugin_information' !== $action ) return $res;
        if ( empty( $args->slug ) || $args->slug !== $this->slug ) return $res;

        $remote = $this->get_remote();
        if ( ! $remote ) return $res;

        $info = new stdClass();
        $info->name            = $remote->name ?? $this->name;
        $info->slug            = $this->slug;
        $info->version         = $remote->version;
        $info->author          = $remote->author ?? $this->author;
        $info->author_profile  = $remote->author_profile ?? '';
        $info->homepage        = $remote->homepage ?? '';
        $info->requires        = $remote->requires ?? '';
        $info->requires_php    = $remote->requires_php ?? '';
        if ( ! empty( $remote->tested ) ) $info->tested = $remote->tested;
        $info->last_updated    = $remote->last_updated ?? '';
        $info->download_link   = $remote->download_url ?? '';
        $info->trunk           = $remote->download_url ?? '';
        $info->active_installs = $remote->active_installs ?? 0;

        // sections (description / installation / changelog / screenshots ...)
        $info->sections = array();
        if ( ! empty( $remote->sections ) ) {
            foreach ( $remote->sections as $k => $v ) {
                $info->sections[ $k ] = $v;
            }
        }

        $info->banners = array(
            'low'  => $remote->banners->low  ?? '',
            'high' => $remote->banners->high ?? '',
        );
        $info->icons = array(
            'low'  => $remote->icons->low  ?? '',
            'high' => $remote->icons->high ?? '',
        );

        return $info;
    }

    // ----------------------------------------------------------------
    // Сумісність зі старим кодом головного файлу: повертає масив
    // ----------------------------------------------------------------
    public function fetch_update_info(): ?array {
        $remote = $this->get_remote();
        if ( ! $remote ) return null;
        return json_decode( wp_json_encode( $remote ), true );
    }

    public function flush_cache(): void {
        $this->remote = null;
        $this->force_check();
    }

    // ----------------------------------------------------------------
    // Змусити WP зробити свіжу перевірку оновлень "прямо зараз".
    // wp_update_plugins() пропускає перевірку поки last_checked свіжий
    // (плагіни — 1 год, інші сторінки — 12 год). Обнуляємо last_checked,
    // тоді будь-який timeout спрацьовує і наш inject_update викликається.
    // Так само поводиться сторінка Майстерня → Оновлення.
    // ----------------------------------------------------------------
    public function force_check(): void {
        $current = get_site_transient( 'update_plugins' );
        if ( ! is_object( $current ) ) $current = new stdClass();
        $current->last_checked = 0;
        set_site_transient( 'update_plugins', $current );
    }

    public function get_version(): string {
        return $this->version;
    }

    // ----------------------------------------------------------------
    // force-update endpoint (поки лишається як є — допрацюємо окремо)
    // ----------------------------------------------------------------
    public function run_update(): array {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/class-automatic-upgrader-skin.php';

        $remote = $this->get_remote();
        if ( ! $remote ) {
            return array( 'updated' => false, 'message' => 'Не вдалося отримати JSON оновлення.' );
        }

        $remote_ver = $remote->version;
        $local_ver  = $this->version;

        if ( ! version_compare( $remote_ver, $local_ver, '>' ) ) {
            return array(
                'updated' => false, 'from' => $local_ver, 'to' => $remote_ver,
                'message' => "Оновлення не потрібне. Встановлена версія ({$local_ver}) актуальна.",
            );
        }

        // НЕ пишемо в response[] вручну — це лишало "хвіст" у transient і дубль.
        // Натомість змушуємо WP свіжо перевірити: force_check обнуляє last_checked,
        // після чого наш inject_update сам коректно наповнить response[] (стандартно).
        $this->force_check();
        wp_update_plugins();

        $current = get_site_transient( 'update_plugins' );
        if ( empty( $current->response[ $this->basename ] ) ) {
            // inject_update не побачив оновлення (напр. CDN ще віддає старий JSON) —
            // як підстраховка наповнюємо мінімально, без зайвих полів.
            if ( ! is_object( $current ) ) $current = new stdClass();
            if ( ! isset( $current->response ) ) $current->response = array();
            $current->response[ $this->basename ] = (object) array(
                'slug'        => $this->slug,
                'plugin'      => $this->basename,
                'new_version' => $remote_ver,
                'package'     => $remote->download_url ?? $this->zip_url,
            );
            set_site_transient( 'update_plugins', $current );
        }

        $was_active = is_plugin_active( $this->basename );

        $skin     = new Automatic_Upgrader_Skin();
        $upgrader = new Plugin_Upgrader( $skin );
        $result   = $upgrader->upgrade( $this->basename );

        if ( is_wp_error( $result ) ) {
            return array( 'updated' => false, 'from' => $local_ver, 'to' => $remote_ver,
                'message' => 'Помилка: ' . $result->get_error_message() );
        }
        if ( $result === false ) {
            return array( 'updated' => false, 'from' => $local_ver, 'to' => $remote_ver,
                'message' => 'Оновлення не вдалось.' );
        }

        if ( $was_active && ! is_plugin_active( $this->basename ) ) {
            activate_plugin( $this->basename );
        }

        // Чистимо кеш оновлень так само, як це робить WP після штатного апгрейду —
        // прибирає запис з response[], плашка зникає без "хвоста".
        if ( function_exists( 'wp_clean_plugins_cache' ) ) {
            wp_clean_plugins_cache( true );
        }

        return array( 'updated' => true, 'from' => $local_ver, 'to' => $remote_ver,
            'message' => "Плагін оновлено з {$local_ver} до {$remote_ver}." );
    }
}

endif;
