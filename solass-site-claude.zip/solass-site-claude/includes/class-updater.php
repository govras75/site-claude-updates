<?php
/**
 * SOLASS Site -> Claude — Updater Module
 */

if (!defined('ABSPATH')) exit;

class SOLASS_Claude_Updater {

    const UPDATE_JSON_URL = 'https://raw.githubusercontent.com/govras75/site-claude-updates/main/info.json';
    const UPDATE_MAX_BYTES = 26214400;
    const PLUGIN_SLUG     = 'solass-site-claude';
    const TRANSIENT_KEY   = 'solass_claude_update_info';

    private string $plugin_file;
    private string $plugin_version;

    public function __construct(string $plugin_file, string $plugin_version) {
        $this->plugin_file    = plugin_basename($plugin_file);
        $this->plugin_version = $plugin_version;

        add_filter('pre_set_site_transient_update_plugins', [$this, 'check_remote_update'], 0);
        add_filter('plugins_api', [$this, 'plugin_info'], 20, 3);
        add_filter('upgrader_pre_download', [$this, 'guard_download_size'], 10, 3);
    }

    // ----------------------------------------------------------------
    // Отримати info.json з GitHub (кеш тільки для plugin_info/попапу)
    // ----------------------------------------------------------------

    public function fetch_update_info(): ?array {
        $cached = get_transient(self::TRANSIENT_KEY);
        if ($cached !== false) return $cached ?: null;

        $res = wp_remote_get(self::UPDATE_JSON_URL . '?t=' . time(), [
            'timeout'   => 15,
            'sslverify' => true,
            'headers'   => ['Cache-Control' => 'no-cache'],
        ]);

        if (is_wp_error($res) || 200 !== wp_remote_retrieve_response_code($res)) {
            set_transient(self::TRANSIENT_KEY, '', HOUR_IN_SECONDS);
            return null;
        }

        $data = json_decode(wp_remote_retrieve_body($res), true);
        if (!is_array($data) || empty($data['version'])) {
            set_transient(self::TRANSIENT_KEY, '', HOUR_IN_SECONDS);
            return null;
        }

        set_transient(self::TRANSIENT_KEY, $data, 6 * HOUR_IN_SECONDS);
        return $data;
    }

    public function flush_cache(): void {
        delete_transient(self::TRANSIENT_KEY);
    }

    // ----------------------------------------------------------------
    // WP hook: pre_set_site_transient_update_plugins
    // Без власних запитів — WP сам передає $transient з актуальними даними.
    // Ми тільки заповнюємо no_update щоб посилання завжди були видимі.
    // ----------------------------------------------------------------

    public function check_remote_update($transient) {
        if (empty($transient->checked)) return $transient;

        $plugin_slug = $this->plugin_file;

        // Якщо WP вже знайшов оновлення для нашого плагіна — не чіпаємо response,
        // тільки додаємо іконки якщо їх немає
        if (isset($transient->response[$plugin_slug])) {
            if (empty($transient->response[$plugin_slug]->icons)) {
                $info = $this->fetch_update_info();
                if ($info) {
                    $transient->response[$plugin_slug]->icons = [
                        '1x' => $info['icons']['low']  ?? '',
                        '2x' => $info['icons']['high'] ?? '',
                    ];
                }
            }
            unset($transient->no_update[$plugin_slug]);
            return $transient;
        }

        // Якщо оновлень немає — записуємо в no_update щоб WP показував
        // "Переглянути деталі" і перемикач автооновлення завжди
        $info = $this->fetch_update_info();
        if (!$info) return $transient;

        $icons = [
            '1x' => $info['icons']['low']  ?? '',
            '2x' => $info['icons']['high'] ?? '',
        ];

        $transient->no_update[$plugin_slug] = (object) [
            'name'         => $info['name'] ?? 'SOLASS Site -> Claude',
            'slug'         => self::PLUGIN_SLUG,
            'plugin'       => $plugin_slug,
            'new_version'  => $this->plugin_version,
            'version'      => $this->plugin_version,
            'last_updated' => $info['last_updated'] ?? '',
            'package'      => '',
            'tested'       => get_bloginfo('version'),
            'url'          => $info['homepage'] ?? 'https://solass.com.ua',
            'id'           => self::PLUGIN_SLUG . '/' . self::PLUGIN_SLUG . '.php',
            'icons'        => $icons,
        ];

        return $transient;
    }

    // ----------------------------------------------------------------
    // WP hook: plugins_api — дані для попапу "Переглянути деталі"
    // ----------------------------------------------------------------

    public function plugin_info($result, $action, $args) {
        if ($action !== 'plugin_information') return $result;
        if (empty($args->slug) || $args->slug !== self::PLUGIN_SLUG) return $result;

        $info = $this->fetch_update_info();
        if (!$info) return $result;

        return (object) [
            'name'           => $info['name'] ?? 'SOLASS Site -> Claude',
            'slug'           => self::PLUGIN_SLUG,
            'version'        => $info['version'],
            'author'         => '<a href="https://solass.com.ua">SOLASS</a>',
            'author_profile' => 'https://solass.com.ua',
            'homepage'       => $info['homepage'] ?? 'https://solass.com.ua',
            'requires'       => $info['requires'] ?? '5.0',
            'tested'         => $info['tested'] ?? '',
            'requires_php'   => $info['requires_php'] ?? '7.4',
            'last_updated'   => $info['last_updated'] ?? '',
            'download_link'  => $info['download_url'] ?? '',
            'trunk'          => $info['download_url'] ?? '',
            'active_installs'=> (int) ($info['active_installs'] ?? 0),
            'sections'       => array_merge(
                ['description' => $info['short_description'] ?? ''],
                (array) ($info['sections'] ?? [])
            ),
            'banners' => [
                'low'  => $info['banners']['low']  ?? '',
                'high' => $info['banners']['high'] ?? '',
            ],
            'icons' => [
                'low'  => $info['icons']['low']  ?? '',
                'high' => $info['icons']['high'] ?? '',
            ],
        ];
    }

    // ----------------------------------------------------------------
    // WP hook: захист від завеликого zip
    // ----------------------------------------------------------------

    public function guard_download_size($reply, $package, $upgrader) {
        if (!is_string($package)) return $reply;
        if (strpos($package, 'raw.githubusercontent.com') === false
            && strpos($package, self::PLUGIN_SLUG) === false) {
            return $reply;
        }

        $head = wp_remote_head($package, ['timeout' => 15, 'sslverify' => true]);
        if (is_wp_error($head)) return $reply;

        $len  = (int) wp_remote_retrieve_header($head, 'content-length');
        $type = wp_remote_retrieve_header($head, 'content-type');

        if ($len > self::UPDATE_MAX_BYTES) {
            return new WP_Error('sc_too_big', sprintf('Пакет завеликий (%s).', size_format($len)));
        }
        if ($type && stripos($type, 'text/html') !== false) {
            return new WP_Error('sc_html', 'Сервер повернув HTML замість ZIP.');
        }

        return $reply;
    }

    // ----------------------------------------------------------------
    // force-update: викликає wp_update_plugins() + upgrade() —
    // рівно те саме що робить кнопка "оновити зараз" в адмінці
    // ----------------------------------------------------------------

    public function run_update(): array {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/class-automatic-upgrader-skin.php';

        $local_ver = $this->plugin_version;

        // Отримати актуальну інфо з GitHub
        $this->flush_cache();
        $info = $this->fetch_update_info();

        if (!$info) {
            return ['updated' => false, 'message' => 'Не вдалося отримати info.json з GitHub.'];
        }

        $remote_ver = $info['version'] ?? '';

        if (!version_compare($remote_ver, $local_ver, '>')) {
            return [
                'updated' => false,
                'from'    => $local_ver,
                'to'      => $remote_ver,
                'message' => "Оновлення не потрібне. Встановлена версія ({$local_ver}) актуальна.",
            ];
        }

        // Додаємо наш плагін в список на оновлення якщо його там немає
        $current = get_site_transient('update_plugins');
        if (!is_object($current)) $current = new stdClass();
        if (!isset($current->response)) $current->response = [];

        $current->response[$this->plugin_file] = (object) [
            'slug'        => self::PLUGIN_SLUG,
            'plugin'      => $this->plugin_file,
            'new_version' => $remote_ver,
            'package'     => $info['download_url'],
        ];
        set_site_transient('update_plugins', $current);

        // Запускаємо upgrade() — рівно те що робить кнопка "оновити зараз"
        $skin     = new Automatic_Upgrader_Skin();
        $upgrader = new Plugin_Upgrader($skin);
        $result   = $upgrader->upgrade($this->plugin_file);

        $this->flush_cache();

        if (is_wp_error($result)) {
            return ['updated' => false, 'from' => $local_ver, 'to' => $remote_ver,
                'message' => 'Помилка: ' . $result->get_error_message()];
        }

        if ($result === false) {
            return ['updated' => false, 'from' => $local_ver, 'to' => $remote_ver,
                'message' => 'Оновлення не вдалось.'];
        }

        return ['updated' => true, 'from' => $local_ver, 'to' => $remote_ver,
            'message' => "Плагін оновлено з {$local_ver} до {$remote_ver}."];
    }
}
