<?php
/**
 * SOLASS Site -> Claude — ЯДРО: Утиліти
 * -------------------------------------------------------------------
 * Фундамент. Чисті допоміжні методи без власного стану.
 * Викликаються напряму: SOLASS_Utils::ok(...), SOLASS_Utils::err(...).
 *
 * Методи, яким потрібен root або список захищених файлів, приймають їх
 * параметром — щоб utils не залежав від конфігу (односторонній напрям).
 * -------------------------------------------------------------------
 */

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'SOLASS_Utils' ) ) :

class SOLASS_Utils {

    // ---- REST-відповіді ----

    public static function ok( $data ): WP_REST_Response {
        $r = new WP_REST_Response( [ 'success' => true, 'data' => $data ], 200 );
        $r->header( 'Cache-Control', 'no-store, no-cache, must-revalidate' );
        $r->header( 'X-Solass-Time', current_time( 'Y-m-d H:i:s' ) );
        return $r;
    }

    public static function err( string $msg, int $code = 400 ): WP_REST_Response {
        $r = new WP_REST_Response( [ 'success' => false, 'error' => $msg ], $code );
        $r->header( 'Cache-Control', 'no-store, no-cache, must-revalidate' );
        $r->header( 'X-Solass-Time', current_time( 'Y-m-d H:i:s' ) );
        return $r;
    }

    // ---- Файлові хелпери ----

    // Безпечний шлях у межах root (або /tmp). root передається параметром.
    public static function vpath( string $path, string $root ) {
        if ( ! $path ) return new WP_Error( 'no_path', 'path required' );
        if ( $path[0] !== '/' ) return $root . '/' . ltrim( $path, '/' );
        $real = realpath( dirname( $path ) ) ?: dirname( $path );
        foreach ( [ $root, '/tmp' ] as $a ) {
            if ( strpos( $real, rtrim( $a, '/' ) ) === 0 ) return $path;
        }
        return new WP_Error( 'bad_path', "Path outside root ({$root}): {$path}" );
    }

    // Чи є файл критичним (заборона запису). Списки передаються параметром.
    public static function is_protected_write( $abs, string $root, array $protected_files, array $protected_dirs ): bool {
        $base = basename( $abs );
        if ( in_array( $base, $protected_files, true ) ) return true;
        $root = rtrim( $root, '/' );
        $rel  = ltrim( str_replace( '\\', '/', substr( $abs, strlen( $root ) ) ), '/' );
        foreach ( $protected_dirs as $d ) {
            if ( $rel === $d || strpos( $rel, $d . '/' ) === 0 ) return true;
        }
        return false;
    }

    // Приховування секретів при читанні wp-config.php (без регулярок).
    public static function redact_secrets( $abs, $content ) {
        if ( basename( $abs ) !== 'wp-config.php' ) return $content;
        $out = [];
        foreach ( explode( "\n", $content ) as $ln ) {
            $u = strtoupper( $ln );
            $is_def = strpos( $u, 'DEFINE' ) !== false;
            $sens = false;
            foreach ( [ 'KEY', 'SALT', 'PASSWORD', 'SECRET', 'TOKEN', 'NONCE', 'AUTH' ] as $w ) {
                if ( strpos( $u, $w ) !== false ) { $sens = true; break; }
            }
            if ( $is_def && $sens ) {
                $cpos = strpos( $ln, ',' );
                if ( $cpos !== false ) {
                    $ln = substr( $ln, 0, $cpos + 1 ) . " '***REDACTED***' );";
                }
            }
            $out[] = $ln;
        }
        return implode( "\n", $out );
    }

    public static function fmt( $b ): string {
        foreach ( [ 'B', 'KB', 'MB', 'GB' ] as $u ) {
            if ( $b < 1024 ) return round( $b, 2 ) . " {$u}";
            $b /= 1024;
        }
        return round( $b, 2 ) . ' TB';
    }

    public static function mysql_ver(): string {
        global $wpdb;
        return $wpdb->get_var( 'SELECT VERSION()' ) ?? '?';
    }

    public static function find_recursive( string $dir, string $pattern, int $max, int $cur, array &$res ): void {
        if ( $cur > $max || count( $res ) >= 200 || ! is_dir( $dir ) || ! is_readable( $dir ) ) return;
        foreach ( scandir( $dir ) as $name ) {
            if ( $name === '.' || $name === '..' ) continue;
            $full = $dir . '/' . $name;
            if ( is_dir( $full ) ) {
                self::find_recursive( $full, $pattern, $max, $cur + 1, $res );
            } elseif ( fnmatch( $pattern, $name ) ) {
                $res[] = [ 'path' => $full, 'size' => self::fmt( filesize( $full ) ), 'modified' => date( 'Y-m-d H:i:s', filemtime( $full ) ) ];
            }
        }
    }

    public static function build_tree( string $dir, int $max, int $cur ): array {
        if ( $cur >= $max || ! is_dir( $dir ) || ! is_readable( $dir ) ) return [];
        $items = [];
        foreach ( scandir( $dir ) as $name ) {
            if ( $name === '.' || $name === '..' ) continue;
            $full = $dir . '/' . $name;
            $item = [ 'name' => $name, 'type' => is_dir( $full ) ? 'dir' : 'file' ];
            if ( is_dir( $full ) ) {
                $item['children'] = self::build_tree( $full, $max, $cur + 1 );
            } else {
                $item['size'] = self::fmt( filesize( $full ) );
            }
            $items[] = $item;
        }
        return $items;
    }
}

endif;
