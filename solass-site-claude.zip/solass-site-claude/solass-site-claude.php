<?php
/**
 * Plugin Name: SOLASS Site -> Claude
 * Plugin URI:  https://solass.com.ua
 * Description: REST API для підключення WordPress сайту до Claude AI.
 * Version:     2.8.8.3
 * Requires at least: 5.0
 * Requires PHP: 7.4
 * Author:      SOLASS
 * Author URI:  https://solass.com.ua/
 * License:     Private
 * Text Domain: solass-claude
 * Domain Path: /languages
 * Update URI:  https://raw.githubusercontent.com/govras75/site-claude-updates/main/solass-site-claude.zip
 */

if (!defined('ABSPATH')) exit;

require_once __DIR__ . '/includes/class-updater.php';

// Параметри плагіна — АВТОМАТИЧНО з шапки, ніде не дублюємо вручну
$solass_claude_meta = get_file_data(__FILE__, [
    'Name'      => 'Plugin Name',
    'Version'   => 'Version',
    'Author'    => 'Author',
    'UpdateURI' => 'Update URI',
]);
define('SOLASS_CLAUDE_VERSION',   $solass_claude_meta['Version']);
define('SOLASS_CLAUDE_NAME',      $solass_claude_meta['Name']);
define('SOLASS_CLAUDE_UPDATEURI', $solass_claude_meta['UpdateURI']);

class SOLASS_Claude {

    // Критичні файли — заборона ПЕРЕЗАПИСУ через write-file
    const PROTECTED_FILES = ['wp-config.php', 'wp-config-sample.php', '.htaccess', 'wp-settings.php', 'wp-load.php', 'wp-blog-header.php', 'wp-cron.php', 'xmlrpc.php'];
    const PROTECTED_DIRS  = ['wp-admin', 'wp-includes'];
    const OPT     = 'solass_claude';
    const NS      = 'solass-claude/v1';
 // 25 MB

    // Команди тільки для читання (GET за замовчуванням)
    const READ_ONLY = ['ping', 'server-info', 'disk-usage', 'list-dir', 'find-files', 'tree', 'get-log', 'wp-info', 'check-url', 'active-plugins', 'read-file', 'site-state', 'read-file-chunk', 'tail-file', 'flush-cache'];

    // Команди запису (потребують окремої галочки для GET)
    const WRITE_CMDS = ['write-file', 'wp-cli', 'exec'];

    // Довжина публічного slug (короткий, не схожий на токен)
    const SLUG_LENGTH = 8;

    const SERVICES = [
        'ping'           => ['Ping — перевірка з\'єднання',                 []],
        'server-info'    => ['Інфо про сервер (PHP, OS, пам\'ять, uptime)', []],
        'disk-usage'     => ['Використання диску',                          ['path? (default /)']],
        'read-file'      => ['Читати вміст файлу',                          ['path']],
        'write-file'     => ['Записати файл (з автобекапом)',               ['path', 'content']],
        'list-dir'       => ['Список файлів у директорії',                  ['path']],
        'find-files'     => ['Пошук файлів по масці рекурсивно',            ['path', 'pattern (напр. *.php)', 'depth? (default 5)']],
        'tree'           => ['Дерево папок',                                ['path', 'depth? (default 3)']],
        'get-log'        => ['Читати лог-файл (tail)',                      ['path?', 'lines? (default 50)']],
        'wp-info'        => ['Інфо про WordPress',                          []],
        'wp-cli'         => ['Виконати WP-CLI команду',                     ['command — без "wp"']],
        'check-url'      => ['Перевірити доступність URL',                  ['url']],
        'active-plugins' => ['Список активних плагінів',                    []],
        'exec'           => ['Виконати shell-команду',                      ['cmd']],
        'site-state'     => ['Повний знімок сайту одним запитом',           []],
        'read-file-chunk'=> ['Читати файл шматками (offset/limit)',          ['path', 'offset? (default 0)', 'limit? (default 50000)']],
        'tail-file'      => ['Хвіст лог-файлу (tail)',                       ['path?', 'lines? (default 100)']],
        'force-update'   => ['Примусово оновити плагін з GitHub',            []],
        'flush-cache'    => ['Скинути кеш оновлень (після пушу нової версії)', []],
    ];

    public function __construct() {
        add_action('rest_api_init',  [$this, 'register_routes']);
        add_action('admin_menu',     [$this, 'admin_menu']);
        add_action('admin_init',     [$this, 'register_settings']);
        add_action('wp_ajax_solass_claude_gen_token', [$this, 'ajax_gen_token']);
        add_action('update_option_' . self::OPT, [$this, 'after_save_settings']);
        add_action('add_option_' . self::OPT,    [$this, 'after_save_settings']);
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), [$this, 'plugin_links']);

        // Ініціалізуємо модуль оновлень
        $this->updater = new SOLASS_Updater(__FILE__);
    }

    public function plugin_links(array $links): array {
        array_unshift($links, sprintf(
            '<a href="%s">Налаштування</a>',
            admin_url('admin.php?page=solass-claude')
        ));
        return $links;
    }

    // ============================================================
    // МАРШРУТИ
    // ============================================================

    public function register_routes(): void {
        // /help — завжди публічний GET
        register_rest_route(self::NS, '/help', [
            'methods'             => ['GET', 'POST'],
            'callback'            => [$this, 'action_help'],
            'permission_callback' => '__return_true',
        ]);

        // /discover/SLUG — публічний, завжди реєструємо
        register_rest_route(self::NS, '/discover/(?P<slug>[a-zA-Z0-9_-]+)', [
            'methods'             => 'GET',
            'callback'            => [$this, 'action_discover'],
            'permission_callback' => '__return_true',
        ]);

        $cfg = $this->cfg();
        if (empty($cfg['enabled'])) return;

        $active  = $cfg['services'] ?? array_keys(self::SERVICES);
        $get_on  = !empty($cfg['get_enabled']);

        // Slug маршрути: /SLUG/endpoint
        $this->register_slug_routes();

        foreach (self::SERVICES as $slug => $_) {
            if (!in_array($slug, $active)) continue;
            register_rest_route(self::NS, '/' . $slug, [
                'methods'             => $get_on ? ['GET', 'POST'] : 'POST',
                'callback'            => [$this, 'action_' . str_replace('-', '_', $slug)],
                'permission_callback' => [$this, 'auth'],
            ]);
        }
    }

    // ============================================================
    // SLUG МАРШРУТИ (публічний GET без токену в URL)
    // ============================================================

    private function register_slug_routes(): void {
        $cfg  = $this->cfg();
        $slug = trim($cfg['access_slug'] ?? '');
        if (empty($slug) || empty($cfg['get_enabled'])) return;

        $active = $cfg['services'] ?? array_keys(self::SERVICES);

        foreach (self::SERVICES as $service => $_) {
            if (!in_array($service, $active)) continue;
            // Маршрут: /ACCESS_SLUG/endpoint
            register_rest_route(self::NS, '/' . preg_quote($slug, '/') . '/' . $service, [
                'methods'             => 'GET',
                'callback'            => [$this, 'action_' . str_replace('-', '_', $service)],
                'permission_callback' => [$this, 'auth_slug'],
            ]);
        }
    }

    // ============================================================
    // АВТОРИЗАЦІЯ
    // ============================================================

    public function auth(WP_REST_Request $r){
        $cfg   = $this->cfg();
        $token = $cfg['token'] ?? '';

        if (empty($token))
            return new WP_Error('no_token', 'Token not configured', ['status' => 500]);

        // Токен з заголовку (POST) або GET-параметра
        $provided = $r->get_header('X-Claude-Token') ?: $r->get_param('token');
        if ($provided !== $token)
            return new WP_Error('bad_token', 'Invalid token', ['status' => 401]);

        // IP фільтр
        $ips = array_filter(
            array_map('trim', explode("\n", $cfg['allowed_ips'] ?? '')),
            fn($l) => $l !== '' && $l[0] !== '#'
        );
        if (!empty($ips) && !in_array($_SERVER['REMOTE_ADDR'] ?? '', $ips))
            return new WP_Error('bad_ip', 'IP not allowed: ' . ($_SERVER['REMOTE_ADDR'] ?? ''), ['status' => 403]);

        // GET-запит — перевіряємо чи дозволений
        if ($r->get_method() === 'GET') {
            if (empty($cfg['get_enabled']))
                return new WP_Error('get_disabled', 'GET requests are disabled', ['status' => 405]);

            // Команди запису через GET — тільки якщо явно дозволено
            $slug = basename($r->get_route());
            if (in_array($slug, self::WRITE_CMDS) && empty($cfg['get_write']))
                return new WP_Error('get_write_disabled', 'Write commands via GET are disabled', ['status' => 403]);

            // Маскуємо токен в логах після авторизації
            $this->mask_token_in_logs($token);
        }

        $this->log_req($r->get_route(), $r->get_method());
        return true;
    }

    // Авторизація через access_slug в шляху (без токену в URL)
    public function auth_slug(WP_REST_Request $r){
        $cfg  = $this->cfg();
        $slug = trim($cfg['access_slug'] ?? '');

        if (empty($slug))
            return new WP_Error('no_slug', 'Access slug not configured', ['status' => 500]);

        // IP фільтр
        $ips = array_filter(
            array_map('trim', explode("
", $cfg['allowed_ips'] ?? '')),
            fn($l) => $l !== '' && $l[0] !== '#'
        );
        if (!empty($ips) && !in_array($_SERVER['REMOTE_ADDR'] ?? '', $ips))
            return new WP_Error('bad_ip', 'IP not allowed: ' . ($_SERVER['REMOTE_ADDR'] ?? ''), ['status' => 403]);

        // Команди запису — тільки якщо дозволено
        $endpoint = basename(parse_url($r->get_route(), PHP_URL_PATH));
        if (in_array($endpoint, self::WRITE_CMDS) && empty($cfg['get_write']))
            return new WP_Error('write_disabled', 'Write commands disabled for slug access', ['status' => 403]);

        $this->log_req($r->get_route(), 'GET-SLUG');
        return true;
    }

    // ============================================================
    // МАСКУВАННЯ ТОКЕНУ В ЛОГАХ
    // ============================================================

    private function mask_token_in_logs(string $token): void {
        if (empty($token) || strlen($token) < 8) return;

        // Шукаємо можливі лог-файли
        $log_candidates = array_filter([
            ini_get('error_log'),
            WP_CONTENT_DIR . '/debug.log',
            // Nginx/Apache access logs — типові шляхи
            '/var/log/nginx/access.log',
            '/var/log/apache2/access.log',
            '/var/log/httpd/access_log',
            '/www/wwwlogs/' . parse_url(get_bloginfo('url'), PHP_URL_HOST) . '.log',
        ], fn($f) => $f && file_exists($f) && is_writable($f));

        foreach ($log_candidates as $log_file) {
            try {
                // Читаємо тільки останні 200 рядків щоб не вантажити пам'ять
                $lines = [];
                $handle = fopen($log_file, 'r+');
                if (!$handle) continue;

                // Отримуємо розмір файлу
                fseek($handle, 0, SEEK_END);
                $size = ftell($handle);
                if ($size === 0) { fclose($handle); continue; }

                // Читаємо останні ~20KB
                $chunk_size = min($size, 20480);
                fseek($handle, -$chunk_size, SEEK_END);
                $chunk = fread($handle, $chunk_size);
                fclose($handle);

                // Замінюємо токен на ***
                if (strpos($chunk, $token) !== false) {
                    $masked = str_replace($token, str_repeat('*', 8), $chunk);
                    // Перезаписуємо тільки останній chunk
                    $handle = fopen($log_file, 'r+');
                    fseek($handle, -$chunk_size, SEEK_END);
                    fwrite($handle, $masked);
                    fclose($handle);
                }
            } catch (\Throwable $e) {
                // Тихо пропускаємо помилки логування
            }
        }
    }

    // ============================================================
    // ЕНДПОІНТИ
    // ============================================================

    public function action_help(WP_REST_Request $r): WP_REST_Response {
        $cfg    = $this->cfg();
        $active = $cfg['services'] ?? array_keys(self::SERVICES);
        $base   = get_rest_url(null, self::NS);
        $get_on = !empty($cfg['get_enabled']);
        $cmds   = [];
        foreach (self::SERVICES as $slug => [$label, $params]) {
            $is_write = in_array($slug, self::WRITE_CMDS);
            $cmds[$slug] = [
                'endpoint'  => $base . '/' . $slug,
                'label'     => $label,
                'params'    => $params,
                'enabled'   => in_array($slug, $active),
                'via_get'   => $get_on && (!$is_write || !empty($cfg['get_write'])),
                'write_cmd' => $is_write,
            ];
        }
        return $this->ok([
            'plugin'    => 'SOLASS Site → Claude v' . SOLASS_CLAUDE_VERSION,
            'site'      => get_bloginfo('url'),
            'base_url'  => $base,
            'wp'        => get_bloginfo('version'),
            'php'       => PHP_VERSION,
            'root'      => $this->root(),
            'get_mode'  => $get_on ? (!empty($cfg['get_write']) ? 'enabled+write' : 'enabled+readonly') : 'disabled',
            'note'      => 'GET з токеном в шляху: /endpoint/TOKEN (напр. /ping/' . substr($token, 0, 8) . '...)',
            'commands'  => $cmds,
        ]);
    }

    // Публічний discover — повертає всі GET URL для Claude
    // URL: /discover/ACCESS_SLUG
    public function action_discover(WP_REST_Request $r): WP_REST_Response {
        $cfg  = $this->cfg();
        $slug = trim($cfg['access_slug'] ?? '');
        $token = $cfg['token'] ?? '';

        // Перевіряємо slug
        if (empty($slug) || $r->get_param('slug') !== $slug) {
            return new WP_REST_Response(['error' => 'Invalid slug'], 403);
        }

        if (empty($cfg['enabled'])) {
            return new WP_REST_Response(['error' => 'Plugin disabled'], 403);
        }

        $base     = get_rest_url(null, self::NS);
        $active   = $cfg['services'] ?? array_keys(self::SERVICES);
        $get_on   = !empty($cfg['get_enabled']);
        $get_write= !empty($cfg['get_write']);

        // Приклади параметрів для кожного ендпоінту
        $examples = [
            'ping'           => [],
            'server-info'    => [],
            'disk-usage'     => [],
            'wp-info'        => [],
            'active-plugins' => [],
            'list-dir'       => ['path' => 'wp-content/themes'],
            'find-files'     => ['path' => 'wp-content', 'pattern' => '*.php', 'depth' => '3'],
            'tree'           => ['path' => 'wp-content', 'depth' => '2'],
            'get-log'        => ['lines' => '50'],
            'read-file'      => ['path' => 'wp-content/themes/' . get_stylesheet() . '/functions.php'],
            'check-url'      => ['url' => get_bloginfo('url')],
            'write-file'     => ['path' => 'wp-content/test.txt', 'content' => 'test'],
            'wp-cli'         => ['command' => 'plugin list'],
            'exec'           => ['cmd' => 'whoami'],
        ];

        $urls = [];
        foreach (self::SERVICES as $service => [$label, $params]) {
            if (!in_array($service, $active)) continue;

            $is_write = in_array($service, self::WRITE_CMDS);
            if ($is_write && !$get_write) continue;
            if (!$get_on && $is_write) continue;

            // Будуємо GET URL з токеном
            $query = ['token' => $token];
            if (!empty($examples[$service])) {
                $query = array_merge($query, $examples[$service]);
            }
            $url = $base . '/' . $service . '?' . http_build_query($query);

            $urls[$service] = [
                'label'   => $label,
                'url'     => $url,
                'params'  => $params,
                'write'   => $is_write,
            ];
        }

        return $this->ok([
            'plugin'    => 'SOLASS Site → Claude v' . SOLASS_CLAUDE_VERSION,
            'site'      => get_bloginfo('url'),
            'wp'        => get_bloginfo('version'),
            'php'       => PHP_VERSION,
            'root'      => $this->root(),
            'abspath'   => ABSPATH,
            'time'      => current_time('Y-m-d H:i:s'),
            'note'      => 'Це приватний endpoint для Claude. Всі URL нижче готові до використання.',
            'endpoints' => $urls,
        ]);
    }

    public function action_ping(): WP_REST_Response {
        return $this->ok(['pong' => true, 'site' => get_bloginfo('url'), 'time' => current_time('Y-m-d H:i:s'), 'plugin' => SOLASS_CLAUDE_VERSION]);
    }

    public function action_server_info(): WP_REST_Response {
        return $this->ok([
            'php'      => PHP_VERSION,
            'os'       => php_uname('s') . ' ' . php_uname('r'),
            'memory'   => ini_get('memory_limit'),
            'max_exec' => ini_get('max_execution_time'),
            'load'     => sys_getloadavg(),
            'uptime'   => trim(shell_exec('uptime -p') ?? ''),
            'mysql'    => $this->mysql_ver(),
        ]);
    }

    public function action_disk_usage(WP_REST_Request $r): WP_REST_Response {
        $path  = $r->get_param('path') ?: '/';
        $total = disk_total_space($path);
        $free  = disk_free_space($path);
        return $this->ok(['path' => $path, 'total' => $this->fmt($total), 'free' => $this->fmt($free), 'used' => $this->fmt($total - $free), 'used_pct' => round((1 - $free / $total) * 100, 1) . '%']);
    }

    public function action_read_file(WP_REST_Request $r): WP_REST_Response {
        $f = $this->vpath($r->get_param('path'));
        if (is_wp_error($f)) return $this->err($f->get_error_message());
        if (!file_exists($f)) return $this->err("Not found: {$f}");
        $content = $this->redact_secrets($f, file_get_contents($f));
        return $this->ok(['path' => $f, 'content' => $content, 'size' => $this->fmt(filesize($f)), 'modified' => date('Y-m-d H:i:s', filemtime($f))]);
    }

    public function action_write_file(WP_REST_Request $r): WP_REST_Response {
        $f = $this->vpath($r->get_param('path'));
        if (is_wp_error($f)) return $this->err($f->get_error_message());
        if ($this->is_protected_write($f)) return $this->err('Захищений файл, запис заблоковано: ' . basename($f));
        $backup = null;
        if (file_exists($f)) { $backup = $f . '.bak_' . date('Ymd_His'); copy($f, $backup); }
        $bytes = file_put_contents($f, $r->get_param('content') ?? '');
        if ($bytes === false) return $this->err("Cannot write: {$f}");
        return $this->ok(['path' => $f, 'bytes' => $bytes, 'backup' => $backup]);
    }

    public function action_list_dir(WP_REST_Request $r): WP_REST_Response {
        $d = $this->vpath($r->get_param('path') ?: $this->root());
        if (is_wp_error($d)) return $this->err($d->get_error_message());
        if (!is_dir($d)) return $this->err("Not a dir: {$d}");
        $items = [];
        foreach (scandir($d) as $name) {
            if ($name === '.' || $name === '..') continue;
            $full    = $d . '/' . $name;
            $items[] = ['name' => $name, 'type' => is_dir($full) ? 'dir' : 'file', 'size' => is_file($full) ? $this->fmt(filesize($full)) : null, 'modified' => date('Y-m-d H:i:s', filemtime($full))];
        }
        return $this->ok(['path' => $d, 'count' => count($items), 'items' => $items]);
    }

    public function action_find_files(WP_REST_Request $r): WP_REST_Response {
        $path    = $this->vpath($r->get_param('path') ?: $this->root());
        if (is_wp_error($path)) return $this->err($path->get_error_message());
        $pattern = $r->get_param('pattern') ?: '*';
        $depth   = min((int)($r->get_param('depth') ?: 5), 10);
        $results = [];
        $this->find_recursive($path, $pattern, $depth, 0, $results);
        return $this->ok(['path' => $path, 'pattern' => $pattern, 'count' => count($results), 'files' => $results]);
    }

    private function find_recursive(string $dir, string $pattern, int $max, int $cur, array &$res): void {
        if ($cur > $max || count($res) >= 200 || !is_dir($dir) || !is_readable($dir)) return;
        foreach (scandir($dir) as $name) {
            if ($name === '.' || $name === '..') continue;
            $full = $dir . '/' . $name;
            if (is_dir($full)) $this->find_recursive($full, $pattern, $max, $cur + 1, $res);
            elseif (fnmatch($pattern, $name))
                $res[] = ['path' => $full, 'size' => $this->fmt(filesize($full)), 'modified' => date('Y-m-d H:i:s', filemtime($full))];
        }
    }

    public function action_tree(WP_REST_Request $r): WP_REST_Response {
        $path  = $this->vpath($r->get_param('path') ?: $this->root());
        if (is_wp_error($path)) return $this->err($path->get_error_message());
        $depth = min((int)($r->get_param('depth') ?: 3), 6);
        return $this->ok(['path' => $path, 'depth' => $depth, 'tree' => $this->build_tree($path, $depth, 0)]);
    }

    private function build_tree(string $dir, int $max, int $cur): array {
        if ($cur >= $max || !is_dir($dir) || !is_readable($dir)) return [];
        $items = [];
        foreach (scandir($dir) as $name) {
            if ($name === '.' || $name === '..') continue;
            $full  = $dir . '/' . $name;
            $item  = ['name' => $name, 'type' => is_dir($full) ? 'dir' : 'file'];
            if (is_dir($full)) $item['children'] = $this->build_tree($full, $max, $cur + 1);
            else $item['size'] = $this->fmt(filesize($full));
            $items[] = $item;
        }
        return $items;
    }

    public function action_get_log(WP_REST_Request $r): WP_REST_Response {
        $cfg   = $this->cfg();
        $file  = $r->get_param('path') ?: ($cfg['log_path'] ?: WP_CONTENT_DIR . '/debug.log');
        $lines = (int)($r->get_param('lines') ?: 50);
        $f     = $this->vpath($file);
        if (is_wp_error($f)) return $this->err($f->get_error_message());
        if (!file_exists($f)) return $this->err("Log not found: {$f}");
        return $this->ok(['path' => $f, 'lines' => $lines, 'content' => shell_exec("tail -n {$lines} " . escapeshellarg($f))]);
    }

    public function action_wp_info(): WP_REST_Response {
        global $wpdb;
        return $this->ok(['site' => get_bloginfo('url'), 'wp' => get_bloginfo('version'), 'theme' => get_stylesheet(), 'plugins_active' => count(get_option('active_plugins', [])), 'users' => count_users()['total_users'], 'posts' => wp_count_posts()->publish, 'db_prefix' => $wpdb->prefix, 'debug' => defined('WP_DEBUG') && WP_DEBUG, 'abspath' => ABSPATH, 'root' => $this->root()]);
    }

    public function action_wp_cli(WP_REST_Request $r): WP_REST_Response {
        $cmd = trim($r->get_param('command') ?? '');
        if (!$cmd) return $this->err('command required');
        foreach (['db drop', 'db reset', 'user delete', 'core download', 'plugin delete'] as $b)
            if (stripos($cmd, $b) !== false) return $this->err("Blocked: {$b}");
        return $this->ok(['command' => $cmd, 'output' => shell_exec('/usr/local/bin/wp --path=' . escapeshellarg(ABSPATH) . ' --allow-root ' . $cmd . ' 2>&1')]);
    }

    public function action_check_url(WP_REST_Request $r): WP_REST_Response {
        $url = $r->get_param('url') ?? '';
        if (!filter_var($url, FILTER_VALIDATE_URL)) return $this->err('Invalid URL');
        $res = wp_remote_get($url, ['timeout' => 10, 'sslverify' => false]);
        if (is_wp_error($res)) return $this->err($res->get_error_message());
        return $this->ok(['url' => $url, 'code' => wp_remote_retrieve_response_code($res), 'body_len' => strlen(wp_remote_retrieve_body($res))]);
    }

    public function action_active_plugins(): WP_REST_Response {
        $active  = get_option('active_plugins', []);
        $plugins = get_plugins();
        $result  = [];
        foreach ($active as $slug) {
            $i = $plugins[$slug] ?? [];
            $result[] = ['slug' => $slug, 'name' => $i['Name'] ?? $slug, 'version' => $i['Version'] ?? '?', 'author' => $i['Author'] ?? '?'];
        }
        return $this->ok($result);
    }

    public function action_exec(WP_REST_Request $r): WP_REST_Response {
        $cmd = $r->get_param('cmd') ?? '';
        if (!$cmd) return $this->err('cmd required');
        return $this->ok(['cmd' => $cmd, 'output' => shell_exec($cmd . ' 2>&1')]);
    }

    // ============================================================
    // АДМІН
    // ============================================================

    public function admin_menu(): void {
        add_menu_page('SOLASS → Claude', 'SOLASS → Claude', 'manage_options', 'solass-claude', [$this, 'page'], 'dashicons-rest-api', 80);
    }

    public function register_settings(): void {
        register_setting(self::OPT, self::OPT, ['sanitize_callback' => [$this, 'sanitize']]);
    }

    public function sanitize(array $in): array {
        return [
            'enabled'     => !empty($in['enabled'])   ? 1 : 0,
            'get_enabled' => !empty($in['get_enabled'])? 1 : 0,
            'get_write'   => !empty($in['get_write'])  ? 1 : 0,
            'token'       => sanitize_text_field($in['token'] ?? ''),
            'access_slug' => sanitize_text_field($in['access_slug'] ?? ''),
            'log_path'    => sanitize_text_field($in['log_path'] ?? ''),
            'root_path'   => sanitize_text_field($in['root_path'] ?? ''),
            'allowed_ips' => sanitize_textarea_field($in['allowed_ips'] ?? ''),
            'services'    => !empty($in['services']) && is_array($in['services'])
                             ? array_map('sanitize_text_field', $in['services'])
                             : [],
        ];
    }

    public function after_save_settings(): void {
        $this->update_api_file();
    }

    public function ajax_gen_token(): void {
        check_ajax_referer('solass_claude_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_die();
        $token = wp_generate_password(48, false);
        $cfg   = $this->cfg();
        $cfg['token'] = $token;
        update_option(self::OPT, $cfg);
        wp_send_json_success(['token' => $token]);
    }

    public function page(): void {
        $cfg      = $this->cfg();
        $token    = $cfg['token'] ?? '';
        $base_url = get_rest_url(null, self::NS);
        $help_url = $base_url . '/help';
        $active_s = $cfg['services'] ?? array_keys(self::SERVICES);
        $get_on   = !empty($cfg['get_enabled']);
        $get_write= !empty($cfg['get_write']);
        ?>
        <style>
            .sc{max-width:920px}
            .sc h1{display:flex;align-items:center;gap:10px}
            .sc-badge{font-size:12px;font-weight:normal;padding:3px 10px;border-radius:20px;background:#00a32a;color:#fff}
            .sc-badge.off{background:#d63638}
            .sc-badge.warn{background:#f0a500}
            .sc-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}
            .sc-card{background:#fff;border:1px solid #ddd;border-radius:8px;padding:20px;margin-bottom:16px}
            .sc-card h2{margin:0 0 14px;font-size:15px;border-bottom:1px solid #f0f0f0;padding-bottom:10px}
            .sc-row{display:flex;gap:8px;align-items:center}
            .sc-token{flex:1;background:#f0f6fc;border:1px solid #c8d8e8;border-radius:6px;padding:10px 14px;font-family:monospace;font-size:13px;word-break:break-all}
            .sc-url{flex:1;background:#f8f9fa;border:1px solid #e0e0e0;border-radius:6px;padding:7px 12px;font-family:monospace;font-size:11px;word-break:break-all;color:#0073aa}
            .sc-services{display:grid;grid-template-columns:1fr 1fr;gap:4px}
            .sc-services label{display:flex;align-items:flex-start;gap:6px;font-size:13px;padding:4px 6px;border-radius:4px;cursor:pointer}
            .sc-services label:hover{background:#f8f9fa}

            #ping-result{margin-top:10px;font-family:monospace;font-size:12px;background:#f8f9fa;border-radius:6px;padding:10px;display:none;white-space:pre-wrap;max-height:200px;overflow-y:auto}
            .sc-info{border-left:4px solid #0073aa;padding:12px 16px;border-radius:0 6px 6px 0;font-size:13px;background:#f0f6fc}
            .sc-warn{border-left:4px solid #f0a500;padding:12px 16px;border-radius:0 6px 6px 0;font-size:13px;background:#fffbf0;margin-top:10px}
            .sc-danger{border-left:4px solid #d63638;padding:12px 16px;border-radius:0 6px 6px 0;font-size:13px;background:#fdf2f2;margin-top:10px}
            .sc-copy-icon{background:none!important;border:none!important;box-shadow:none!important;outline:none!important;padding:2px;cursor:pointer;color:#a0a5aa;display:inline-flex;align-items:center;justify-content:center;line-height:1;}
.sc-copy-icon:hover,.sc-copy-icon:focus,.sc-copy-icon:active{background:none!important;border:none!important;box-shadow:none!important;outline:none!important;color:#0073aa;}
.sc-copy-icon .dashicons{font-size:20px;width:20px;height:20px;}
            .sc-get-block{border:1px solid #ddd;border-radius:6px;padding:14px;margin-top:10px}
            .sc-get-block.active{border-color:#00a32a;background:#f0fff4}
            .sc-ip-note{font-size:12px;color:#666;margin-top:6px;padding:8px;background:#f8f9fa;border-radius:4px}
        </style>

        <div class="wrap sc">
            <h1>
                SOLASS Site → Claude
                <span class="sc-badge <?= empty($cfg['enabled']) ? 'off' : '' ?>"><?= empty($cfg['enabled']) ? 'Вимкнено' : 'v' . SOLASS_CLAUDE_VERSION ?></span>
                <?php if ($get_on): ?>
                    <span class="sc-badge <?= $get_write ? 'warn' : '' ?>">GET <?= $get_write ? '+ запис' : 'активний' ?></span>
                <?php endif; ?>
            </h1>

            <?php if (isset($_GET['settings-updated'])): ?>
                <div class="notice notice-success is-dismissible"><p>Налаштування збережено.</p></div>
            <?php endif; ?>

            <form method="post" action="options.php">
                <?php settings_fields(self::OPT); ?>

                <div class="sc-grid">
                    <div>

                        <!-- Загальне -->
                        <div class="sc-card">
                            <h2>Загальне</h2>
                            <label style="display:flex;align-items:center;gap:8px;font-size:14px;">
                                <input type="checkbox" name="<?= self::OPT ?>[enabled]" value="1" <?= checked($cfg['enabled'] ?? 1, 1) ?>>
                                Плагін активний
                            </label>
                        </div>

                        <!-- Токен -->
                        <div class="sc-card">
                            <h2>API Токен</h2>
                            <div class="sc-row">
                                <div class="sc-token" id="sc-token-display"><?= esc_html($token ?: '— не задано —') ?></div>
                                <button type="button" class="sc-copy-icon" id="sc-copy-token" title="Копіювати"><span class="dashicons dashicons-clipboard"></span></button>
                                <button type="button" class="button button-primary" id="sc-gen-btn" title="Згенерувати новий токен" style="display:inline-flex;align-items:center;justify-content:center;width:34px;padding:0;"><span class="dashicons dashicons-update" style="margin:0;color:#fff;font-size:18px;width:18px;height:18px;line-height:1;"></span></button>
                            </div>
                            <input type="hidden" name="<?= self::OPT ?>[token]" id="sc-token-input" value="<?= esc_attr($token) ?>">
                            <p class="description" style="margin-top:8px;">POST: заголовок <code>X-Claude-Token</code>. GET: параметр <code>?token=</code></p>
                        </div>

                        <!-- GET доступ -->
                        <div class="sc-card">
                            <h2>GET доступ для Claude</h2>

                            <div class="sc-get-block <?= $get_on ? 'active' : '' ?>">
                                <label style="display:flex;align-items:center;gap:8px;font-size:14px;font-weight:500;">
                                    <input type="checkbox" name="<?= self::OPT ?>[get_enabled]" value="1" id="sc-get-toggle" <?= checked($get_on, true) ?>>
                                    Увімкнути GET-запити
                                </label>
                                <p style="margin:8px 0 0;font-size:12px;color:#666;">
                                    <strong>Для Claude:</strong> вмикай коли хочеш щоб я сам лізав на сервер за твоєю командою з чату. Вимикай коли не потрібно.
                                </p>

                                <div id="sc-get-write-block" style="margin-top:12px;padding-top:12px;border-top:1px solid #e0e0e0;<?= $get_on ? '' : 'display:none' ?>">
                                    <label style="display:flex;align-items:center;gap:8px;font-size:13px;">
                                        <input type="checkbox" name="<?= self::OPT ?>[get_write]" value="1" <?= checked($get_write, true) ?>>
                                        <span>Дозволити <strong>запис</strong> через GET
                                        <small style="display:block;color:#888;font-weight:normal;">write-file, wp-cli, exec — небезпечніше, вмикай тільки якщо треба</small></span>
                                    </label>
                                </div>
                            </div>

                            <?php if ($get_on): ?>
                                <div class="sc-warn">
                                    <span class="dashicons dashicons-warning" style="color:#f0a500;font-size:18px;vertical-align:middle;margin-right:6px;"></span><strong>GET увімкнено.</strong> Токен передається в URL — він може потрапити в логи сервера. Плагін автоматично маскує токен в логах після кожного запиту.
                                    <?php if ($get_write): ?>
                                        <br><br><span class="dashicons dashicons-warning" style="color:#d63638;font-size:18px;vertical-align:middle;margin-right:6px;"></span><strong>Запис через GET увімкнено</strong> — підвищений ризик. Вимкни коли закінчиш роботу з Claude.
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <div class="sc-info" style="margin-top:10px;">
                                    GET вимкнено — тільки POST з заголовком. Максимальна безпека.
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Access Slug -->
                        <div class="sc-card">
                            <h2>Access Slug для Claude</h2>
                            <?php $access_slug = $cfg['access_slug'] ?? ''; ?>
                            <div class="sc-row">
                                <input type="text" name="<?= self::OPT ?>[access_slug]" id="sc-slug-input"
                                       value="<?= esc_attr($access_slug) ?>"
                                       class="regular-text code"
                                       placeholder="напр. x7k2m9">
                                <button type="button" class="button" id="sc-gen-slug" title="Згенерувати slug" style="display:inline-flex;align-items:center;justify-content:center;width:34px;padding:0;"><span class="dashicons dashicons-update" style="margin:0;font-size:18px;width:18px;height:18px;line-height:1;"></span></button>
                            </div>
                            <p class="description" style="margin-top:8px;">
                                Короткий секретний рядок для GET доступу без токену в URL.<br>
                                <?php if ($access_slug): ?>
                                Приклад: <code><?= esc_html($base_url . '/' . $access_slug . '/ping') ?></code>
                                <?php endif; ?>
                            </p>
                        </div>

                        <!-- Корінь -->
                        <div class="sc-card">
                            <h2>Корінь для сканування</h2>
                            <input type="text" name="<?= self::OPT ?>[root_path]" value="<?= esc_attr($cfg['root_path'] ?? '') ?>" class="large-text code" placeholder="<?= esc_attr(ABSPATH) ?>">
                            <p class="description">Claude читає файли починаючи з цієї папки. Default: корінь WP (<code><?= esc_html(ABSPATH) ?></code>)</p>
                        </div>

                        <!-- Лог -->
                        <div class="sc-card">
                            <h2>Шлях до лог-файлу</h2>
                            <input type="text" name="<?= self::OPT ?>[log_path]" value="<?= esc_attr($cfg['log_path'] ?? '') ?>" class="large-text code" placeholder="<?= esc_attr(WP_CONTENT_DIR) ?>/debug.log">
                        </div>

                        <!-- IP -->
                        <div class="sc-card">
                            <h2>Дозволені IP</h2>
                            <textarea name="<?= self::OPT ?>[allowed_ips]" class="large-text code" rows="4"
                                placeholder="# Порожньо = всі дозволені (захист через токен)&#10;# Один IP на рядок, # = коментар&#10;1.2.3.4"><?= esc_textarea($cfg['allowed_ips'] ?? '') ?></textarea>
                            <div class="sc-ip-note">
                                <strong>Порожньо</strong> → всі IP + правильний токен<br>
                                <strong>Є IP</strong> → тільки він + правильний токен
                            </div>
                        </div>

                    </div>
                    <div>

                        <!-- Сервіси -->
                        <div class="sc-card">
                            <h2>Активні сервіси</h2>
                            <div class="sc-services">
                                <?php foreach (self::SERVICES as $slug => [$label, $params]):
                                    $is_write = in_array($slug, self::WRITE_CMDS); ?>
                                    <label>
                                        <input type="checkbox" name="<?= self::OPT ?>[services][]" value="<?= esc_attr($slug) ?>" <?= in_array($slug, $active_s) ? 'checked' : '' ?>>
                                        <span>
                                            <code style="font-size:11px;<?= $is_write ? 'background:#fff3e0;color:#e65100;' : '' ?>"><?= esc_html($slug) ?></code><br>
                                            <small style="color:#666"><?= esc_html($label) ?></small>
                                        </span>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                            <p style="margin-top:10px;font-size:12px;">
                                <a href="#" onclick="document.querySelectorAll('.sc-services input').forEach(i=>i.checked=true);return false">Всі</a> |
                                <a href="#" onclick="document.querySelectorAll('.sc-services input').forEach(i=>i.checked=false);return false">Жодного</a>
                            </p>
                            <p class="description">Виділені команди — запис. Через GET доступні тільки якщо увімкнено "Дозволити запис через GET".</p>
                        </div>

                        <!-- Тест -->
                        <div class="sc-card">
                            <h2>Тест з'єднання</h2>
                            <button type="button" class="button button-primary" id="sc-ping-btn" style="display:inline-flex;align-items:center;gap:4px;"><span class="dashicons dashicons-controls-play" style="margin:0;color:#fff;font-size:16px;width:16px;height:16px;line-height:1.1;"></span> Ping</button>
                            <div id="ping-result"></div>
                        </div>

                    </div>
                </div>

                <?php submit_button('Зберегти'); ?>
            </form>

            <!-- ЗА МЕЖАМИ ФОРМИ -->
            <div class="sc-card">
                <h2>API для Claude</h2>
                <div class="sc-row">
                    <div class="sc-url"><?= esc_url($base_url) ?></div>
                    <button type="button" class="sc-copy-icon" data-copy="<?= esc_attr($base_url) ?>" title="Копіювати"><span class="dashicons dashicons-clipboard"></span></button>
                    <button type="button" class="button button-primary" id="sc-copy-claude" style="display:inline-flex;align-items:center;gap:6px;"><span class="dashicons dashicons-clipboard" style="margin:0;color:#fff;font-size:16px;width:16px;height:16px;line-height:1.1;"></span> Для Claude</button>
                </div>

                <div class="sc-info" style="margin-top:12px;">
                    <strong>Help URL (публічний):</strong>
                    <div class="sc-row" style="margin-top:6px;">
                        <div class="sc-url"><?= esc_url($help_url) ?></div>
                        <button type="button" class="sc-copy-icon" data-copy="<?= esc_attr($help_url) ?>" title="Копіювати"><span class="dashicons dashicons-clipboard"></span></button>
                    </div>
                </div>

                <?php
                $access_slug_val = $cfg['access_slug'] ?? '';
                if ($get_on && $access_slug_val): ?>
                <div style="margin-top:12px;">
                    <p style="font-size:13px;font-weight:500;margin-bottom:8px;">GET URL для Claude (через Access Slug):</p>
                    <?php
                    $examples = [
                        'ping'           => '',
                        'wp-info'        => '',
                        'server-info'    => '',
                        'list-dir'       => '?path=wp-content/themes',
                        'find-files'     => '?path=wp-content/themes&pattern=*.css',
                        'tree'           => '?path=wp-content/plugins&depth=2',
                        'read-file'      => '?path=wp-content/themes/' . get_stylesheet() . '/style.css',
                        'get-log'        => '?lines=50',
                        'active-plugins' => '',
                    ];
                    foreach ($examples as $ep => $extra):
                        $url = $base_url . '/' . $access_slug_val . '/' . $ep . ($extra ?: '');
                    ?>
                    <div class="sc-row" style="margin-bottom:4px;">
                        <div class="sc-url"><?= esc_html($url) ?></div>
                        <button type="button" class="sc-copy-icon" data-copy="<?= esc_attr($url) ?>" title="Копіювати"><span class="dashicons dashicons-clipboard"></span></button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php elseif ($get_on && !$access_slug_val): ?>
                <div class="sc-info" style="margin-top:12px;border-left-color:#f0a500;">
                    Задай <strong>Access Slug</strong> вище і збережи — тут з'являться GET URL для Claude.
                </div>
                <?php else: ?>
                <div class="sc-info" style="margin-top:12px;border-left-color:#888;">
                    GET вимкнено — увімкни GET щоб побачити URL для Claude.
                </div>
                <?php endif; ?>
            </div>

        </div>

        <script>
        const SC = {
            token:     <?= json_encode($token) ?>,
            baseUrl:   <?= json_encode($base_url) ?>,
            helpUrl:   <?= json_encode($help_url) ?>,
            nonce:     <?= json_encode(wp_create_nonce('wp_rest')) ?>,
            ajaxNonce: <?= json_encode(wp_create_nonce('solass_claude_nonce')) ?>
        };

        // Іконки
        const ICON_DONE     = '<span class="dashicons dashicons-yes-alt" style="color:#00a32a;font-size:20px;width:20px;height:20px;display:block;"></span>';
        const ICON_DONE_W   = '<span class="dashicons dashicons-yes-alt" style="color:#fff;font-size:18px;width:18px;height:18px;margin:0;display:block;"></span>';
        const ICON_UPDATE_W = '<span class="dashicons dashicons-update" style="color:#fff;font-size:18px;width:18px;height:18px;margin:0;display:block;"></span>';

        // Копіювання через іконку (без рамки)
        function scCopy(text, btn) {
            navigator.clipboard.writeText(text).then(function() {
                var orig = btn.innerHTML;
                btn.innerHTML = ICON_DONE;
                setTimeout(function() { btn.innerHTML = orig; }, 2000);
            });
        }

        // Всі іконки копіювання data-copy
        document.querySelectorAll('.sc-copy-icon[data-copy]').forEach(function(btn) {
            btn.addEventListener('click', function() { scCopy(this.dataset.copy, this); });
        });

        // Токен
        document.getElementById('sc-copy-token').addEventListener('click', function() {
            scCopy(SC.token, this);
        });

        // Для Claude — кнопка зеленіє на 2 сек
        document.getElementById('sc-copy-claude').addEventListener('click', function() {
            var self = this;
            var slug = document.getElementById('sc-slug-input') ? document.getElementById('sc-slug-input').value : '';
            var msg = 'SOLASS API: ' + SC.baseUrl + '\nToken: ' + SC.token + '\nHelp: ' + SC.helpUrl;
            if (slug) msg += '\nDiscover: ' + SC.baseUrl + '/discover/' + slug;
            navigator.clipboard.writeText(msg).then(function() {
                self.style.background = '#00a32a';
                self.style.borderColor = '#00a32a';
                setTimeout(function() { self.style.background = ''; self.style.borderColor = ''; }, 2000);
            });
        });

        // Генерація access slug
        document.getElementById('sc-gen-slug').addEventListener('click', function() {
            var chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
            var slug = '';
            for (var i = 0; i < 8; i++) slug += chars[Math.floor(Math.random() * chars.length)];
            document.getElementById('sc-slug-input').value = slug;
        });

        // GET toggle
        document.getElementById('sc-get-toggle').addEventListener('change', function() {
            document.getElementById('sc-get-write-block').style.display = this.checked ? 'block' : 'none';
        });

        // Генерація токену
        document.getElementById('sc-gen-btn').addEventListener('click', function() {
            if (!confirm('Згенерувати новий токен? Старий одразу перестане працювати.')) return;
            var self = this;
            self.disabled = true;
            self.innerHTML = ICON_UPDATE_W;
            fetch(ajaxurl, {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=solass_claude_gen_token&nonce=' + SC.ajaxNonce
            })
            .then(function(r) { return r.json(); })
            .then(function(d) {
                if (d.success) {
                    document.getElementById('sc-token-display').textContent = d.data.token;
                    document.getElementById('sc-token-input').value = d.data.token;
                    SC.token = d.data.token;
                    self.innerHTML = ICON_DONE_W;
                    setTimeout(function() { self.innerHTML = ICON_UPDATE_W; self.disabled = false; }, 2000);
                } else {
                    self.innerHTML = ICON_UPDATE_W;
                    self.disabled = false;
                }
            });
        });

        // Ping
        document.getElementById('sc-ping-btn').addEventListener('click', function() {
            var res = document.getElementById('ping-result');
            res.style.display = 'block';
            res.textContent = 'Запит...';
            fetch(SC.baseUrl + '/ping', {
                method: 'POST',
                headers: {'Content-Type': 'application/json', 'X-Claude-Token': SC.token, 'X-WP-Nonce': SC.nonce},
                body: '{}'
            })
            .then(function(r) { return r.json(); })
            .then(function(d) { res.textContent = 'OK\n\n' + JSON.stringify(d.data, null, 2); })
            .catch(function(e) { res.textContent = 'Помилка: ' + e.message; });
        });
        </script>
        <?php
    }

    // ============================================================
    // API.PHP ПРОКСІ ФАЙЛ
    // ============================================================

    private function update_api_file(): void {
        $cfg  = $this->cfg();
        $slug = trim($cfg['access_slug'] ?? '');
        $file = plugin_dir_path(__FILE__) . 'api.php';

        if (empty($slug) || empty($cfg['enabled'])) {
            // Видаляємо файл якщо slug не задано або плагін вимкнено
            if (file_exists($file)) unlink($file);
            return;
        }

        $site_url  = get_rest_url(null, 'solass-claude/v1');
        $token     = $cfg['token'] ?? '';
        $get_write = !empty($cfg['get_write']) ? 'true' : 'false';

        $php = <<<PHPCODE
<?php
/**
 * SOLASS Site -> Claude — API Proxy
 * Auto-generated. Do not edit manually.
 * URL: {$_SERVER['HTTP_HOST']}/wp-content/plugins/solass-site-claude/api.php/SLUG/endpoint
 */

define('SC_SLUG',      '{$slug}');
define('SC_TOKEN',     '{$token}');
define('SC_API_BASE',  '{$site_url}');
define('SC_GET_WRITE', {$get_write});

// Парсимо PATH_INFO: /SLUG/endpoint
\$path = trim(\$_SERVER['PATH_INFO'] ?? parse_url(\$_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
\$path = preg_replace('#^.*api\.php/?#', '', \$path);
\$parts = explode('/', ltrim(\$path, '/'), 2);
\$req_slug    = \$parts[0] ?? '';
\$req_endpoint= \$parts[1] ?? '';

if (\$req_slug !== SC_SLUG || empty(\$req_endpoint)) {
    http_response_code(404);
    die(json_encode(['error' => 'Not found']));
}

// Команди запису — тільки якщо дозволено
\$write_cmds = ['write-file', 'wp-cli', 'exec'];
if (in_array(\$req_endpoint, \$write_cmds) && !SC_GET_WRITE) {
    http_response_code(403);
    die(json_encode(['error' => 'Write commands disabled']));
}

// Збираємо параметри з GET
\$params = \$_GET;
unset(\$params['_path']);

// Проксі запит до WP REST API
\$url = SC_API_BASE . '/' . \$req_endpoint;
if (!empty(\$params)) \$url .= '?' . http_build_query(\$params);

\$ch = curl_init(\$url);
curl_setopt_array(\$ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => 30,
    CURLOPT_HTTPHEADER     => [
        'X-Claude-Token: ' . SC_TOKEN,
        'Content-Type: application/json',
    ],
    CURLOPT_SSL_VERIFYPEER => false,
]);
\$response = curl_exec(\$ch);
\$code      = curl_getinfo(\$ch, CURLINFO_HTTP_CODE);
curl_close(\$ch);

http_response_code(\$code);
header('Content-Type: application/json; charset=utf-8');
echo \$response;
PHPCODE;

        file_put_contents($file, $php);
    }


    // ============================================================
    // АПДЕЙТЕР
    // ============================================================

    private SOLASS_Updater $updater;

    // ============================================================
    // НОВІ ЕНДПОІНТИ 2.7.0
    // ============================================================

    public function action_site_state(): WP_REST_Response {
        global $wpdb;

        // Версії і середовище
        $state = [
            'plugin'       => 'SOLASS Site → Claude v' . SOLASS_CLAUDE_VERSION,
            'site'         => get_bloginfo('url'),
            'time'         => current_time('Y-m-d H:i:s'),
            'wp'           => get_bloginfo('version'),
            'php'          => PHP_VERSION,
            'mysql'        => $this->mysql_ver(),
            'memory_limit' => ini_get('memory_limit'),
            'memory_usage' => $this->fmt(memory_get_usage(true)),
            'max_exec'     => ini_get('max_execution_time'),
            'wp_debug'     => defined('WP_DEBUG') && WP_DEBUG,
            'abspath'      => ABSPATH,
            'root'         => $this->root(),
            'db_prefix'    => $wpdb->prefix,
        ];

        // Диск
        $free  = disk_free_space('/');
        $total = disk_total_space('/');
        $state['disk'] = [
            'total'    => $this->fmt($total),
            'free'     => $this->fmt($free),
            'used'     => $this->fmt($total - $free),
            'used_pct' => round((1 - $free / $total) * 100, 1) . '%',
        ];

        // Тема
        $state['theme'] = get_stylesheet();

        // Активні плагіни (slug => версія)
        $active  = get_option('active_plugins', []);
        $plugins = get_plugins();
        $active_list = [];
        foreach ($active as $slug) {
            $active_list[$slug] = $plugins[$slug]['Version'] ?? '?';
        }
        $state['active_plugins'] = $active_list;
        $state['plugins_count']  = count($active);

        // Кеш-плагіни
        $cache_plugins = ['w3-total-cache', 'wp-super-cache', 'wp-rocket', 'litespeed-cache', 'wp-fastest-cache', 'redis-cache', 'object-cache-pro'];
        $state['cache_plugins'] = array_values(array_filter($cache_plugins, fn($p) => isset($active_list[$p . '/' . $p . '.php']) || isset($active_list[$p . '/wp-cache.php'])));

        // Останні помилки з debug.log (якщо є)
        $log = WP_CONTENT_DIR . '/debug.log';
        if (file_exists($log)) {
            $lines = array_filter(explode("\n", shell_exec("tail -n 30 " . escapeshellarg($log)) ?? ''));
            $errors = array_values(array_filter($lines, fn($l) => strpos($l, 'PHP Fatal') !== false || strpos($l, 'PHP Error') !== false));
            $state['last_errors'] = array_slice($errors, -5);
        } else {
            $state['last_errors'] = [];
        }

        // Версія плагіна в GitHub (з кешованого info.json)
        $info = $this->updater->fetch_update_info();
        $state['update'] = [
            'current'    => SOLASS_CLAUDE_VERSION,
            'available'  => $info['version'] ?? null,
            'has_update' => $info ? version_compare($info['version'] ?? '0', SOLASS_CLAUDE_VERSION, '>') : false,
        ];

        return $this->ok($state);
    }

    public function action_read_file_chunk(WP_REST_Request $r): WP_REST_Response {
        $f = $this->vpath($r->get_param('path'));
        if (is_wp_error($f)) return $this->err($f->get_error_message());
        if (!file_exists($f)) return $this->err("Not found: {$f}");

        $offset = max(0, (int) ($r->get_param('offset') ?? 0));
        $limit  = min(200000, max(1000, (int) ($r->get_param('limit') ?? 50000)));
        $size   = filesize($f);

        $handle = fopen($f, 'r');
        if (!$handle) return $this->err("Cannot open: {$f}");
        if ($offset > 0) fseek($handle, $offset);
        $chunk = fread($handle, $limit);
        fclose($handle);

        $chunk = $this->redact_secrets($f, $chunk);

        return $this->ok([
            'path'      => $f,
            'size'      => $this->fmt($size),
            'size_bytes'=> $size,
            'offset'    => $offset,
            'limit'     => $limit,
            'read_bytes'=> strlen($chunk),
            'has_more'  => ($offset + $limit) < $size,
            'next_offset'=> min($offset + $limit, $size),
            'content'   => $chunk,
        ]);
    }

    public function action_tail_file(WP_REST_Request $r): WP_REST_Response {
        $cfg   = $this->cfg();
        $path  = $r->get_param('path') ?: ($cfg['log_path'] ?: WP_CONTENT_DIR . '/debug.log');
        $lines = min(500, max(1, (int) ($r->get_param('lines') ?? 100)));

        $f = $this->vpath($path);
        if (is_wp_error($f)) return $this->err($f->get_error_message());
        if (!file_exists($f)) return $this->err("File not found: {$f}");

        $content = shell_exec("tail -n {$lines} " . escapeshellarg($f));
        return $this->ok([
            'path'    => $f,
            'lines'   => $lines,
            'size'    => $this->fmt(filesize($f)),
            'content' => $content ?? '',
        ]);
    }

    public function action_force_update(): WP_REST_Response {
        $result = $this->updater->run_update();
        return $this->ok($result);
    }

    public function action_flush_cache(): WP_REST_Response {
        $this->updater->flush_cache();
        delete_site_transient('update_plugins');
        return $this->ok(['flushed' => true, 'message' => 'Кеш оновлень скинуто.']);
    }

    // ============================================================
    // ХЕЛПЕРИ
    // ============================================================

    private function cfg(): array {
        return array_merge(
            ['enabled' => 1, 'get_enabled' => 0, 'get_write' => 0, 'token' => '', 'access_slug' => '', 'log_path' => '', 'root_path' => '', 'allowed_ips' => '', 'services' => array_keys(self::SERVICES)],
            (array) get_option(self::OPT, [])
        );
    }

    private function root(): string {
        $cfg = $this->cfg();
        return rtrim($cfg['root_path'] ?: ABSPATH, '/');
    }

    private function ok(mixed $data): WP_REST_Response {
        $r = new WP_REST_Response(['success' => true, 'data' => $data], 200);
        $r->header('Cache-Control', 'no-store, no-cache, must-revalidate');
        $r->header('X-Solass-Time', current_time('Y-m-d H:i:s'));
        return $r;
    }

    private function err(string $msg, int $code = 400): WP_REST_Response {
        $r = new WP_REST_Response(['success' => false, 'error' => $msg], $code);
        $r->header('Cache-Control', 'no-store, no-cache, must-revalidate');
        $r->header('X-Solass-Time', current_time('Y-m-d H:i:s'));
        return $r;
    }

    // Чи є файл критичним (заборона запису)
    private function is_protected_write($abs) {
        $base = basename($abs);
        if (in_array($base, self::PROTECTED_FILES, true)) return true;
        $root = rtrim($this->root(), '/');
        $rel  = ltrim(str_replace('\\', '/', substr($abs, strlen($root))), '/');
        foreach (self::PROTECTED_DIRS as $d) {
            if ($rel === $d || strpos($rel, $d . '/') === 0) return true;
        }
        return false;
    }

    // Приховування секретів при читанні wp-config.php (без регулярок — надійно)
    private function redact_secrets($abs, $content) {
        if (basename($abs) !== 'wp-config.php') return $content;
        $out = [];
        foreach (explode("\n", $content) as $ln) {
            $u = strtoupper($ln);
            $is_def = strpos($u, 'DEFINE') !== false;
            $sens = false;
            foreach (['KEY', 'SALT', 'PASSWORD', 'SECRET', 'TOKEN', 'NONCE', 'AUTH'] as $w) {
                if (strpos($u, $w) !== false) { $sens = true; break; }
            }
            if ($is_def && $sens) {
                $cpos = strpos($ln, ',');
                if ($cpos !== false) {
                    $ln = substr($ln, 0, $cpos + 1) . " '***REDACTED***' );";
                }
            }
            $out[] = $ln;
        }
        return implode("\n", $out);
    }

    private function vpath(string $path){
        if (!$path) return new WP_Error('no_path', 'path required');
        $root = $this->root();
        if ($path[0] !== '/') return $root . '/' . ltrim($path, '/');
        $real = realpath(dirname($path)) ?: dirname($path);
        foreach ([$root, '/tmp'] as $a) {
            if (strpos($real, rtrim($a, '/')) === 0) return $path;
        }
        return new WP_Error('bad_path', "Path outside root ({$root}): {$path}");
    }

    private function fmt($b): string {
        foreach (['B', 'KB', 'MB', 'GB'] as $u) { if ($b < 1024) return round($b, 2) . " {$u}"; $b /= 1024; }
        return round($b, 2) . ' TB';
    }

    private function mysql_ver(): string {
        global $wpdb; return $wpdb->get_var('SELECT VERSION()') ?? '?';
    }

    private function log_req(string $route, string $method = 'POST'): void {
        $log = get_option(self::OPT . '_log', []);
        array_unshift($log, ['t' => current_time('Y-m-d H:i:s'), 'r' => $route, 'ip' => $_SERVER['REMOTE_ADDR'] ?? '', 'm' => $method]);
        update_option(self::OPT . '_log', array_slice($log, 0, 100));
    }
}

register_activation_hook(__FILE__, function() {
    $inst = new SOLASS_Claude();
    $inst->after_save_settings();
});

// Завжди створюємо клас — щоб адмінка була доступна при будь-яких налаштуваннях
// API маршрути блокуються всередині register_routes() якщо enabled=0
add_action('plugins_loaded', function () {
    new SOLASS_Claude();
});
