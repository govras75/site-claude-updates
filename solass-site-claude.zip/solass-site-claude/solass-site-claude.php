<?php
/**
 * Plugin Name: SOLASS Site -> Claude
 * Plugin URI:  https://solass.com.ua
 * Description: REST API для підключення WordPress сайту до Claude AI.
 * Version:     2.9.1.3
 * Requires at least: 5.0
 * Requires PHP: 7.4
 * Author:      SOLASS
 * Author URI:  https://solass.com.ua/
 * License:     Private
 * Text Domain: solass-claude
 * Domain Path: /languages
 * Update URI:  https://raw.githubusercontent.com/govras75/site-claude-updates/main/solass-site-claude.zip
 * Update JSON: https://raw.githubusercontent.com/govras75/site-claude-updates/main/solass-site-claude-info.json
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// -------------------------------------------------------------------
// Параметри плагіна — АВТОМАТИЧНО з шапки, ніде не дублюємо вручну
// -------------------------------------------------------------------
$solass_claude_meta = get_file_data( __FILE__, [
    'Name'       => 'Plugin Name',
    'Version'    => 'Version',
    'Author'     => 'Author',
    'UpdateURI'  => 'Update URI',
    'UpdateJSON' => 'Update JSON',
] );
define( 'SOLASS_CLAUDE_VERSION',    $solass_claude_meta['Version'] );
define( 'SOLASS_CLAUDE_NAME',       $solass_claude_meta['Name'] );
define( 'SOLASS_CLAUDE_UPDATEURI',  $solass_claude_meta['UpdateURI'] );
define( 'SOLASS_CLAUDE_UPDATEJSON', $solass_claude_meta['UpdateJSON'] );
define( 'SOLASS_CLAUDE_FILE',       __FILE__ );

// -------------------------------------------------------------------
// ЯДРО (фундамент) — підключається завжди, перед модулями
// -------------------------------------------------------------------
require_once __DIR__ . '/includes/class-config.php';
require_once __DIR__ . '/includes/class-utils.php';
require_once __DIR__ . '/includes/class-updater.php';

// -------------------------------------------------------------------
// МОДУЛІ — автозавантаження з теки includes/.
// Кожен модуль самореєструє свої хуки у власному конструкторі.
// Видалення файлу модуля прибирає тільки його функціонал — завантажувач
// не падає (class_exists перевіряється перед створенням).
// Ядрові файли (config/utils/updater) вже підключені вище — пропускаємо.
// -------------------------------------------------------------------
$solass_core = [ 'class-config.php', 'class-utils.php', 'class-updater.php' ];
foreach ( glob( __DIR__ . '/includes/class-*.php' ) as $module_file ) {
    if ( in_array( basename( $module_file ), $solass_core, true ) ) continue;
    require_once $module_file;
}

add_action( 'plugins_loaded', function () {

    // Ядро оновлень (потрібне api-модулю)
    $updater = class_exists( 'SOLASS_Updater' ) ? new SOLASS_Updater( SOLASS_CLAUDE_FILE ) : null;

    // Ядро налаштувань: дефолтний список команд бере з api-модуля (якщо є), реєструє опції
    if ( class_exists( 'SOLASS_Config' ) ) {
        $services = class_exists( 'SOLASS_Api' ) ? array_keys( SOLASS_Api::SERVICES ) : [];
        SOLASS_Config::init( $services );
        add_action( 'admin_init', [ 'SOLASS_Config', 'register' ] );
    }

    // Модулі — кожен самостійний, створюємо лише якщо файл-клас на місці
    $api = class_exists( 'SOLASS_Api' )    ? new SOLASS_Api( $updater )       : null;
    if ( class_exists( 'SOLASS_Github' ) ) new SOLASS_Github( $api );
    if ( class_exists( 'SOLASS_Admin' ) )  new SOLASS_Admin( SOLASS_CLAUDE_FILE );
} );

// При активації — згенерувати proxy api.php (через admin-модуль, якщо присутній)
register_activation_hook( __FILE__, function () {
    require_once __DIR__ . '/includes/class-config.php';
    foreach ( glob( __DIR__ . '/includes/class-*.php' ) as $module_file ) {
        require_once $module_file;
    }
    if ( class_exists( 'SOLASS_Admin' ) ) {
        $admin = new SOLASS_Admin( __FILE__ );
        $admin->after_save_settings();
    }
} );
