<?php
/**
 * Plugin Name: SOLASS Site -> Claude
 * Plugin URI:  https://solass.com.ua
 * Description: REST API для підключення WordPress сайту до Claude AI.
 * Version:     2.9.0.3
 * Requires at least: 5.0
 * Requires PHP: 7.4
 * Author:      SOLASS
 * Author URI:  https://solass.com.ua/
 * License:     Private
 * Text Domain: solass-claude
 * Domain Path: /languages
 * Update URI:  https://raw.githubusercontent.com/govras75/site-claude-updates/main/solass-site-claude.zip
 * Update JSON: https://raw.githubusercontent.com/govras75/site-claude-updates/main/solass-site-claude-info.json
 */

if (!defined('ABSPATH')) exit;

require_once __DIR__ . '/includes/class-config.php';
require_once __DIR__ . '/includes/class-utils.php';
require_once __DIR__ . '/includes/class-updater.php';
require_once __DIR__ . '/includes/class-api.php';
require_once __DIR__ . '/admin/page-access.php';

// Параметри плагіна — АВТОМАТИЧНО з шапки, ніде не дублюємо вручну
$solass_claude_meta = get_file_data(__FILE__, [
    'Name'       => 'Plugin Name',
    'Version'    => 'Version',
    'Author'     => 'Author',
    'UpdateURI'  => 'Update URI',
    'UpdateJSON' => 'Update JSON',
]);
define('SOLASS_CLAUDE_VERSION',    $solass_claude_meta['Version']);
define('SOLASS_CLAUDE_NAME',       $solass_claude_meta['Name']);
define('SOLASS_CLAUDE_UPDATEURI',  $solass_claude_meta['UpdateURI']);
define('SOLASS_CLAUDE_UPDATEJSON', $solass_claude_meta['UpdateJSON']);

class SOLASS_Claude {

    // Критичні файли — заборона ПЕРЕЗАПИСУ через write-file
    const OPT     = 'solass_claude';
    const OPT_GH  = 'solass_claude_github';
 // 25 MB

    // Команди тільки для читання (GET за замовчуванням)
    // 'flush-cache' прибрано зі списку (зайвий) — щоб увімкнути, додати сюди назад

    // Команди запису (потребують окремої галочки для GET)

    // Довжина публічного slug (короткий, не схожий на токен)


    public function __construct() {
        // Ініціалізуємо модуль оновлень
        $this->updater = new SOLASS_Updater(__FILE__);

        // Ядро: передаємо у Config дефолтний список команд (з api-модуля) і реєструємо опції
        SOLASS_Config::init(array_keys(SOLASS_Api::SERVICES));

        // Модуль команд/REST — сам реєструє свої маршрути на rest_api_init
        $this->api = new SOLASS_Api($this->updater);

        add_action('admin_menu',     [$this, 'admin_menu']);
        add_action('admin_init',     [SOLASS_Config::class, 'register']);
        add_action('wp_ajax_solass_claude_gen_token', [$this, 'ajax_gen_token']);
        add_action('update_option_' . self::OPT, [$this, 'after_save_settings']);
        add_action('add_option_' . self::OPT,    [$this, 'after_save_settings']);
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), [$this, 'plugin_links']);
    }

    public function plugin_links(array $links): array {
        array_unshift($links, sprintf(
            '<a href="%s">Налаштування</a>',
            admin_url('admin.php?page=solass-claude')
        ));
        return $links;
    }

    // ============================================================
    // МАРШРУТИ
    // ============================================================


    // ============================================================
    // SLUG МАРШРУТИ (публічний GET без токену в URL)
    // ============================================================


    // ============================================================
    // АВТОРИЗАЦІЯ
    // ============================================================


    // Авторизація через access_slug в шляху (без токену в URL)

    // ============================================================
    // МАСКУВАННЯ ТОКЕНУ В ЛОГАХ
    // ============================================================


    // ============================================================
    // ЕНДПОІНТИ
    // ============================================================


    // Публічний discover — повертає всі GET URL для Claude
    // URL: /discover/ACCESS_SLUG

















    // ============================================================
    // АДМІН
    // ============================================================

    public function admin_menu(): void {
        add_menu_page('SOLASS → Claude', 'SOLASS → Claude', 'manage_options', 'solass-claude', [$this, 'page'], 'dashicons-rest-api', 80);
        add_submenu_page('solass-claude', 'Налаштування', 'Налаштування', 'manage_options', 'solass-claude', [$this, 'page']);
        add_submenu_page('solass-claude', 'Доступи та інтеграції', 'Доступи', 'manage_options', 'solass-claude-source', [$this, 'page_source']);
    }



    // GitHub-доступи — окрема опція solass_claude_github.
    // Сторінка GitHub зберігає ТІЛЬКИ цю опцію, не чіпаючи основні налаштування.

    public function after_save_settings(): void {
        $this->update_api_file();
    }

    public function ajax_gen_token(): void {
        check_ajax_referer('solass_claude_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_die();
        $token = wp_generate_password(48, false);
        $cfg   = SOLASS_Config::cfg();
        $cfg['token'] = $token;
        update_option(self::OPT, $cfg);
        wp_send_json_success(['token' => $token]);
    }

    public function page(): void {
        $cfg      = SOLASS_Config::cfg();
        $token    = $cfg['token'] ?? '';
        $base_url = get_rest_url(null, SOLASS_Api::NS);
        $help_url = $base_url . '/help';
        $active_s = $cfg['services'] ?? array_keys(SOLASS_Api::SERVICES);
        $get_on   = !empty($cfg['get_enabled']);
        $get_write= !empty($cfg['get_write']);
        ?>
        <style>
            .sc{max-width:920px}
            .sc h1{display:flex;align-items:center;gap:10px}
            .sc-badge{font-size:12px;font-weight:normal;padding:3px 10px;border-radius:20px;background:#00a32a;color:#fff}
            .sc-badge.off{background:#d63638}
            .sc-badge.warn{background:#f0a500}
            .sc-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}
            .sc-card{background:#fff;border:1px solid #ddd;border-radius:8px;padding:20px;margin-bottom:16px}
            .sc-card h2{margin:0 0 14px;font-size:15px;border-bottom:1px solid #f0f0f0;padding-bottom:10px}
            .sc-row{display:flex;gap:8px;align-items:center}
            .sc-token{flex:1;background:#f0f6fc;border:1px solid #c8d8e8;border-radius:6px;padding:10px 14px;font-family:monospace;font-size:13px;word-break:break-all}
            .sc-url{flex:1;background:#f8f9fa;border:1px solid #e0e0e0;border-radius:6px;padding:7px 12px;font-family:monospace;font-size:11px;word-break:break-all;color:#0073aa}
            .sc-services{display:grid;grid-template-columns:1fr 1fr;gap:4px}
            .sc-services label{display:flex;align-items:flex-start;gap:6px;font-size:13px;padding:4px 6px;border-radius:4px;cursor:pointer}
            .sc-services label:hover{background:#f8f9fa}

            #ping-result{margin-top:10px;font-family:monospace;font-size:12px;background:#f8f9fa;border-radius:6px;padding:10px;display:none;white-space:pre-wrap;max-height:200px;overflow-y:auto}
            .sc-info{border-left:4px solid #0073aa;padding:12px 16px;border-radius:0 6px 6px 0;font-size:13px;background:#f0f6fc}
            .sc-warn{border-left:4px solid #f0a500;padding:12px 16px;border-radius:0 6px 6px 0;font-size:13px;background:#fffbf0;margin-top:10px}
            .sc-danger{border-left:4px solid #d63638;padding:12px 16px;border-radius:0 6px 6px 0;font-size:13px;background:#fdf2f2;margin-top:10px}
            .sc-copy-icon{background:none!important;border:none!important;box-shadow:none!important;outline:none!important;padding:2px;cursor:pointer;color:#a0a5aa;display:inline-flex;align-items:center;justify-content:center;line-height:1;}
.sc-copy-icon:hover,.sc-copy-icon:focus,.sc-copy-icon:active{background:none!important;border:none!important;box-shadow:none!important;outline:none!important;color:#0073aa;}
.sc-copy-icon .dashicons{font-size:20px;width:20px;height:20px;}
            .sc-get-block{border:1px solid #ddd;border-radius:6px;padding:14px;margin-top:10px}
            .sc-get-block.active{border-color:#00a32a;background:#f0fff4}
            .sc-ip-note{font-size:12px;color:#666;margin-top:6px;padding:8px;background:#f8f9fa;border-radius:4px}
        </style>

        <div class="wrap sc">
            <h1>
                SOLASS Site → Claude
                <span class="sc-badge <?= empty($cfg['enabled']) ? 'off' : '' ?>"><?= empty($cfg['enabled']) ? 'Вимкнено' : 'v' . SOLASS_CLAUDE_VERSION ?></span>
                <?php if ($get_on): ?>
                    <span class="sc-badge <?= $get_write ? 'warn' : '' ?>">GET <?= $get_write ? '+ запис' : 'активний' ?></span>
                <?php endif; ?>
            </h1>

            <?php if (isset($_GET['settings-updated'])): ?>
                <div class="notice notice-success is-dismissible"><p>Налаштування збережено.</p></div>
            <?php endif; ?>

            <form method="post" action="options.php">
                <?php settings_fields(self::OPT); ?>

                <div class="sc-grid">
                    <div>

                        <!-- Загальне -->
                        <div class="sc-card">
                            <h2>Загальне</h2>
                            <label style="display:flex;align-items:center;gap:8px;font-size:14px;">
                                <input type="checkbox" name="<?= self::OPT ?>[enabled]" value="1" <?= checked($cfg['enabled'] ?? 1, 1) ?>>
                                Плагін активний
                            </label>
                        </div>

                        <!-- Токен -->
                        <div class="sc-card">
                            <h2>API Токен</h2>
                            <div class="sc-row">
                                <div class="sc-token" id="sc-token-display"><?= esc_html($token ?: '— не задано —') ?></div>
                                <button type="button" class="sc-copy-icon" id="sc-copy-token" title="Копіювати"><span class="dashicons dashicons-clipboard"></span></button>
                                <button type="button" class="button button-primary" id="sc-gen-btn" title="Згенерувати новий токен" style="display:inline-flex;align-items:center;justify-content:center;width:34px;padding:0;"><span class="dashicons dashicons-update" style="margin:0;color:#fff;font-size:18px;width:18px;height:18px;line-height:1;"></span></button>
                            </div>
                            <input type="hidden" name="<?= self::OPT ?>[token]" id="sc-token-input" value="<?= esc_attr($token) ?>">
                            <p class="description" style="margin-top:8px;">POST: заголовок <code>X-Claude-Token</code>. GET: параметр <code>?token=</code></p>
                        </div>

                        <!-- GET доступ -->
                        <div class="sc-card">
                            <h2>GET доступ для Claude</h2>

                            <div class="sc-get-block <?= $get_on ? 'active' : '' ?>">
                                <label style="display:flex;align-items:center;gap:8px;font-size:14px;font-weight:500;">
                                    <input type="checkbox" name="<?= self::OPT ?>[get_enabled]" value="1" id="sc-get-toggle" <?= checked($get_on, true) ?>>
                                    Увімкнути GET-запити
                                </label>
                                <p style="margin:8px 0 0;font-size:12px;color:#666;">
                                    <strong>Для Claude:</strong> вмикай коли хочеш щоб я сам лізав на сервер за твоєю командою з чату. Вимикай коли не потрібно.
                                </p>

                                <div id="sc-get-write-block" style="margin-top:12px;padding-top:12px;border-top:1px solid #e0e0e0;<?= $get_on ? '' : 'display:none' ?>">
                                    <label style="display:flex;align-items:center;gap:8px;font-size:13px;">
                                        <input type="checkbox" name="<?= self::OPT ?>[get_write]" value="1" <?= checked($get_write, true) ?>>
                                        <span>Дозволити <strong>запис</strong> через GET
                                        <small style="display:block;color:#888;font-weight:normal;">write-file, wp-cli, exec — небезпечніше, вмикай тільки якщо треба</small></span>
                                    </label>
                                </div>
                            </div>

                            <?php if ($get_on): ?>
                                <div class="sc-warn">
                                    <span class="dashicons dashicons-warning" style="color:#f0a500;font-size:18px;vertical-align:middle;margin-right:6px;"></span><strong>GET увімкнено.</strong> Токен передається в URL — він може потрапити в логи сервера. Плагін автоматично маскує токен в логах після кожного запиту.
                                    <?php if ($get_write): ?>
                                        <br><br><span class="dashicons dashicons-warning" style="color:#d63638;font-size:18px;vertical-align:middle;margin-right:6px;"></span><strong>Запис через GET увімкнено</strong> — підвищений ризик. Вимкни коли закінчиш роботу з Claude.
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <div class="sc-info" style="margin-top:10px;">
                                    GET вимкнено — тільки POST з заголовком. Максимальна безпека.
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Access Slug -->
                        <div class="sc-card">
                            <h2>Access Slug для Claude</h2>
                            <?php $access_slug = $cfg['access_slug'] ?? ''; ?>
                            <div class="sc-row">
                                <input type="text" name="<?= self::OPT ?>[access_slug]" id="sc-slug-input"
                                       value="<?= esc_attr($access_slug) ?>"
                                       class="regular-text code"
                                       placeholder="напр. x7k2m9">
                                <button type="button" class="button" id="sc-gen-slug" title="Згенерувати slug" style="display:inline-flex;align-items:center;justify-content:center;width:34px;padding:0;"><span class="dashicons dashicons-update" style="margin:0;font-size:18px;width:18px;height:18px;line-height:1;"></span></button>
                            </div>
                            <p class="description" style="margin-top:8px;">
                                Короткий секретний рядок для GET доступу без токену в URL.<br>
                                <?php if ($access_slug): ?>
                                Приклад: <code><?= esc_html($base_url . '/' . $access_slug . '/ping') ?></code>
                                <?php endif; ?>
                            </p>
                        </div>

                        <!-- Корінь -->
                        <div class="sc-card">
                            <h2>Корінь для сканування</h2>
                            <input type="text" name="<?= self::OPT ?>[root_path]" value="<?= esc_attr($cfg['root_path'] ?? '') ?>" class="large-text code" placeholder="<?= esc_attr(ABSPATH) ?>">
                            <p class="description">Claude читає файли починаючи з цієї папки. Default: корінь WP (<code><?= esc_html(ABSPATH) ?></code>)</p>
                        </div>

                        <!-- Лог -->
                        <div class="sc-card">
                            <h2>Шлях до лог-файлу</h2>
                            <input type="text" name="<?= self::OPT ?>[log_path]" value="<?= esc_attr($cfg['log_path'] ?? '') ?>" class="large-text code" placeholder="<?= esc_attr(WP_CONTENT_DIR) ?>/debug.log">
                        </div>

                        <!-- IP -->
                        <div class="sc-card">
                            <h2>Дозволені IP</h2>
                            <textarea name="<?= self::OPT ?>[allowed_ips]" class="large-text code" rows="4"
                                placeholder="# Порожньо = всі дозволені (захист через токен)&#10;# Один IP на рядок, # = коментар&#10;1.2.3.4"><?= esc_textarea($cfg['allowed_ips'] ?? '') ?></textarea>
                            <div class="sc-ip-note">
                                <strong>Порожньо</strong> → всі IP + правильний токен<br>
                                <strong>Є IP</strong> → тільки він + правильний токен
                            </div>
                        </div>

                    </div>
                    <div>

                        <!-- Сервіси -->
                        <div class="sc-card">
                            <h2>Активні сервіси</h2>
                            <div class="sc-services">
                                <?php foreach (SOLASS_Api::SERVICES as $slug => [$label, $params]):
                                    $is_write = in_array($slug, SOLASS_Api::WRITE_CMDS); ?>
                                    <label>
                                        <input type="checkbox" name="<?= self::OPT ?>[services][]" value="<?= esc_attr($slug) ?>" <?= in_array($slug, $active_s) ? 'checked' : '' ?>>
                                        <span>
                                            <code style="font-size:11px;<?= $is_write ? 'background:#fff3e0;color:#e65100;' : '' ?>"><?= esc_html($slug) ?></code><br>
                                            <small style="color:#666"><?= esc_html($label) ?></small>
                                        </span>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                            <p style="margin-top:10px;font-size:12px;">
                                <a href="#" onclick="document.querySelectorAll('.sc-services input').forEach(i=>i.checked=true);return false">Всі</a> |
                                <a href="#" onclick="document.querySelectorAll('.sc-services input').forEach(i=>i.checked=false);return false">Жодного</a>
                            </p>
                            <p class="description">Виділені команди — запис. Через GET доступні тільки якщо увімкнено "Дозволити запис через GET".</p>
                        </div>

                        <!-- Тест -->
                        <div class="sc-card">
                            <h2>Тест з'єднання</h2>
                            <button type="button" class="button button-primary" id="sc-ping-btn" style="display:inline-flex;align-items:center;gap:4px;"><span class="dashicons dashicons-controls-play" style="margin:0;color:#fff;font-size:16px;width:16px;height:16px;line-height:1.1;"></span> Ping</button>
                            <div id="ping-result"></div>
                        </div>

                    </div>
                </div>

                <?php submit_button('Зберегти'); ?>
            </form>

            <!-- ЗА МЕЖАМИ ФОРМИ -->
            <div class="sc-card">
                <h2>API для Claude</h2>
                <div class="sc-row">
                    <div class="sc-url"><?= esc_url($base_url) ?></div>
                    <button type="button" class="sc-copy-icon" data-copy="<?= esc_attr($base_url) ?>" title="Копіювати"><span class="dashicons dashicons-clipboard"></span></button>
                    <button type="button" class="button button-primary" id="sc-copy-claude" style="display:inline-flex;align-items:center;gap:6px;"><span class="dashicons dashicons-clipboard" style="margin:0;color:#fff;font-size:16px;width:16px;height:16px;line-height:1.1;"></span> Для Claude</button>
                </div>

                <div class="sc-info" style="margin-top:12px;">
                    <strong>Help URL (публічний):</strong>
                    <div class="sc-row" style="margin-top:6px;">
                        <div class="sc-url"><?= esc_url($help_url) ?></div>
                        <button type="button" class="sc-copy-icon" data-copy="<?= esc_attr($help_url) ?>" title="Копіювати"><span class="dashicons dashicons-clipboard"></span></button>
                    </div>
                </div>

                <?php
                $access_slug_val = $cfg['access_slug'] ?? '';
                if ($get_on && $access_slug_val): ?>
                <div style="margin-top:12px;">
                    <p style="font-size:13px;font-weight:500;margin-bottom:8px;">GET URL для Claude (через Access Slug):</p>
                    <?php
                    $examples = [
                        'ping'           => '',
                        'wp-info'        => '',
                        'server-info'    => '',
                        'list-dir'       => '?path=wp-content/themes',
                        'find-files'     => '?path=wp-content/themes&pattern=*.css',
                        'tree'           => '?path=wp-content/plugins&depth=2',
                        'read-file'      => '?path=wp-content/themes/' . get_stylesheet() . '/style.css',
                        'get-log'        => '?lines=50',
                        'active-plugins' => '',
                    ];
                    foreach ($examples as $ep => $extra):
                        $url = $base_url . '/' . $access_slug_val . '/' . $ep . ($extra ?: '');
                    ?>
                    <div class="sc-row" style="margin-bottom:4px;">
                        <div class="sc-url"><?= esc_html($url) ?></div>
                        <button type="button" class="sc-copy-icon" data-copy="<?= esc_attr($url) ?>" title="Копіювати"><span class="dashicons dashicons-clipboard"></span></button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php elseif ($get_on && !$access_slug_val): ?>
                <div class="sc-info" style="margin-top:12px;border-left-color:#f0a500;">
                    Задай <strong>Access Slug</strong> вище і збережи — тут з'являться GET URL для Claude.
                </div>
                <?php else: ?>
                <div class="sc-info" style="margin-top:12px;border-left-color:#888;">
                    GET вимкнено — увімкни GET щоб побачити URL для Claude.
                </div>
                <?php endif; ?>
            </div>

        </div>

        <script>
        const SC = {
            token:     <?= json_encode($token) ?>,
            baseUrl:   <?= json_encode($base_url) ?>,
            helpUrl:   <?= json_encode($help_url) ?>,
            nonce:     <?= json_encode(wp_create_nonce('wp_rest')) ?>,
            ajaxNonce: <?= json_encode(wp_create_nonce('solass_claude_nonce')) ?>
        };

        // Іконки
        const ICON_DONE     = '<span class="dashicons dashicons-yes-alt" style="color:#00a32a;font-size:20px;width:20px;height:20px;display:block;"></span>';
        const ICON_DONE_W   = '<span class="dashicons dashicons-yes-alt" style="color:#fff;font-size:18px;width:18px;height:18px;margin:0;display:block;"></span>';
        const ICON_UPDATE_W = '<span class="dashicons dashicons-update" style="color:#fff;font-size:18px;width:18px;height:18px;margin:0;display:block;"></span>';

        // Копіювання через іконку (без рамки)
        function scCopy(text, btn) {
            navigator.clipboard.writeText(text).then(function() {
                var orig = btn.innerHTML;
                btn.innerHTML = ICON_DONE;
                setTimeout(function() { btn.innerHTML = orig; }, 2000);
            });
        }

        // Всі іконки копіювання data-copy
        document.querySelectorAll('.sc-copy-icon[data-copy]').forEach(function(btn) {
            btn.addEventListener('click', function() { scCopy(this.dataset.copy, this); });
        });

        // Токен
        document.getElementById('sc-copy-token').addEventListener('click', function() {
            scCopy(SC.token, this);
        });

        // Для Claude — кнопка зеленіє на 2 сек
        document.getElementById('sc-copy-claude').addEventListener('click', function() {
            var self = this;
            var slug = document.getElementById('sc-slug-input') ? document.getElementById('sc-slug-input').value : '';
            var msg = 'SOLASS API: ' + SC.baseUrl + '\nToken: ' + SC.token + '\nHelp: ' + SC.helpUrl;
            if (slug) msg += '\nDiscover: ' + SC.baseUrl + '/discover/' + slug;
            navigator.clipboard.writeText(msg).then(function() {
                self.style.background = '#00a32a';
                self.style.borderColor = '#00a32a';
                setTimeout(function() { self.style.background = ''; self.style.borderColor = ''; }, 2000);
            });
        });

        // Генерація access slug
        document.getElementById('sc-gen-slug').addEventListener('click', function() {
            var chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
            var slug = '';
            for (var i = 0; i < 8; i++) slug += chars[Math.floor(Math.random() * chars.length)];
            document.getElementById('sc-slug-input').value = slug;
        });

        // GET toggle
        document.getElementById('sc-get-toggle').addEventListener('change', function() {
            document.getElementById('sc-get-write-block').style.display = this.checked ? 'block' : 'none';
        });

        // Генерація токену
        document.getElementById('sc-gen-btn').addEventListener('click', function() {
            if (!confirm('Згенерувати новий токен? Старий одразу перестане працювати.')) return;
            var self = this;
            self.disabled = true;
            self.innerHTML = ICON_UPDATE_W;
            fetch(ajaxurl, {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=solass_claude_gen_token&nonce=' + SC.ajaxNonce
            })
            .then(function(r) { return r.json(); })
            .then(function(d) {
                if (d.success) {
                    document.getElementById('sc-token-display').textContent = d.data.token;
                    document.getElementById('sc-token-input').value = d.data.token;
                    SC.token = d.data.token;
                    self.innerHTML = ICON_DONE_W;
                    setTimeout(function() { self.innerHTML = ICON_UPDATE_W; self.disabled = false; }, 2000);
                } else {
                    self.innerHTML = ICON_UPDATE_W;
                    self.disabled = false;
                }
            });
        });

        // Ping
        document.getElementById('sc-ping-btn').addEventListener('click', function() {
            var res = document.getElementById('ping-result');
            res.style.display = 'block';
            res.textContent = 'Запит...';
            fetch(SC.baseUrl + '/ping', {
                method: 'POST',
                headers: {'Content-Type': 'application/json', 'X-Claude-Token': SC.token, 'X-WP-Nonce': SC.nonce},
                body: '{}'
            })
            .then(function(r) { return r.json(); })
            .then(function(d) { res.textContent = 'OK\n\n' + JSON.stringify(d.data, null, 2); })
            .catch(function(e) { res.textContent = 'Помилка: ' + e.message; });
        });
        </script>
        <?php
    }

    public function page_source(): void {
        solass_claude_access_render( SOLASS_Config::cfg_github(), self::OPT_GH );
    }

    // ============================================================
    // API.PHP ПРОКСІ ФАЙЛ
    // ============================================================

    private function update_api_file(): void {
        $cfg  = SOLASS_Config::cfg();
        $slug = trim($cfg['access_slug'] ?? '');
        $file = plugin_dir_path(__FILE__) . 'api.php';

        if (empty($slug) || empty($cfg['enabled'])) {
            // Видаляємо файл якщо slug не задано або плагін вимкнено
            if (file_exists($file)) unlink($file);
            return;
        }

        $site_url  = get_rest_url(null, 'solass-claude/v1');
        $token     = $cfg['token'] ?? '';
        $get_write = !empty($cfg['get_write']) ? 'true' : 'false';

        $php = <<<PHPCODE
<?php
/**
 * SOLASS Site -> Claude — API Proxy
 * Auto-generated. Do not edit manually.
 * URL: {$_SERVER['HTTP_HOST']}/wp-content/plugins/solass-site-claude/api.php/SLUG/endpoint
 */

define('SC_SLUG',      '{$slug}');
define('SC_TOKEN',     '{$token}');
define('SC_API_BASE',  '{$site_url}');
define('SC_GET_WRITE', {$get_write});

// Парсимо PATH_INFO: /SLUG/endpoint
\$path = trim(\$_SERVER['PATH_INFO'] ?? parse_url(\$_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
\$path = preg_replace('#^.*api\.php/?#', '', \$path);
\$parts = explode('/', ltrim(\$path, '/'), 2);
\$req_slug    = \$parts[0] ?? '';
\$req_endpoint= \$parts[1] ?? '';

if (\$req_slug !== SC_SLUG || empty(\$req_endpoint)) {
    http_response_code(404);
    die(json_encode(['error' => 'Not found']));
}

// Команди запису — тільки якщо дозволено
\$write_cmds = ['write-file', 'wp-cli', 'exec'];
if (in_array(\$req_endpoint, \$write_cmds) && !SC_GET_WRITE) {
    http_response_code(403);
    die(json_encode(['error' => 'Write commands disabled']));
}

// Збираємо параметри з GET
\$params = \$_GET;
unset(\$params['_path']);

// Проксі запит до WP REST API
\$url = SC_API_BASE . '/' . \$req_endpoint;
if (!empty(\$params)) \$url .= '?' . http_build_query(\$params);

\$ch = curl_init(\$url);
curl_setopt_array(\$ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => 30,
    CURLOPT_HTTPHEADER     => [
        'X-Claude-Token: ' . SC_TOKEN,
        'Content-Type: application/json',
    ],
    CURLOPT_SSL_VERIFYPEER => false,
]);
\$response = curl_exec(\$ch);
\$code      = curl_getinfo(\$ch, CURLINFO_HTTP_CODE);
curl_close(\$ch);

http_response_code(\$code);
header('Content-Type: application/json; charset=utf-8');
echo \$response;
PHPCODE;

        file_put_contents($file, $php);
    }


    // ============================================================
    // АПДЕЙТЕР
    // ============================================================

    private SOLASS_Updater $updater;
    private SOLASS_Api $api;

    // ============================================================
    // НОВІ ЕНДПОІНТИ 2.7.0
    // ============================================================





    // Віддає дані доступу до GitHub-репо (для роботи з файлами/патчами).
    // Повертає повний токен — потрібно щоб Claude міг писати в репо.
    // Команда READ_ONLY, тож захищена API-токеном плагіна.

    // Обробник endpoint 'flush-cache' (зараз вимкнений — зайвий).
    // Викликає force_check() — обнуляє last_checked, WP робить свіжу перевірку
    // оновлень одразу (як сторінка Майстерня → Оновлення).
    // Щоб увімкнути: розкоментувати метод + реєстрацію в SERVICES + READ_ONLY (вгорі).
    // public function action_flush_cache(): WP_REST_Response {
    //     $this->updater->force_check();
    //     return SOLASS_Utils::ok(['flushed' => true, 'message' => 'Перевірку оновлень примусово оновлено.']);
    // }

    // ============================================================
    // ХЕЛПЕРИ
    // ============================================================


    // GitHub-доступи — окрема опція.




    // Чи є файл критичним (заборона запису)

    // Приховування секретів при читанні wp-config.php (без регулярок — надійно)




}

register_activation_hook(__FILE__, function() {
    $inst = new SOLASS_Claude();
    $inst->after_save_settings();
});

// Завжди створюємо клас — щоб адмінка була доступна при будь-яких налаштуваннях
// API маршрути блокуються всередині register_routes() якщо enabled=0
add_action('plugins_loaded', function () {
    new SOLASS_Claude();
});